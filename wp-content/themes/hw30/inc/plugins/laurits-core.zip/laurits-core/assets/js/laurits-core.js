(function ( $ ) {
	'use strict';

	// This case is important when theme is not active
	if ( typeof qodef !== 'object' ) {
		window.qodef = {};
	}

	window.qodefCore                = {};
	qodefCore.shortcodes            = {};
	qodefCore.listShortcodesScripts = {
		qodefSwiper: qodef.qodefSwiper,
		qodefPagination: qodef.qodefPagination,
		qodefFilter: qodef.qodefFilter,
		qodefMasonryLayout: qodef.qodefMasonryLayout,
		qodefJustifiedGallery: qodef.qodefJustifiedGallery,
	};

	qodefCore.body         = $( 'body' );
	qodefCore.html         = $( 'html' );
	qodefCore.windowWidth  = $( window ).width();
	qodefCore.windowHeight = $( window ).height();
	qodefCore.scroll       = 0;

	$( document ).ready(
		function () {
			qodefCore.scroll = $( window ).scrollTop();
			qodefInlinePageStyle.init();
		}
	);

	$( window ).resize(
		function () {
			qodefCore.windowWidth  = $( window ).width();
			qodefCore.windowHeight = $( window ).height();
		}
	);

	$( window ).scroll(
		function () {
			qodefCore.scroll = $( window ).scrollTop();
		}
	);

	/**
	 * Check element to be in the viewport
	 */
	var qodefIsInViewport = {
		check ( $element, callback, onlyOnce ) {
			if ( $element.length ) {
				let value;

				if ( qodef.windowWidth > 680 ) {
					value = 0.15;
				} else {
					value = 0.10;
				}

				var offset = typeof $element.data( 'viewport-offset' ) !== 'undefined' ? $element.data( 'viewport-offset' ) : value; // When item is 15% (10% on mobile devices) in the viewport

				var observer = new IntersectionObserver(
					( entries ) => {
						// isIntersecting is true when element and viewport are overlapping
						// isIntersecting is false when element and viewport don't overlap
						if ( true === entries[0].isIntersecting ) {
							callback.call( $element );

							// Stop watching the element when it's initialize
							if ( false !== onlyOnce ) {
								observer.disconnect();
							}
						}
					},
					{ threshold: [offset] }
				);

				observer.observe( $element[0] );
			}
		},
	};

	qodefCore.qodefIsInViewport = qodefIsInViewport;

	var qodefScroll = {
		disable: function () {
			if ( window.addEventListener ) {
				window.addEventListener(
					'wheel',
					qodefScroll.preventDefaultValue,
					{ passive: false }
				);
			}

			// window.onmousewheel = document.onmousewheel = qodefScroll.preventDefaultValue;
			document.onkeydown = qodefScroll.keyDown;
		},
		enable: function () {
			if ( window.removeEventListener ) {
				window.removeEventListener(
					'wheel',
					qodefScroll.preventDefaultValue,
					{ passive: false }
				);
			}
			window.onmousewheel = document.onmousewheel = document.onkeydown = null;
		},
		preventDefaultValue: function ( e ) {
			e = e || window.event;
			if ( e.preventDefault ) {
				e.preventDefault();
			}
			e.returnValue = false;
		},
		keyDown: function ( e ) {
			var keys = [37, 38, 39, 40];
			for ( var i = keys.length; i--; ) {
				if ( e.keyCode === keys[i] ) {
					qodefScroll.preventDefaultValue( e );
					return;
				}
			}
		}
	};

	qodefCore.qodefScroll = qodefScroll;

	var qodefPerfectScrollbar = {
		init: function ( $holder ) {
			if ( $holder.length ) {
				qodefPerfectScrollbar.qodefInitScroll( $holder );
			}
		},
		qodefInitScroll: function ( $holder ) {
			var $defaultParams = {
				wheelSpeed: 0.6,
				suppressScrollX: true
			};

			var $ps = new PerfectScrollbar(
				$holder[0],
				$defaultParams
			);

			$( window ).resize(
				function () {
					$ps.update();
				}
			);
		}
	};

	qodefCore.qodefPerfectScrollbar = qodefPerfectScrollbar;

	var qodefInlinePageStyle = {
		init: function () {
			this.holder = $( '#laurits-core-page-inline-style' );

			if ( this.holder.length ) {
				var style = this.holder.data( 'style' );

				if ( style.length ) {
					$( 'head' ).append( '<style type="text/css">' + style + '</style>' );
				}
			}
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( window ).on(
		'load',
		function () {
			qodefUncoverFooter.init();
		}
	);

	var qodefUncoverFooter = {
		holder: '',
		init: function () {
			this.holder = $( '#qodef-page-footer.qodef--uncover' );

			if ( this.holder.length && ! qodefCore.html.hasClass( 'touchevents' ) ) {
				qodefUncoverFooter.addClass();
				qodefUncoverFooter.setHeight( this.holder );

				$( window ).resize(
					function () {
						qodefUncoverFooter.setHeight( qodefUncoverFooter.holder );
					}
				);
			}
		},
		setHeight: function ( $holder ) {
			$holder.css( 'height', 'auto' );

			var footerHeight = $holder.outerHeight();

			if ( footerHeight > 0 ) {
				$( '#qodef-page-outer' ).css(
					{
						'margin-bottom': footerHeight,
						'background-color': qodefCore.body.css( 'backgroundColor' )
					}
				);

				$holder.css( 'height', footerHeight );
			}
		},
		addClass: function () {
			qodefCore.body.addClass( 'qodef-page-footer--uncover' );
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefFullscreenMenu.init();
		}
	);

	var qodefFullscreenMenu = {
		init: function () {
			var $fullscreenMenuOpener = $( 'a.qodef-fullscreen-menu-opener' ),
				$menuItems            = $( '#qodef-fullscreen-area nav ul li a' );

			// Open popup menu
			$fullscreenMenuOpener.on(
				'click',
				function ( e ) {
					e.preventDefault();
					var $thisOpener = $( this );

					if ( ! qodefCore.body.hasClass( 'qodef-fullscreen-menu--opened' ) ) {
						qodefFullscreenMenu.openFullscreen( $thisOpener );

						$( document ).keyup(
							function ( e ) {
								if ( e.keyCode === 27 ) {
									qodefFullscreenMenu.closeFullscreen( $thisOpener );
								}
							}
						);
					} else {
						qodefFullscreenMenu.closeFullscreen( $thisOpener );
					}
				}
			);

			//open dropdowns
			$menuItems.on(
				'tap click',
				function ( e ) {
					var $thisItem = $( this );

					if ( $thisItem.parent().hasClass( 'menu-item-has-children' ) ) {
						e.preventDefault();
						qodefFullscreenMenu.clickItemWithChild( $thisItem );
					} else if ( $thisItem.attr( 'href' ) !== 'http://#' && $thisItem.attr( 'href' ) !== '#' ) {
						qodefFullscreenMenu.closeFullscreen( $fullscreenMenuOpener );
					}
				}
			);
		},
		openFullscreen: function ( $opener ) {
			$opener.addClass( 'qodef--opened' );
			qodefCore.body.removeClass( 'qodef-fullscreen-menu-animate--out' ).addClass( 'qodef-fullscreen-menu--opened qodef-fullscreen-menu-animate--in' );
			qodefCore.qodefScroll.disable();
		},
		closeFullscreen: function ( $opener ) {
			$opener.removeClass( 'qodef--opened' );
			qodefCore.body.removeClass( 'qodef-fullscreen-menu--opened qodef-fullscreen-menu-animate--in' ).addClass( 'qodef-fullscreen-menu-animate--out' );
			qodefCore.qodefScroll.enable();
			$( 'nav.qodef-fullscreen-menu ul.sub_menu' ).slideUp( 200 );
		},
		clickItemWithChild: function ( thisItem ) {
			var $thisItemParent  = thisItem.parent(),
				$thisItemSubMenu = $thisItemParent.find( '.sub-menu' ).first();

			if ( $thisItemSubMenu.is( ':visible' ) ) {
				$thisItemSubMenu.slideUp( 300 );
				$thisItemParent.removeClass( 'qodef--opened' );
			} else {
				$thisItemSubMenu.slideDown( 300 );
				$thisItemParent.addClass( 'qodef--opened' ).siblings().find( '.sub-menu' ).slideUp( 400 );
			}
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefHeaderScrollAppearance.init();
		}
	);

	var qodefHeaderScrollAppearance = {
		appearanceType: function () {
			return qodefCore.body.attr( 'class' ).indexOf( 'qodef-header-appearance--' ) !== -1 ? qodefCore.body.attr( 'class' ).match( /qodef-header-appearance--([\w]+)/ )[1] : '';
		},
		init: function () {
			var appearanceType = this.appearanceType();

			if ( appearanceType !== '' && appearanceType !== 'none' ) {
				qodefCore[appearanceType + 'HeaderAppearance']();
			}
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
	    function () {
            qodefMobileHeaderAppearance.init();
        }
	);

	/*
	 **	Init mobile header functionality
	 */
	var qodefMobileHeaderAppearance = {
		init: function () {
			if ( qodefCore.body.hasClass( 'qodef-mobile-header-appearance--sticky' ) ) {

				var docYScroll1   = qodefCore.scroll,
					displayAmount = qodefGlobal.vars.mobileHeaderHeight + qodefGlobal.vars.adminBarHeight,
					$pageOuter    = $( '#qodef-page-outer' );

				qodefMobileHeaderAppearance.showHideMobileHeader( docYScroll1, displayAmount, $pageOuter );

				$( window ).scroll(
				    function () {
                        qodefMobileHeaderAppearance.showHideMobileHeader( docYScroll1, displayAmount, $pageOuter );
                        docYScroll1 = qodefCore.scroll;
                    }
				);

				$( window ).resize(
				    function () {
                        $pageOuter.css( 'padding-top', 0 );
                        qodefMobileHeaderAppearance.showHideMobileHeader( docYScroll1, displayAmount, $pageOuter );
                    }
				);
			}
		},
		showHideMobileHeader: function ( docYScroll1, displayAmount, $pageOuter ) {
			if ( qodefCore.windowWidth <= 1024 ) {
				if ( qodefCore.scroll > displayAmount * 2 ) {
					//set header to be fixed
					qodefCore.body.addClass( 'qodef-mobile-header--sticky' );

					//add transition to it
					setTimeout(
						function () {
							qodefCore.body.addClass( 'qodef-mobile-header--sticky-animation' );
						},
						300
					); //300 is duration of sticky header animation

					//add padding to content so there is no 'jumping'
					$pageOuter.css( 'padding-top', qodefGlobal.vars.mobileHeaderHeight );
				} else {
					//unset fixed header
					qodefCore.body.removeClass( 'qodef-mobile-header--sticky' );

					//remove transition
					setTimeout(
						function () {
							qodefCore.body.removeClass( 'qodef-mobile-header--sticky-animation' );
						},
						300
					); //300 is duration of sticky header animation

					//remove padding from content since header is not fixed anymore
					$pageOuter.css( 'padding-top', 0 );
				}

				if ( (qodefCore.scroll > docYScroll1 && qodefCore.scroll > displayAmount) || (qodefCore.scroll < displayAmount * 3) ) {
					//show sticky header
					qodefCore.body.removeClass( 'qodef-mobile-header--sticky-display' );
				} else {
					//hide sticky header
					qodefCore.body.addClass( 'qodef-mobile-header--sticky-display' );
				}
			}
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefNavMenu.init();
		}
	);

	var qodefNavMenu = {
		init: function () {
			qodefNavMenu.dropdownBehavior();
			qodefNavMenu.wideDropdownPosition();
			qodefNavMenu.dropdownPosition();
		},
		dropdownBehavior: function () {
			var $menuItems = $( '.qodef-header-navigation > ul > li' );

			$menuItems.each(
				function () {
					var $thisItem = $( this );

					if ( $thisItem.find( '.qodef-drop-down-second' ).length ) {
						$thisItem.waitForImages(
							function () {
								var $dropdownHolder      = $thisItem.find( '.qodef-drop-down-second' ),
									$dropdownMenuItem    = $dropdownHolder.find( '.qodef-drop-down-second-inner ul' ),
									dropDownHolderHeight = $dropdownMenuItem.outerHeight();

								if ( navigator.userAgent.match( /(iPod|iPhone|iPad)/ ) ) {
									$thisItem.on(
										'touchstart mouseenter',
										function () {
											$dropdownHolder.css(
												{
													'height': dropDownHolderHeight,
													'overflow': 'visible',
													'visibility': 'visible',
													'opacity': '1',
												}
											);
										}
									).on(
										'mouseleave',
										function () {
											$dropdownHolder.css(
												{
													'height': '0px',
													'overflow': 'hidden',
													'visibility': 'hidden',
													'opacity': '0',
												}
											);
										}
									);
								} else {
									if ( qodefCore.body.hasClass( 'qodef-drop-down-second--animate-height' ) ) {
										var animateConfig = {
											interval: 0,
											over: function () {
												setTimeout(
													function () {
														$dropdownHolder.addClass( 'qodef-drop-down--start' ).css(
															{
																'visibility': 'visible',
																'height': '0',
																'opacity': '1',
															}
														);
														$dropdownHolder.stop().animate(
															{
																'height': dropDownHolderHeight,
															},
															400,
															'linear',
															function () {
																$dropdownHolder.css( 'overflow', 'visible' );
															}
														);
													},
													100
												);
											},
											timeout: 100,
											out: function () {
												$dropdownHolder.stop().animate(
													{
														'height': '0',
														'opacity': 0,
													},
													100,
													function () {
														$dropdownHolder.css(
															{
																'overflow': 'hidden',
																'visibility': 'hidden',
															}
														);
													}
												);

												$dropdownHolder.removeClass( 'qodef-drop-down--start' );
											}
										};

										$thisItem.hoverIntent( animateConfig );
									} else {
										var config = {
											interval: 0,
											over: function () {
												setTimeout(
													function () {
														$dropdownHolder.addClass( 'qodef-drop-down--start' ).stop().css( { 'height': dropDownHolderHeight } );
													},
													150
												);
											},
											timeout: 150,
											out: function () {
												$dropdownHolder.stop().css( { 'height': '0' } ).removeClass( 'qodef-drop-down--start' );
											}
										};

										$thisItem.hoverIntent( config );
									}
								}
							}
						);
					}
				}
			);
		},
		wideDropdownPosition: function () {
			var $menuItems = $( '.qodef-header-navigation > ul > li.qodef-menu-item--wide' );

			if ( $menuItems.length ) {
				$menuItems.each(
					function () {
						var $menuItem        = $( this );
						var $menuItemSubMenu = $menuItem.find( '.qodef-drop-down-second' );

						if ( $menuItemSubMenu.length ) {
							$menuItemSubMenu.css( 'left', 0 );

							var leftPosition = $menuItemSubMenu.offset().left;

							if ( qodefCore.body.hasClass( 'qodef--boxed' ) ) {
								//boxed layout case
								var boxedWidth = $( '.qodef--boxed #qodef-page-wrapper' ).outerWidth();
								leftPosition   = leftPosition - (qodefCore.windowWidth - boxedWidth) / 2;
								$menuItemSubMenu.css( { 'left': -leftPosition, 'width': boxedWidth } );

							} else if ( qodefCore.body.hasClass( 'qodef-drop-down-second--full-width' ) ) {
								//wide dropdown full width case
								$menuItemSubMenu.css( { 'left': -leftPosition, 'width': qodefCore.windowWidth } );
							} else {
								//wide dropdown in grid case
								$menuItemSubMenu.css( { 'left': -leftPosition + (qodefCore.windowWidth - $menuItemSubMenu.width()) / 2 } );
							}
						}
					}
				);
			}
		},
		dropdownPosition: function () {
			var $menuItems = $( '.qodef-header-navigation > ul > li.qodef-menu-item--narrow.menu-item-has-children' );

			if ( $menuItems.length ) {
				$menuItems.each(
					function () {
						var $thisItem         = $( this ),
							menuItemPosition  = $thisItem.offset().left,
							$dropdownHolder   = $thisItem.find( '.qodef-drop-down-second' ),
							$dropdownMenuItem = $dropdownHolder.find( '.qodef-drop-down-second-inner ul' ),
							dropdownMenuWidth = $dropdownMenuItem.outerWidth(),
							menuItemFromLeft  = $( window ).width() - menuItemPosition;

						if ( qodef.body.hasClass( 'qodef--boxed' ) ) {
							//boxed layout case
							var boxedWidth   = $( '.qodef--boxed #qodef-page-wrapper' ).outerWidth();
							menuItemFromLeft = boxedWidth - menuItemPosition;
						}

						var dropDownMenuFromLeft;

						if ( $thisItem.find( 'li.menu-item-has-children' ).length > 0 ) {
							dropDownMenuFromLeft = menuItemFromLeft - dropdownMenuWidth;
						}

						$dropdownHolder.removeClass( 'qodef-drop-down--right' );
						$dropdownMenuItem.removeClass( 'qodef-drop-down--right' );
						if ( menuItemFromLeft < dropdownMenuWidth || dropDownMenuFromLeft < dropdownMenuWidth ) {
							$dropdownHolder.addClass( 'qodef-drop-down--right' );
							$dropdownMenuItem.addClass( 'qodef-drop-down--right' );
						}
					}
				);
			}
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( window ).on(
		'load',
		function () {
			qodefParallaxBackground.init();
		}
	);

	/**
	 * Init global parallax background functionality
	 */
	var qodefParallaxBackground = {
		init: function ( settings ) {
			this.$sections = $( '.qodef-parallax' );

			// Allow overriding the default config
			$.extend( this.$sections, settings );

			var isSupported = ! qodefCore.html.hasClass( 'touchevents' ) && ! qodefCore.body.hasClass( 'qodef-browser--edge' ) && ! qodefCore.body.hasClass( 'qodef-browser--ms-explorer' );

			if ( this.$sections.length && isSupported ) {
				this.$sections.each(
					function () {
						qodefParallaxBackground.ready( $( this ) );
					}
				);
			}
		},
		ready: function ( $section ) {
			$section.$imgHolder  = $section.find( '.qodef-parallax-img-holder' );
			$section.$imgWrapper = $section.find( '.qodef-parallax-img-wrapper' );
			$section.$img        = $section.find( 'img.qodef-parallax-img' );

			var h           = $section.height(),
				imgWrapperH = $section.$imgWrapper.height();

			$section.movement = 100 * (imgWrapperH - h) / h / 2; //percentage (divided by 2 due to absolute img centering in CSS)

			$section.buffer       = window.pageYOffset;
			$section.scrollBuffer = null;


			//calc and init loop
			requestAnimationFrame(
				function () {
					$section.$imgHolder.animate( { opacity: 1 }, 100 );
					qodefParallaxBackground.calc( $section );
					qodefParallaxBackground.loop( $section );
				}
			);

			//recalc
			$( window ).on(
				'resize',
				function () {
					qodefParallaxBackground.calc( $section );
				}
			);
		},
		calc: function ( $section ) {
			var wH = $section.$imgWrapper.height(),
				wW = $section.$imgWrapper.width();

			if ( $section.$img.width() < wW ) {
				$section.$img.css(
					{
						'width': '100%',
						'height': 'auto',
					}
				);
			}

			if ( $section.$img.height() < wH ) {
				$section.$img.css(
					{
						'height': '100%',
						'width': 'auto',
						'max-width': 'unset',
					}
				);
			}
		},
		loop: function ( $section ) {
			if ( $section.scrollBuffer === Math.round( window.pageYOffset ) ) {
				requestAnimationFrame(
					function () {
						qodefParallaxBackground.loop( $section );
					}
				); //repeat loop

				return false; //same scroll value, do nothing
			} else {
				$section.scrollBuffer = Math.round( window.pageYOffset );
			}

			var wH   = window.outerHeight,
				sTop = $section.offset().top,
				sH   = $section.height();

			if ( $section.scrollBuffer + wH * 1.2 > sTop && $section.scrollBuffer < sTop + sH ) {
				var delta = (Math.abs( $section.scrollBuffer + wH - sTop ) / (wH + sH)).toFixed( 4 ), //coeff between 0 and 1 based on scroll amount
					yVal  = (delta * $section.movement).toFixed( 4 );

				if ( $section.buffer !== delta ) {
					$section.$imgWrapper.css( 'transform', 'translate3d(0,' + yVal + '%, 0)' );
				}

				$section.buffer = delta;
			}

			requestAnimationFrame(
				function () {
					qodefParallaxBackground.loop( $section );
				}
			); //repeat loop
		}
	};

	qodefCore.qodefParallaxBackground = qodefParallaxBackground;

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefReview.init();
		}
	);

	var qodefReview = {
		init: function () {
			var ratingHolder = $( '#qodef-page-comments-form .qodef-rating-inner' );

			var addActive = function ( stars, ratingValue ) {
				for ( var i = 0; i < stars.length; i++ ) {
					var star = stars[i];

					if ( i < ratingValue ) {
						$( star ).addClass( 'active' );
					} else {
						$( star ).removeClass( 'active' );
					}
				}
			};

			ratingHolder.each(
				function () {
					var thisHolder  = $( this ),
						ratingInput = thisHolder.find( '.qodef-rating' ),
						ratingValue = ratingInput.val(),
						stars       = thisHolder.find( '.qodef-star-rating' );

					addActive( stars, ratingValue );

					stars.on(
						'click',
						function () {
							ratingInput.val( $( this ).data( 'value' ) ).trigger( 'change' );
						}
					);

					ratingInput.change(
						function () {
							ratingValue = ratingInput.val();

							addActive( stars, ratingValue );
						}
					);
				}
			);
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefSideArea.init();
		}
	);

	var qodefSideArea = {
		init: function () {
			var $sideAreaOpener = $( 'a.qodef-side-area-opener' ),
				$sideAreaClose  = $( '#qodef-side-area-close' ),
				$sideArea       = $( '#qodef-side-area' );

			qodefSideArea.openerHoverColor( $sideAreaOpener );

			// Open Side Area
			$sideAreaOpener.on(
				'click',
				function ( e ) {
					e.preventDefault();

					if ( ! qodefCore.body.hasClass( 'qodef-side-area--opened' ) ) {
						qodefSideArea.openSideArea();

						$( document ).keyup(
							function ( e ) {
								if ( e.keyCode === 27 ) {
									qodefSideArea.closeSideArea();
								}
							}
						);
					} else {
						qodefSideArea.closeSideArea();
					}
				}
			);

			$sideAreaClose.on(
				'click',
				function ( e ) {
					e.preventDefault();
					qodefSideArea.closeSideArea();
				}
			);

			if ( $sideArea.length && typeof qodefCore.qodefPerfectScrollbar === 'object' ) {
				// qodefCore.qodefPerfectScrollbar.init( $sideArea );
			}
		},
		openSideArea: function () {
			var $wrapper      = $( '#qodef-page-wrapper' );
			var currentScroll = $( window ).scrollTop();

			$( '.qodef-side-area-cover' ).remove();
			$wrapper.prepend( '<div class="qodef-side-area-cover"/>' );
			qodefCore.body.removeClass( 'qodef-side-area-animate--out' ).addClass( 'qodef-side-area--opened qodef-side-area-animate--in' );

			$( '.qodef-side-area-cover' ).on(
				'click',
				function ( e ) {
					e.preventDefault();
					qodefSideArea.closeSideArea();
				}
			);

			$( window ).scroll(
				function () {
					if ( Math.abs( qodefCore.scroll - currentScroll ) > 400 ) {
						qodefSideArea.closeSideArea();
					}
				}
			);
		},
		closeSideArea: function () {
			qodefCore.body.removeClass( 'qodef-side-area--opened qodef-side-area-animate--in' ).addClass( 'qodef-side-area-animate--out' );
		},
		openerHoverColor: function ( $opener ) {
			if ( typeof $opener.data( 'hover-color' ) !== 'undefined' ) {
				var hoverColor    = $opener.data( 'hover-color' );
				var originalColor = $opener.css( 'color' );

				$opener.on(
					'mouseenter',
					function () {
						$opener.css( 'color', hoverColor );
					}
				).on(
					'mouseleave',
					function () {
						$opener.css( 'color', originalColor );
					}
				);
			}
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefSpinner.init();
		}
	);

	$( window ).on(
		'elementor/frontend/init',
		function () {
			var isEditMode = Boolean( elementorFrontend.isEditMode() );

			if ( isEditMode ) {
				qodefSpinner.init( isEditMode );
			}
		}
	);

	var qodefSpinner = {
		init: function ( isEditMode ) {
			this.holder = $( '#qodef-page-spinner:not(.qodef-layout--laurits)' );

			if ( this.holder.length ) {
				qodefSpinner.animateSpinner( this.holder, isEditMode );
				qodefSpinner.fadeOutAnimation();
			}
		},
		animateSpinner: function ( $holder, isEditMode ) {
			$( window ).on(
				'load',
				function () {
					qodefSpinner.fadeOutLoader( $holder );
				}
			);

			if ( isEditMode ) {
				qodefSpinner.fadeOutLoader( $holder );
			}
		},
		fadeOutLoader: function ( $holder, speed, delay, easing ) {
			speed  = speed ? speed : 600;
			delay  = delay ? delay : 0;
			easing = easing ? easing : 'swing';

			$holder.delay( delay ).fadeOut( speed, easing );

			$( window ).on(
				'bind',
				'pageshow',
				function ( event ) {
					if ( event.originalEvent.persisted ) {
						$holder.fadeOut( speed, easing );
					}
				}
			);
		},
		fadeOutAnimation: function () {

			// Check for fade out animation
			if ( qodefCore.body.hasClass( 'qodef-spinner--fade-out' ) ) {
				var $pageHolder = $( '#qodef-page-wrapper' ),
					$linkItems  = $( 'a' );

				// If back button is pressed, than show content to avoid state where content is on display:none
				window.addEventListener(
					'pageshow',
					function ( event ) {
						var historyPath = event.persisted || (typeof window.performance !== 'undefined' && window.performance.navigation.type === 2);
						if ( historyPath && ! $pageHolder.is( ':visible' ) ) {
							$pageHolder.show();
						}
					}
				);

				$linkItems.on(
					'click',
					function ( e ) {
						var $clickedLink = $( this );

						if (
							e.which === 1 && // check if the left mouse button has been pressed
							$clickedLink.attr( 'href' ).indexOf( window.location.host ) >= 0 && // check if the link is to the same domain
							! $clickedLink.hasClass( 'remove' ) && // check is WooCommerce remove link
							$clickedLink.parent( '.product-remove' ).length <= 0 && // check is WooCommerce remove link
							$clickedLink.parents( '.woocommerce-product-gallery__image' ).length <= 0 && // check is product gallery link
							typeof $clickedLink.data( 'rel' ) === 'undefined' && // check pretty photo link
							typeof $clickedLink.attr( 'rel' ) === 'undefined' && // check VC pretty photo link
							! $clickedLink.hasClass( 'lightbox-active' ) && // check is lightbox plugin active
							(typeof $clickedLink.attr( 'target' ) === 'undefined' || $clickedLink.attr( 'target' ) === '_self') && // check if the link opens in the same window
							$clickedLink.attr( 'href' ).split( '#' )[0] !== window.location.href.split( '#' )[0] // check if it is an anchor aiming for a different page
						) {
							e.preventDefault();

							$pageHolder.fadeOut(
								600,
								'easeOutSine',
								function () {
									window.location = $clickedLink.attr( 'href' );
								}
							);
						}
					}
				);
			}
		}
	};

})( jQuery );

(function ($) {
	"use strict";
	
	$(window).on('load', function () {
		qodefStickyColumn.init('init');
	});
	
	$(window).resize(function () {
		qodefStickyColumn.init('resize');
	});
	
	var qodefStickyColumn = {
		pageOffset: '',
		scrollAmount: '',
		
		init: function (state) {
			var $holder = $('.qodef-sticky-column'),
				editor = $holder.hasClass('wpb_column') ? 'wp_bakery' : 'elementor';
			
			if ($holder.length) {
				$holder.each(function () {
					qodefStickyColumn.calculateVars($(this), state, editor);
				});
			}
		},
		calculateVars: function ($column, state, editor) {
			var columnVars = {};
			
			if ('wp_bakery' === editor) {
				columnVars.$columnInner = $column.find('.vc_column-inner');
			} else {
				columnVars.$columnInner = $column.find('.elementor-column-wrap');
				if ( ! columnVars.$columnInner.length ) {
					columnVars.$columnInner = $column.find('.elementor-widget-wrap');
				}
			}
			
			columnVars.columnTopEdgePosition = $column.offset().top;
			columnVars.columnLeftEdgePosition = $column.offset().left;
			columnVars.columnWidth = $column.innerWidth();
			columnVars.columnHeight = columnVars.$columnInner.outerHeight(true);
			
			if ('wp_bakery' === editor) {
				columnVars.$row = $column.closest('.vc_row');
			} else {
				columnVars.$row = $column.closest('.elementor-section');
			}
			
			columnVars.rowTopEdgePosition = columnVars.$row.offset().top;
			columnVars.rowHeight = columnVars.$row.outerHeight(true);
			columnVars.rowBottomEdgePosition = columnVars.rowTopEdgePosition + columnVars.rowHeight;
			qodefStickyColumn.scrollAmount = qodef.scroll;
			qodefStickyColumn.scrollAmount = $('#qodef-page-header').outerHeight();

			qodefStickyColumn.checkPosition( $column, columnVars);
			
			$(window).scroll(function () {
				if ('init' === state) {
					var scrollDirection = qodefStickyColumn.checkScrollDirection();
				}
				
				qodefStickyColumn.checkPosition( $column, columnVars, scrollDirection);
			});
		},
		checkPosition: function (column, columnVars, direction) {

			if (qodef.windowWidth > 1024) {
				qodefStickyColumn.calculateOffset();
				
				if ( column.hasClass('qodef-sticky-fixed') ) {
					qodefStickyColumn.setPosition(columnVars, 'fixed');
				} else {
					
					if ((qodef.scroll + qodefStickyColumn.pageOffset) <= columnVars.columnTopEdgePosition) {
						qodefStickyColumn.setPosition(columnVars, 'relative');
					}
					
					if (((qodef.scroll + qodefStickyColumn.pageOffset) >= columnVars.columnTopEdgePosition) && ((qodef.scroll + qodefStickyColumn.pageOffset + columnVars.columnHeight) < columnVars.rowBottomEdgePosition)) {
						qodefStickyColumn.setPosition(columnVars, 'fixed', direction);
					} else if ((qodef.scroll + qodefStickyColumn.pageOffset + columnVars.columnHeight) >= columnVars.rowBottomEdgePosition) {
						if ( column.parents('.qodef-custom-scroll-fix').length ) {
							qodefStickyColumn.setPosition(columnVars, 'fixed', direction);
						} else {
							qodefStickyColumn.setPosition(columnVars, 'absolute');
						}
					}
				}
				
			} else {
				qodefStickyColumn.setPosition(columnVars, 'relative');
			}
		},
		calculateOffset: function () {
			qodefStickyColumn.pageOffset = 0;
			
			if ($('body').hasClass('admin-bar')) {
				qodefStickyColumn.pageOffset += 32;
			}
			
			if ($('body').hasClass('qodef-header--sticky-display') && $('.qodef-header-sticky').length) {
				qodefStickyColumn.pageOffset += parseInt($('.qodef-header-sticky').outerHeight(true));
			}
			
			if ($('body').hasClass('qodef-header--fixed-display')) {
				qodefStickyColumn.pageOffset += parseInt($('#qodef-page-header').outerHeight(true));
				qodefStickyColumn.pageOffset += parseInt($('#qodef-page-header').css('margin-top'));
			}
		},
		checkScrollDirection: function () {
			var scrollDirection = (qodef.scroll > qodefStickyColumn.scrollAmount) ? 'down' : 'up';
			
			qodefStickyColumn.scrollAmount = qodef.scroll;
			
			return scrollDirection;
		},
		setPosition: function (columnVars, position, direction) {
			if ('relative' === position) {
				columnVars.$columnInner.css({
					'bottom': 'auto',
					'left': 'auto',
					'position': 'relative',
					'top': 'auto',
					'width': columnVars.columnWidth,
					'transform': 'translateY(0)',
					'transition': 'none'
				});
			}
			if ('fixed' === position) {
				var transitionValue = 'none';
				
				
				if ($('body').hasClass('qodef-header--sticky-display')) {
					transitionValue = ('up' === direction) ? 'none' : 'transform .5s ease';
				}
				
				if ( $('body').hasClass('qodef-header-fixed-from-start') ) {
					columnVars.$columnInner.css({
						'bottom': 'auto',
						'left': columnVars.columnLeftEdgePosition,
						'position': 'fixed',
						'top': 0,
						'width': columnVars.columnWidth,
						'transform': 'translateY(' +  $('#qodef-page-header').outerHeight()  + 'px)',
						'transition': transitionValue
					});
				} else {
					columnVars.$columnInner.css({
						'bottom': 'auto',
						'left': columnVars.columnLeftEdgePosition,
						'position': 'fixed',
						'top': 0,
						'width': columnVars.columnWidth,
						'transform': 'translateY(' + qodefStickyColumn.pageOffset + 'px)',
						'transition': transitionValue
					});
				}
			}
			if ('absolute' === position) {
				columnVars.$columnInner.css({
					'bottom': -columnVars.rowHeight,
					'left': '0',
					'position': 'absolute',
					'top': 'auto',
					'width': columnVars.columnWidth,
					'transform': 'translateY(0)',
					'transition': 'none'
				});
			}
		}
	};
	
	window.qodefStickyColumn = qodefStickyColumn;
})(jQuery);

(function ($) {
	"use strict";
	
	$(window).on('load', function () {
		qodefPortfolioSticky.init('init');
	});
	
	$(window).resize(function () {
		qodefPortfolioSticky.init('resize');
	});
	
	var qodefPortfolioSticky = {
		pageOffset: '',
		scrollAmount: '',
		
		init: function (state) {
			var $holder = $('.qodef-portfolio-info-holder');
			
			if ($holder.length) {
				$holder.each(function () {
					qodefPortfolioSticky.calculateVars($(this), state);
				});
			}
		},
		calculateVars: function ($info, state) {
			var infoVars = {};
			
			infoVars.$infoInner = $info;
			
			infoVars.columnTopEdgePosition = $info.offset().top;
			infoVars.columnLeftEdgePosition = $info.offset().left;
			infoVars.columnWidth = $info.innerWidth();
			infoVars.columnHeight = $info.outerHeight();
			
			
			infoVars.$outerItem = $info.closest('.qodef-e-content-inner');
			
			
			infoVars.outerItemTopEdgePosition = infoVars.$outerItem.offset().top;
			infoVars.outerItemHeight = infoVars.$outerItem.height();
			infoVars.outerItemBottomEdgePosition = infoVars.outerItemTopEdgePosition + infoVars.outerItemHeight;
			qodefPortfolioSticky.scrollAmount = qodef.scroll;
			
			qodefPortfolioSticky.checkPosition(infoVars);
			
			$(window).scroll(function () {
				if ('init' === state) {
					var scrollDirection = qodefPortfolioSticky.checkScrollDirection();
				}
				
				qodefPortfolioSticky.checkPosition(infoVars, scrollDirection);
			});
		},
		checkPosition: function (infoVars, direction) {
			
			if (qodef.windowWidth > 1024) {
				qodefPortfolioSticky.calculateOffset();
				if ((qodef.scroll + qodefPortfolioSticky.pageOffset) <= infoVars.columnTopEdgePosition) {
					qodefPortfolioSticky.setPosition(infoVars, 'relative');
				}
				if (((qodef.scroll + qodefPortfolioSticky.pageOffset) >= infoVars.columnTopEdgePosition) && ((qodef.scroll + qodefPortfolioSticky.pageOffset + infoVars.columnHeight) < infoVars.outerItemBottomEdgePosition)) {
					qodefPortfolioSticky.setPosition(infoVars, 'fixed', direction);
				} else if ((qodef.scroll + qodefPortfolioSticky.pageOffset + infoVars.columnHeight) >= infoVars.outerItemBottomEdgePosition) {
					qodefPortfolioSticky.setPosition(infoVars, 'absolute');
				}
			} else {
				qodefPortfolioSticky.setPosition(infoVars, 'relative');
			}
		},
		calculateOffset: function () {
			qodefPortfolioSticky.pageOffset = 0;
			
			if ($('body').hasClass('admin-bar')) {
				qodefPortfolioSticky.pageOffset += 32;
			}
			
			if ($('body').hasClass('qodef-header--sticky-display') && $('.qodef-header-sticky').length) {
				qodefPortfolioSticky.pageOffset += parseInt($('.qodef-header-sticky').outerHeight(true));
			}
			
			if ($('body').hasClass('qodef-header--fixed-display')) {
				qodefPortfolioSticky.pageOffset += parseInt($('#qodef-page-header').outerHeight(true));
				qodefPortfolioSticky.pageOffset += parseInt($('#qodef-page-header').css('margin-top'));
			}
		},
		checkScrollDirection: function () {
			var scrollDirection = (qodef.scroll > qodefPortfolioSticky.scrollAmount) ? 'down' : 'up';
			
			qodefPortfolioSticky.scrollAmount = qodef.scroll;
			
			return scrollDirection;
		},
		setPosition: function (columnVars, position, direction) {
			if ('relative' === position) {
				columnVars.$infoInner.css({
					'bottom': 'auto',
					'left': 'auto',
					'position': 'relative',
					'top': 'auto',
					'width': columnVars.columnWidth,
					'transform': 'translateY(0)',
					'transition': 'none, padding .2s ease-out'
				});
				
				if ( columnVars.$infoInner.hasClass('qodef-scroll') ) {
					columnVars.$infoInner.removeClass('qodef-scroll');
				}
				
			}
			if ('fixed' === position) {
				if ($('body').hasClass('qodef-header--sticky-display')) {
					var transitionValue = ('up' === direction) ? 'none' : 'transform .5s ease';
				}
				
				columnVars.$infoInner.css({
					'bottom': 'auto',
					'left': columnVars.columnLeftEdgePosition,
					'position': 'fixed',
					'top': 0,
					'width': columnVars.columnWidth,
					'transform': 'translateY(' + qodefPortfolioSticky.pageOffset + 'px)',
					'transition': transitionValue + ', padding .2s ease-out'
				});
				
				if ( ! columnVars.$infoInner.hasClass('qodef-scroll') ) {
					columnVars.$infoInner.addClass('qodef-scroll');
				}
				
				columnVars.columnHeight = columnVars.$infoInner.outerHeight();
			}
			if ('absolute' === position) {
				columnVars.$infoInner.css({
					'bottom': '0',
					'left': '0',
					'position': 'absolute',
					'top': 'auto',
					'width': columnVars.columnWidth,
					'transform': 'translateY(0)',
					'transition': 'none, padding .2s ease-out'
				});
			}
		}
	};
	
	window.qodefPortfolioSticky = qodefPortfolioSticky;
})(jQuery);

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_accordion = {};

	$( document ).ready(
		function () {
			qodefAccordion.init();
		}
	);

	var qodefAccordion = {
		init: function () {
			var $holder = $( '.qodef-accordion' );

			if ( $holder.length ) {
				$holder.each(
					function () {
						qodefAccordion.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			if ( $currentItem.hasClass( 'qodef-behavior--accordion' ) ) {
				qodefAccordion.initAccordion( $currentItem );
			}

			if ( $currentItem.hasClass( 'qodef-behavior--toggle' ) ) {
				qodefAccordion.initToggle( $currentItem );
			}

			$currentItem.addClass( 'qodef--init' );
		},
		initAccordion: function ( $accordion ) {
			$accordion.accordion(
				{
					animate: 'swing',
					collapsible: true,
					active: 0,
					icons: '',
					heightStyle: 'content',
				}
			);
		},
		initToggle: function ( $toggle ) {
			var $toggleAccordionTitle = $toggle.find( '.qodef-accordion-title' );

			$toggleAccordionTitle.off().on(
				'mouseenter',
				function () {
					$( this ).addClass( 'ui-state-hover' );
				}
			).on(
				'mouseleave',
				function () {
					$( this ).removeClass( 'ui-state-hover' );
				}
			).on(
				'click',
				function () {
					var $thisTitle = $( this );

					if ( $thisTitle.hasClass( 'ui-state-active' ) ) {
						$thisTitle.removeClass( 'ui-state-active' );
						$thisTitle.next().removeClass( 'ui-accordion-content-active' ).slideUp( 300 );
					} else {
						$thisTitle.addClass( 'ui-state-active' );
						$thisTitle.next().addClass( 'ui-accordion-content-active' ).slideDown( 400 );
					}
				}
			);
		}
	};

	qodefCore.shortcodes.laurits_core_accordion.qodefAccordion = qodefAccordion;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_button = {};

	$( document ).ready(
		function () {
			qodefButton.init();
		}
	);

	var qodefButton = {
		init: function () {
			this.buttons = $( '.qodef-button' );

			if ( this.buttons.length ) {
				this.buttons.each(
					function () {
						qodefButton.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			qodefButton.buttonHoverColor( $currentItem );
			qodefButton.buttonHoverBgColor( $currentItem );
			qodefButton.buttonHoverBorderColor( $currentItem );
		},
		buttonHoverColor: function ( $button ) {
			if ( typeof $button.data( 'hover-color' ) !== 'undefined' ) {
				var hoverColor    = $button.data( 'hover-color' );
				var originalColor = $button.css( 'color' );

				$button.on(
					'mouseenter touchstart',
					function () {
						qodefButton.changeColor( $button, 'color', hoverColor );
					}
				);
				$button.on(
					'mouseleave touchend',
					function () {
						qodefButton.changeColor( $button, 'color', originalColor );
					}
				);
			}
		},
		buttonHoverBgColor: function ( $button ) {
			if ( typeof $button.data( 'hover-background-color' ) !== 'undefined' ) {
				var hoverBackgroundColor    = $button.data( 'hover-background-color' );
				var originalBackgroundColor = $button.css( 'background-color' );

				$button.on(
					'mouseenter touchstart',
					function () {
						qodefButton.changeColor( $button, 'background-color', hoverBackgroundColor );
					}
				);
				$button.on(
					'mouseleave touchend',
					function () {
						qodefButton.changeColor( $button, 'background-color', originalBackgroundColor );
					}
				);
			}
		},
		buttonHoverBorderColor: function ( $button ) {
			if ( typeof $button.data( 'hover-border-color' ) !== 'undefined' ) {
				var hoverBorderColor    = $button.data( 'hover-border-color' );
				var originalBorderColor = $button.css( 'borderTopColor' );

				$button.on(
					'mouseenter touchstart',
					function () {
						qodefButton.changeColor( $button, 'border-color', hoverBorderColor );
					}
				);
				$button.on(
					'mouseleave touchend',
					function () {
						qodefButton.changeColor( $button, 'border-color', originalBorderColor );
					}
				);
			}
		},
		changeColor: function ( $button, cssProperty, color ) {
			$button.css( cssProperty, color );
		}
	};

	qodefCore.shortcodes.laurits_core_button.qodefButton = qodefButton;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_countdown = {};

	$( document ).ready(
		function () {
			qodefCountdown.init();
		}
	);

	var qodefCountdown = {
		init: function () {
			this.countdowns = $( '.qodef-countdown' );

			if ( this.countdowns.length ) {
				this.countdowns.each(
					function () {
						qodefCountdown.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			var $countdownElement = $currentItem.find( '.qodef-m-date' ),
				options           = qodefCountdown.generateOptions( $currentItem );

			qodefCountdown.initCountdown( $countdownElement, options );
		},
		generateOptions: function ( $countdown ) {
			var options  = {};
			options.date = typeof $countdown.data( 'date' ) !== 'undefined' ? $countdown.data( 'date' ) : null;

			options.weekLabel       = typeof $countdown.data( 'week-label' ) !== 'undefined' ? $countdown.data( 'week-label' ) : '';
			options.weekLabelPlural = typeof $countdown.data( 'week-label-plural' ) !== 'undefined' ? $countdown.data( 'week-label-plural' ) : '';

			options.dayLabel       = typeof $countdown.data( 'day-label' ) !== 'undefined' ? $countdown.data( 'day-label' ) : '';
			options.dayLabelPlural = typeof $countdown.data( 'day-label-plural' ) !== 'undefined' ? $countdown.data( 'day-label-plural' ) : '';

			options.hourLabel       = typeof $countdown.data( 'hour-label' ) !== 'undefined' ? $countdown.data( 'hour-label' ) : '';
			options.hourLabelPlural = typeof $countdown.data( 'hour-label-plural' ) !== 'undefined' ? $countdown.data( 'hour-label-plural' ) : '';

			options.minuteLabel       = typeof $countdown.data( 'minute-label' ) !== 'undefined' ? $countdown.data( 'minute-label' ) : '';
			options.minuteLabelPlural = typeof $countdown.data( 'minute-label-plural' ) !== 'undefined' ? $countdown.data( 'minute-label-plural' ) : '';

			options.secondLabel       = typeof $countdown.data( 'second-label' ) !== 'undefined' ? $countdown.data( 'second-label' ) : '';
			options.secondLabelPlural = typeof $countdown.data( 'second-label-plural' ) !== 'undefined' ? $countdown.data( 'second-label-plural' ) : '';

			return options;
		},
		initCountdown: function ( $countdownElement, options ) {
			var $weekHTML   = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%w</span><span class="qodef-label">' + '%!w:' + options.weekLabel + ',' + options.weekLabelPlural + ';</span></span>';
			var $dayHTML    = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%d</span><span class="qodef-label">' + '%!d:' + options.dayLabel + ',' + options.dayLabelPlural + ';</span></span>';
			var $hourHTML   = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%H</span><span class="qodef-label">' + '%!H:' + options.hourLabel + ',' + options.hourLabelPlural + ';</span></span>';
			var $minuteHTML = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%M</span><span class="qodef-label">' + '%!M:' + options.minuteLabel + ',' + options.minuteLabelPlural + ';</span></span>';
			var $secondHTML = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%S</span><span class="qodef-label">' + '%!S:' + options.secondLabel + ',' + options.secondLabelPlural + ';</span></span>';

			$countdownElement.countdown(
				options.date,
				function ( event ) {
					$( this ).html( event.strftime( $weekHTML + $dayHTML + $hourHTML + $minuteHTML + $secondHTML ) );
				}
			);
		}
	};

	qodefCore.shortcodes.laurits_core_countdown.qodefCountdown = qodefCountdown;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_counter = {};

	$( document ).ready(
		function () {
			qodefCounter.init();
		}
	);

	var qodefCounter = {
		init: function () {
			this.counters = $( '.qodef-counter' );

			if ( this.counters.length ) {
				this.counters.each(
					function () {
						qodefCounter.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			var $counterElement = $currentItem.find( '.qodef-m-digit' ),
				options         = qodefCounter.generateOptions( $currentItem );

			qodefCounter.counterScript( $counterElement, options );
		},
		generateOptions: function ( $counter ) {
			var options   = {};
			options.start = typeof $counter.data( 'start-digit' ) !== 'undefined' && $counter.data( 'start-digit' ) !== '' ? $counter.data( 'start-digit' ) : 0;
			options.end   = typeof $counter.data( 'end-digit' ) !== 'undefined' && $counter.data( 'end-digit' ) !== '' ? $counter.data( 'end-digit' ) : null;
			options.step  = typeof $counter.data( 'step-digit' ) !== 'undefined' && $counter.data( 'step-digit' ) !== '' ? $counter.data( 'step-digit' ) : 1;
			options.delay = typeof $counter.data( 'step-delay' ) !== 'undefined' && $counter.data( 'step-delay' ) !== '' ? parseInt( $counter.data( 'step-delay' ), 10 ) : 100;
			options.txt   = typeof $counter.data( 'digit-label' ) !== 'undefined' && $counter.data( 'digit-label' ) !== '' ? $counter.data( 'digit-label' ) : '';

			return options;
		},
		counterScript: function ( $counterElement, options ) {
			var defaults = {
				start: 0,
				end: null,
				step: 1,
				delay: 50,
				txt: '',
			};

			var settings = $.extend( defaults, options || {} );
			var nb_start = settings.start;
			var nb_end   = settings.end;

			$counterElement.text( nb_start + settings.txt );

			var counter = function () {
				// Definition of conditions of arrest
				if ( nb_end !== null && nb_start >= nb_end ) {
					return;
				}
				// incrementation
				nb_start = nb_start + settings.step;

				if ( nb_start >= nb_end ) {
					nb_start = nb_end;
				}
				// display
				$counterElement.text( nb_start + settings.txt );
			};

			// Timer
			// Launches every "settings.delay"
			$counterElement.appear(
				function () {
					setInterval( counter, settings.delay );
				},
				{ accX: 0, accY: 0 }
			);
		}
	};

	qodefCore.shortcodes.laurits_core_counter.qodefCounter = qodefCounter;

})( jQuery );

(function ( $ ) {
    'use strict';

    qodefCore.shortcodes.laurits_core_custom_font = {};

    $( document ).ready(
        () => {
            qodefCustomFont.init();
        }
    );

    const qodefCustomFont = {
        init () {
            this.holder = $('.qodef-custom-font');

            if ( this.holder.length ) {
                this.holder.each(
                    ( index, element ) => {
                        const $holder = $( element );

                        if ( $holder.hasClass('qodef-appear-animation--yes') ) {
                            qodefCustomFont.appearAnimation( $holder );
                        }
                    }
                );
            }
        },
        appearAnimation ( $holder ) {
            qodefCore.qodefIsInViewport.check(
                $holder,
                () => {
                    const $titleParts = $holder.find('.qodef-m-title-part'),
                          delay       = $holder.data('appearing-delay');

                    setTimeout(
                        () => {
                            $holder.addClass('qodef--appeared');
                        }, delay
                    );

                    if ( $titleParts.length ) {
                        $titleParts.each(
                            ( index, element ) => {
                                const $thisTitlePart = $( element );

                                setTimeout(
                                    () => {
                                        $thisTitlePart.addClass('qodef--appeared');
                                    }, index * 200 + ( delay + 100 )
                                );
                            }
                        );
                    }
                }
            );
        }
    };

    qodefCore.shortcodes.laurits_core_custom_font.qodefCustomFont = qodefCustomFont;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_google_map = {};

	$( document ).ready(
		function () {
			qodefGoogleMap.init();
		}
	);

	var qodefGoogleMap = {
		init: function () {
			this.holder = $( '.qodef-google-map' );

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						qodefGoogleMap.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			if ( typeof window.qodefGoogleMap !== 'undefined' ) {
				window.qodefGoogleMap.init( $currentItem.find( '.qodef-m-map' ) );
			}
		},
	};

	qodefCore.shortcodes.laurits_core_google_map.qodefGoogleMap = qodefGoogleMap;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_icon = {};

	$( document ).ready(
		function () {
			qodefIcon.init();
		}
	);

	var qodefIcon = {
		init: function () {
			this.icons = $( '.qodef-icon-holder' );

			if ( this.icons.length ) {
				this.icons.each(
					function () {
						qodefIcon.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			qodefIcon.iconHoverColor( $currentItem );
			qodefIcon.iconHoverBgColor( $currentItem );
			qodefIcon.iconHoverBorderColor( $currentItem );
		},
		iconHoverColor: function ( $iconHolder ) {
			if ( typeof $iconHolder.data( 'hover-color' ) !== 'undefined' ) {
				var spanHolder    = $iconHolder.find( 'span' ).length ? $iconHolder.find( 'span' ) : $iconHolder;
				var originalColor = spanHolder.css( 'color' );
				var hoverColor    = $iconHolder.data( 'hover-color' );

				$iconHolder.on(
					'mouseenter',
					function () {
						qodefIcon.changeColor(
							spanHolder,
							'color',
							hoverColor
						);
					}
				);
				$iconHolder.on(
					'mouseleave',
					function () {
						qodefIcon.changeColor(
							spanHolder,
							'color',
							originalColor
						);
					}
				);
			}
		},
		iconHoverBgColor: function ( $iconHolder ) {
			if ( typeof $iconHolder.data( 'hover-background-color' ) !== 'undefined' ) {
				var hoverBackgroundColor    = $iconHolder.data( 'hover-background-color' );
				var originalBackgroundColor = $iconHolder.css( 'background-color' );

				$iconHolder.on(
					'mouseenter',
					function () {
						qodefIcon.changeColor(
							$iconHolder,
							'background-color',
							hoverBackgroundColor
						);
					}
				);
				$iconHolder.on(
					'mouseleave',
					function () {
						qodefIcon.changeColor(
							$iconHolder,
							'background-color',
							originalBackgroundColor
						);
					}
				);
			}
		},
		iconHoverBorderColor: function ( $iconHolder ) {
			if ( typeof $iconHolder.data( 'hover-border-color' ) !== 'undefined' ) {
				var hoverBorderColor    = $iconHolder.data( 'hover-border-color' );
				var originalBorderColor = $iconHolder.css( 'borderTopColor' );

				$iconHolder.on(
					'mouseenter',
					function () {
						qodefIcon.changeColor(
							$iconHolder,
							'border-color',
							hoverBorderColor
						);
					}
				);
				$iconHolder.on(
					'mouseleave',
					function () {
						qodefIcon.changeColor(
							$iconHolder,
							'border-color',
							originalBorderColor
						);
					}
				);
			}
		},
		changeColor: function ( iconElement, cssProperty, color ) {
			iconElement.css(
				cssProperty,
				color
			);
		}
	};

	qodefCore.shortcodes.laurits_core_icon.qodefIcon = qodefIcon;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_image_gallery = {};

	$( document ).ready(
		() => {
			qodefImageGallery.init();
		}
	);

	const qodefImageGallery = {
		init: function () {
			this.holder = $('.qodef-image-gallery');

			if ( this.holder.length ) {
				this.holder.each(
					( index, element ) => {
						const $holder = $( element );

						if ( $holder.hasClass('qodef-appear-animation--yes') ) {
							qodefImageGallery.appearAnimation( $holder );
						}
					}
				);
			}
		},
		appearAnimation ( $holder ) {
			qodefCore.qodefIsInViewport.check(
				$holder,
				() => {
					$holder.addClass('qodef--appeared');
				}
			);
		}
	}

	qodefCore.shortcodes.laurits_core_image_gallery.qodefImageGallery  = qodefImageGallery;
	qodefCore.shortcodes.laurits_core_image_gallery.qodefSwiper        = qodef.qodefSwiper;
	qodefCore.shortcodes.laurits_core_image_gallery.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.laurits_core_image_gallery.qodefMagnificPopup = qodef.qodefMagnificPopup;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_image_with_text = {};

	$( document ).ready(
		() => {
			qodefImageWithText.init();
		}
	);

	var qodefImageWithText = {
		init () {
			const $holder = $( '.qodef-image-with-text' );

			if ( $holder.length ) {
				$holder.each(
					( index, element ) => {
						const $thisHolder = $( element );

						qodefImageWithText.scrollAnimation( $thisHolder );

						if ( $thisHolder.hasClass('qodef-appear-animation--yes') ) {
							qodefImageWithText.appearAnimation( $thisHolder );
						}

						if ( $thisHolder.hasClass('qodef-image-action--custom-link') ) {
							qodefImageWithText.linkHover( $thisHolder );
						}
					}
				);
			}
		},
		scrollAnimation ( $thisHolder ) {
			if ( $thisHolder.hasClass( 'qodef-image-action--scrolling-image' ) ) {
				let $imageHolder = $thisHolder.find( '.qodef-m-image' ),
					$frame       = $thisHolder.find( '.qodef-m-frame' ),
					$image       = $thisHolder.find( '.qodef-m-image-holder-inner > a > img, .qodef-m-image-holder-inner > img' ),
					horizontal   = $thisHolder.hasClass('qodef-scrolling-direction--horizontal'),
					frameHeight,
					frameWidth,
					imageHeight,
					imageWidth,
					delta,
					timing,
					scrollable  = false;

				const setSize = () => {
					frameHeight = $frame.height();
					imageHeight = $image.height();
					frameWidth  = $frame.width();
					imageWidth  = $image.width();
					delta       = Math.round( imageHeight - frameHeight );
					timing      = Math.round( imageHeight / frameHeight ) * 2;

					if ( horizontal ) {
						delta = Math.round( imageWidth - frameWidth );
						timing = Math.round( imageWidth / frameWidth ) * 2;

						if ( imageWidth > frameWidth ) {
							scrollable = true;
						}
					} else {
						delta = Math.round( imageHeight - frameHeight );
						timing = Math.round( imageHeight / frameHeight ) * 2;

						if ( imageHeight > frameHeight ) {
							scrollable = true;
						}
					}
				};

				var initAnimation = () => {
					$imageHolder.on(
						'mouseenter',
						() => {
							if ( scrollable ) {
								$image.css(
									'transition-duration',
									timing + 's'
								);

								if ( horizontal ) {
									$image.css(
										'transform',
										'translate3d(-' + delta + 'px, 0px, 0px)'
									);
								} else {
									$image.css(
										'transform',
										'translate3d(0px, -' + delta + 'px, 0px)'
									);
								}
							}
						}
					);

					$imageHolder.on(
						'mouseleave',
						() => {
							if ( scrollable ) {
								$image.css(
									'transition-duration',
									Math.min(
										timing / 3,
										3
									) + 's'
								);
								$image.css(
									'transform',
									'translate3d(0px, 0px, 0px)'
								);
							}
						}
					);
				};

				$thisHolder.waitForImages(
					() => {
						$thisHolder.css(
							'visibility',
							'visible'
						);
						setSize();
						initAnimation();
					}
				);

				$( window ).resize(
					() => {
						setSize();
					}
				);
			}
		},
		appearAnimation ( $holder ) {
			if ( $holder.hasClass('qodef-wait-for-trigger') ) {
				const randomDelay = Math.floor(Math.random() * 1000) + 1;
				const delay = $holder.data('appearing-delay');

				const interval = setInterval(
					() => {
						if ( qodef.body.hasClass('qodef-spinner--done') ) {
							setTimeout(
								() => {
									$holder.addClass( 'qodef--appeared' );
								}, randomDelay + delay
							);
							clearInterval(interval);
						}
					}, 100
				);
			} else {
				qodefCore.qodefIsInViewport.check(
					$holder,
					() => {
						$holder.addClass( 'qodef--appeared' );
					}
				);
			}
		},
		linkHover ( $holder ) {
			const $link = $holder.find('.qodef-m-image a');

			if ( $link.length ) {
				$link.on(
					'mouseenter',
					() => {
						$holder.addClass('qodef--active');
					}
				);

				$link.on(
					'mouseleave',
					() => {
						$holder.removeClass('qodef--active');
					}
				);
			}
		},
	};

	qodefCore.shortcodes.laurits_core_image_with_text.qodefImageWithText = qodefImageWithText;
	qodefCore.shortcodes.laurits_core_image_with_text.qodefMagnificPopup = qodef.qodefMagnificPopup;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_info_section = {};

	$( document ).ready(
		function () {
			qodefInfoSection.init();
		}
	);

	var qodefInfoSection = {
		init: function () {
			this.holder = $( '.qodef-info-section' );

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						var $holder = $( this ),
							$info   = $holder.find( '.qodef-m-event, .qodef-m-info' ),
							$bottom = $holder.find( '.qodef-m-info-bottom, .qodef-m-event-bottom' );

						$info.css( 'height', 'calc( 100% - ' + $bottom.outerHeight() + 'px )' );

						if ( $holder.hasClass('qodef-appear-animation--yes') ) {
							qodefInfoSection.appearAnimation( $holder );
						}
					}
				);
			}
		},
		appearAnimation ( $holder ) {
			qodefCore.qodefIsInViewport.check(
				$holder,
				() => {
					$holder.addClass('qodef--appeared');
				}
			);
		}
	}

	qodefCore.shortcodes.laurits_core_info_section.qodefInfoSection = qodefInfoSection;

})( jQuery );

(function ( $ ) {
    'use strict';

    qodefCore.shortcodes.laurits_core_section_title = {};

    $( document ).ready(
        () => {
            qodefSectionTitle.init();
        }
    );

    const qodefSectionTitle = {
        init () {
            this.holder = $('.qodef-section-title');

            if ( this.holder.length ) {
                this.holder.each(
                    ( index, element ) => {
                        const $holder = $( element );

                        if ( $holder.hasClass('qodef-appear-animation--yes') ) {
                            qodefSectionTitle.appearAnimation( $holder );
                        }
                    }
                );
            }
        },
        appearAnimation ( $holder ) {
            if ( $holder.hasClass('qodef-wait-for-trigger') ) {
                const interval = setInterval(
                    () => {
                        if ( qodef.body.hasClass('qodef-spinner--done') ) {
                            $holder.addClass( 'qodef--appeared' );
                            clearInterval(interval);
                        }
                    }, 100
                );
            } else {
                qodefCore.qodefIsInViewport.check(
                    $holder,
                    () => {
                        $holder.addClass( 'qodef--appeared' );
                    }
                );
            }
        }
    };

    qodefCore.shortcodes.laurits_core_section_title.qodefSectionTitle = qodefSectionTitle;

})( jQuery );

(function ( $ ) {
	'use strict';
	
	qodefCore.shortcodes.laurits_core_single_image = {};
	
	$( document ).ready(
		function () {
			qodefSingleImageFullHeight.init();
			qodefSingleImage.init();
		}
	);
	
	var qodefSingleImageFullHeight = {
		init: function () {
			this.singleImage = $( '.qodef-single-image.qodef-full-height' );
			
			if ( this.singleImage.length ) {
				this.singleImage.each(
					function () {
						var $image = $( this ).find('.qodef-m-image'),
							$header = $('#qodef-page-header'),
							$headerBorder = $header.find('#qodef-page-header-inner').css('border-bottom-width'),
							$headerHeight = $header.height() - parseFloat($headerBorder),
							$height = 'calc(100vh - ' + $headerHeight + 'px)';
						
						if ( qodef.body.hasClass('qodef-header-appearance--fixed') ) {
							$image.css('height', $height );
						} else {
							$image.css('height', '100vh');
						}
					}
				);
			}
		}
	};

	const qodefSingleImage = {
		init () {
			this.holder = $('.qodef-single-image');

			if ( this.holder.length ) {
				this.holder.each(
					( index, element ) => {
						const $holder = $( element );

						if ( $holder.hasClass('qodef-appear-animation--yes') ) {
							qodefSingleImage.appearAnimation( $holder );
						}
					}
				);
			}
		},
		appearAnimation ( $holder ) {
			qodefCore.qodefIsInViewport.check(
				$holder,
				() => {
					const delay = $holder.data('appearing-delay');

					setTimeout(
						() => {
							$holder.addClass('qodef--appeared');
						}, delay
					);
				}
			);
		}
	};

	qodefCore.shortcodes.laurits_core_single_image.qodefSingleImage           = qodefSingleImage;
	qodefCore.shortcodes.laurits_core_single_image.qodefSingleImageFullHeight = qodefSingleImageFullHeight;
	qodefCore.shortcodes.laurits_core_single_image.qodefMagnificPopup         = qodef.qodefMagnificPopup;

})( jQuery );

(function ( $ ) {
    'use strict';

    qodefCore.shortcodes.laurits_core_social_links = {};

    $( document ).ready(
        () => {
            qodefSocialLinks.init();
        }
    );

    const qodefSocialLinks = {
        init () {
            this.holder = $('.qodef-social-links');

            if ( this.holder.length ) {
                this.holder.each(
                    ( index, element ) => {
                        const $holder = $( element );

                        if ( $holder.hasClass('qodef-appear-animation--yes') ) {
                            qodefSocialLinks.appearAnimation( $holder );
                        }
                    }
                );
            }
        },
        appearAnimation ( $holder ) {
            qodefCore.qodefIsInViewport.check(
                $holder,
                () => {
                    const delay = $holder.data('appearing-delay');

                    setTimeout(
                        () => {
                            $holder.addClass('qodef--appeared');
                        }, delay
                    );
                }
            );
        }
    };

    qodefCore.shortcodes.laurits_core_social_links.qodefSocialLinks = qodefSocialLinks;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_tabs = {};

	$( document ).ready(
		function () {
			qodefTabs.init();
		}
	);

	var qodefTabs = {
		init: function () {
			this.holder = $( '.qodef-tabs' );

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						qodefTabs.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			$currentItem.children( '.qodef-tabs-content' ).each(
				function ( index ) {
					index = index + 1;

					var $that    = $( this ),
						link     = $that.attr( 'id' ),
						$navItem = $that.parent().find( '.qodef-tabs-navigation li:nth-child(' + index + ') a' ),
						navLink  = $navItem.attr( 'href' );

					link = '#' + link;

					if ( link.indexOf( navLink ) > -1 ) {
						$navItem.attr(
							'href',
							link
						);
					}
				}
			);

			$currentItem.addClass( 'qodef--init' ).tabs();
		}
	};

	qodefCore.shortcodes.laurits_core_tabs.qodefTabs = qodefTabs;

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_video_button                    = {};
	qodefCore.shortcodes.laurits_core_video_button.qodefMagnificPopup = qodef.qodefMagnificPopup;

})( jQuery );

(function ( $ ) {
	'use strict';

	$( window ).on(
		'load',
		function () {
			qodefStickySidebar.init();
		}
	);

	var qodefStickySidebar = {
		init: function () {
			var info = $( '.widget_laurits_core_sticky_sidebar' );

			if ( info.length && qodefCore.windowWidth > 1024 ) {
				info.wrapper = info.parents( '#qodef-page-sidebar' );
				info.offsetM = info.offset().top - info.wrapper.offset().top;
				info.adj     = 15;

				qodefStickySidebar.callStack( info );

				$( window ).on(
					'resize',
					function () {
						if ( qodefCore.windowWidth > 1024 ) {
							qodefStickySidebar.callStack( info );
						}
					}
				);

				$( window ).on(
					'scroll',
					function () {
						if ( qodefCore.windowWidth > 1024 ) {
							qodefStickySidebar.infoPosition( info );
						}
					}
				);
			}
		},
		calc: function ( info ) {
			var content = $( '.qodef-page-content-section' ),
				headerH = qodefCore.body.hasClass( 'qodef-header-appearance--none' ) ? 0 : parseInt( qodefGlobal.vars.headerHeight, 10 );

			// If posts not found set content to have the same height as the sidebar
			if ( qodefCore.windowWidth > 1024 && content.height() < 100 ) {
				content.css( 'height', info.wrapper.height() - content.height() );
			}

			info.start = content.offset().top;
			info.end   = content.outerHeight();
			info.h     = info.wrapper.height();
			info.w     = info.outerWidth();
			info.left  = info.offset().left;
			info.top   = headerH + qodefGlobal.vars.adminBarHeight - info.offsetM;
			info.data( 'state', 'top' );
		},
		infoPosition: function ( info ) {
			if ( qodefCore.scroll < info.start - info.top && qodefCore.scroll + info.h && info.data( 'state' ) !== 'top' ) {
				gsap.to(
					info.wrapper,
					.1,
					{
						y: 5,
					}
				);
				gsap.to(
					info.wrapper,
					.3,
					{
						y: 0,
						delay: .1,
					}
				);
				info.data( 'state', 'top' );
				info.wrapper.css(
					{
						'position': 'static',
					}
				);
			} else if ( qodefCore.scroll >= info.start - info.top && qodefCore.scroll + info.h + info.adj <= info.start + info.end &&
				info.data( 'state' ) !== 'fixed' ) {
				var c = info.data( 'state' ) === 'top' ? 1 : -1;
				info.data( 'state', 'fixed' );
				info.wrapper.css(
					{
						'position': 'fixed',
						'top': info.top,
						'left': info.left,
						'width': info.w,
					}
				);
				gsap.fromTo(
					info.wrapper,
					.2,
					{
						y: 0
					},
					{
						y: c * 10,
						ease: Power4.easeInOut
					}
				);
				gsap.to(
					info.wrapper,
					.2,
					{
						y: 0,
						delay: .2,
					}
				);
			} else if ( qodefCore.scroll + info.h + info.adj > info.start + info.end && info.data( 'state' ) !== 'bottom' ) {
				info.data( 'state', 'bottom' );
				info.wrapper.css(
					{
						'position': 'absolute',
						'top': info.end - info.h - info.adj,
						'left': 'auto',
						'width': info.w,
					}
				);
				gsap.fromTo(
					info.wrapper,
					.1,
					{
						y: 0
					},
					{
						y: -5,
					}
				);
				gsap.to(
					info.wrapper,
					.3,
					{
						y: 0,
						delay: .1,
					}
				);
			}
		},
		callStack: function ( info ) {
			this.calc( info );
			this.infoPosition( info );
		}
	};

})( jQuery );

(function ($) {
	'use strict';
	
	var shortcode = 'laurits_core_blog_list';
	
	$(document).on(
		'laurits_trigger_get_new_posts',
		function (e, $holder, response, nextPage) {
			if ($holder.hasClass('qodef-blog')) {
				qodefBlogSortBy.init($holder, response, nextPage);
			}
			qodefBlogListDynamicImage.init();
		}
	);
	
	$(window).on(
		'load',
		function () {
			qodefBlogListDynamicImage.init();
			qodefBlogSortBy.init();
			qodefBlogListRemoveSideBorders.init();
			qodefBlogListAnimation.init();
		}
	);
	
	$(window).on(
		'resize',
		function () {
			qodefBlogListDynamicImage.init();
		}
	);
	
	var qodefBlogListDynamicImage = {
			init: function () {
				this.holder = $('.qodef-blog.qodef-dynaimc-image-height');
				
				if (this.holder.length) {
					this.holder.each(
						function () {
							var $list = $(this),
								items = $list.find('.qodef-blog-item');
							$list.waitForImages(
								function () {
									if (items.length) {
										items.each(
											function () {
												var item = $(this),
													innerHeight = item.find('.qodef-e-content-holder').outerHeight(),
													contentHeight = item.find('.qodef-e-content').outerHeight(),
													image = item.find('.qodef-e-media-image');
												
												if (image.length) {
													image.css('height', innerHeight - contentHeight);
												}
											}
										);
									}
								}
							);
						}
					);
				}
			}
		},
		qodefBlogSortBy = {
			init: function () {
				var $blogList = $('.qodef-blog.qodef-shortcode');
				
				if ($blogList.length) {
					$blogList.each(
						function () {
							var $thisBlogList = $(this),
								$fields = [];
							
							$fields.$orderbyFields = $blogList.find('.qodef-ordering-filter-link');
							$fields.orderbyFieldsExists = $fields.$orderbyFields.length;
							$fields.$categoryFields = $blogList.find('.qodef-m-filter-item');
							$fields.categoryFieldsExists = $fields.$categoryFields.length;
							
							qodefBlogSortBy.initFilter($thisBlogList, $fields);
							
						}
					);
				}
			},
			initFilter: function ($list, $fields) {
				var links = $list.find('.qodef-m-filter-item, .qodef-ordering-filter-link');
				
				links.on(
					'click',
					function (e) {
						e.preventDefault();
						e.stopPropagation();
						
						var clickedLink = $(this);
						if (!clickedLink.hasClass('qodef--active')) {
							
							clickedLink.addClass('qodef--active');
							clickedLink.parent().siblings().find('a').removeClass('qodef--active');
							
							var options = $list.data('options'),
								newOptions = {};
							
							if ($fields.orderbyFieldsExists) {
								$fields.$orderbyFields.each(
									function () {
										if ($(this).hasClass('qodef--active')) {
											var orderKey = 'order_by',
												value = $(this).data('ordering');
											
											if (typeof value !== "undefined" && value !== "") {
												newOptions[orderKey] = value;
											} else {
												newOptions[orderKey] = '';
											}
										}
									}
								);
							}
							
							if ($fields.categoryFieldsExists) {
								$fields.$categoryFields.each(
									function () {
										if ($(this).hasClass('qodef--active')) {
											var categoryKey = $(this).data('taxonomy'),
												value = $(this).data('filter');
											
											if (typeof value !== "undefined" && value !== "" && value !== "*") {
												newOptions[categoryKey] = value;
											} else {
												newOptions[categoryKey] = '';
											}
										}
									}
								);
							}
							
							var additional = qodefBlogSortBy.createAdditionalQuery(newOptions);
							
							$.each(
								additional,
								function (key, value) {
									options[key] = value;
								}
							);
							
							$list.data('options', options);
							
							qodef.body.trigger('laurits_trigger_load_more', [$list, 1]);
							
							qodefBlogListDynamicImage.init();
							
						}
					}
				);
			},
			createAdditionalQuery: function (newOptions) {
				var addQuery = {},
					taxQueryOptions = {},
					categories = $('.qodef-m-filter-item');
				
				addQuery.additional_query_args = {};
				addQuery.additional_query_args.tax_query = [];
				
				if (typeof newOptions === 'object') {
					$.each(
						newOptions,
						function (key, value) {
							
							switch (key) {
								case 'order_by':
									addQuery.orderby = newOptions.order_by;
									break;
								case 'category':
									taxQueryOptions = {
										0: {
											taxonomy: 'category',
											field: typeof value === 'number' ? 'term_id' : 'slug',
											terms: value,
										}
									};
									break;
								case 'post_tag':
									taxQueryOptions = {
										0: {
											taxonomy: 'post_tag',
											field: typeof value === 'number' ? 'term_id' : 'slug',
											terms: value,
										}
									};
							}
						}
					);
					
					if (categories.length && taxQueryOptions[0].terms.length > 0) {
						addQuery.additional_query_args = {
							tax_query: taxQueryOptions,
						};
					}
				}
				
				return addQuery;
			},
		},
		qodefBlogListRemoveSideBorders = {
			init: function () {
				var page = $('#qodef-page-content');
				this.holder = page.find('.qodef-blog.qodef-item-border--yes.qodef-side-border--off');
				
				if (this.holder.length) {
					this.holder.each(
						function () {
							var $list = $(this),
								body = $('body'),
								editor = body.hasClass('elementor-page') ? 'elementor' : 'wp_bakery',
								grid = $list.find('.qodef-grid-inner'),
								backgroundVars = {},
								color = '#fff';
							
							if ('elementor' === editor) {
								backgroundVars.$widgetBackgroundColor = $list.closest('.elementor-widget-container').css('background-color');
								backgroundVars.$columnBackgroundColor = $list.closest('.elementor-column-wrap').css('background-color');
								backgroundVars.$sectionBackgroundColor = $list.closest('section.elementor-element').css('background-color');
								backgroundVars.$pageBackground = body.css('background-color');
							} else {
								backgroundVars.$widgetBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
								backgroundVars.$columnBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
								backgroundVars.$sectionBackgroundColor = $list.closest('.vc_row').css('background-color');
								backgroundVars.$pageBackground = body.css('background-color');
							}
							if ('undefined' !== typeof backgroundVars.$widgetBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$widgetBackgroundColor) {
								color = backgroundVars.$widgetBackgroundColor;
							} else if ('undefined' !== typeof backgroundVars.$columnBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$columnBackgroundColor) {
								color = backgroundVars.$columnBackgroundColor;
							} else if ('undefined' !== typeof backgroundVars.$sectionBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$sectionBackgroundColor) {
								color = backgroundVars.$sectionBackgroundColor;
							} else if ('undefined' !== typeof backgroundVars.$pageBackground && 'rgba(0, 0, 0, 0)' !== backgroundVars.$pageBackground) {
								color = backgroundVars.$pageBackground;
							}
							
							grid.css('color', color);
						}
					);
				}
			}
		},
		qodefBlogListAnimation = {
			init () {
				this.blog = $('.qodef-blog');

				if ( this.blog.length ) {
					this.blog.each(
						( index, element ) => {
							const $thisBlogList = $( element );

							if ( $thisBlogList.hasClass('qodef-hover-animation--yes') ) {
								qodefBlogListAnimation.linkHover( $thisBlogList );
							}

							if ( $thisBlogList.hasClass('qodef-appear-animation--yes') ) {
								qodefBlogListAnimation.appearAnimation( $thisBlogList );
							}
						}
					);
				}
			},
			linkHover ( $holder ) {
				const $items = $holder.find('.qodef-blog-item');

				$items.each(
					( index, element ) => {
						const $thisItem = $( element ),
							$itemMedia = $thisItem.find('.qodef-e-media-image'),
							$titleLink = $thisItem.find('.qodef-e-title-link');

						if ( $itemMedia.length ) {
							$itemMedia.on(
								'mouseenter',
								() => {
									$thisItem.addClass('qodef--active');
								}
							);

							$itemMedia.on(
								'mouseleave',
								() => {
									$thisItem.removeClass('qodef--active');
								}
							);
						}

						if ( $titleLink.length ) {
							$titleLink.on(
								'mouseenter',
								() => {
									$thisItem.addClass('qodef--active');
								}
							);

							$titleLink.on(
								'mouseleave',
								() => {
									$thisItem.removeClass('qodef--active');
								}
							);
						}
					}
				);
			},
			appearAnimation ( $holder ) {
				const delay = $holder.data('appearing-delay');
				qodefCore.qodefIsInViewport.check(
					$holder,
					() => {
						const $items = $holder.find('.qodef-e');
						$holder.addClass('qodef--appeared');

						if ( $items.length ) {
							$items.each(
								( index, element ) => {
									const $thisItem = $( element );

									if ( $holder.hasClass('qodef-filter--on') ) {
										setTimeout(
											() => {
												$thisItem.addClass('qodef--appeared');
											}, index * 160 + 180 + delay
										);
									} else {
										setTimeout(
											() => {
												$thisItem.addClass('qodef--appeared');
											}, index * 160 + delay
										);
									}

									if ( $thisItem.hasClass('qodef-parallax-effect--yes') ) {
										$thisItem.attr(
											'data-parallax',
											'{"y": -80, "smoothness": 100}'
										);

										qodefPortfolioAnimationEffects.initItems();
									}
								}
							)
						}
					}
				);
			}
		};
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(
			qodefCore.listShortcodesScripts,
			function (key, value) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}
	
	qodefCore.shortcodes[shortcode].qodefResizeIframes = qodef.qodefResizeIframes;
	qodefCore.shortcodes[shortcode].qodefBlogListDynamicImage = qodefBlogListDynamicImage;
	qodefCore.shortcodes[shortcode].qodefBlogSortBy = qodefBlogSortBy;
	qodefCore.shortcodes[shortcode].qodefBlogListRemoveSideBorders = qodefBlogListRemoveSideBorders;
	
})(jQuery);

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefTabbedNavMenu.init();
		}
	);

	var qodefTabbedNavMenu = {

		init: function () {
				var $holder = $( '.qodef-header--tabbed #qodef-page-header' );

			if ( $holder.length ) {
				$holder.each(
					function () {
						qodefTabbedNavMenu.initItem( $( this ) );
					}
				);
			}
		},

		initItem: function ( $currentHeader ) {
			var $logo 	  = $currentHeader.find( '#qodef-page-header-inner .qodef-header-logo-link' );
			var $menuItem = $currentHeader.find( '#qodef-page-header-inner .qodef-header-navigation > ul > li' );
			var $widget   = $currentHeader.find( '#qodef-page-header-inner .qodef-widget-holder .widget' );
			var $width 	  = $( window ).width();

			var $headerItems = $logo.add( $menuItem ).add( $widget );

			$headerItems.css( 'width', 'calc( ' + $width / ( $logo.length + $menuItem.length + $widget.length ) + 'px )' );
		},

	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefVerticalSlidingNavMenu.init();
		}
	);

	/**
	 * Function object that represents vertical menu area.
	 * @returns {{init: Function}}
	 */
	var qodefVerticalSlidingNavMenu = {
		openedScroll: 0,

		initNavigation: function ( $verticalSlidingMenuObject ) {
			var $verticalSlidingNavObject = $verticalSlidingMenuObject.find( '.qodef-header-vertical-sliding-navigation' );

			if ( $verticalSlidingNavObject.hasClass( 'qodef-vertical-sliding-drop-down--below' ) ) {
				qodefVerticalSlidingNavMenu.dropdownClickToggle( $verticalSlidingNavObject );
			} else if ( $verticalSlidingNavObject.hasClass( 'qodef-vertical-sliding-drop-down--side' ) ) {
				qodefVerticalSlidingNavMenu.dropdownFloat( $verticalSlidingNavObject );
			}
		},
		dropdownClickToggle: function ( $verticalSlidingNavObject ) {
			var $menuItems = $verticalSlidingNavObject.find( 'ul li.menu-item-has-children' );

			$menuItems.each(
				function () {
					var $elementToExpand = $( this ).find( ' > .qodef-drop-down-second, > ul' );
					var menuItem         = this;
					var $dropdownOpener  = $( this ).find( '> a' );
					var slideUpSpeed     = 'fast';
					var slideDownSpeed   = 'slow';

					$dropdownOpener.on(
						'click tap',
						function ( e ) {
							e.preventDefault();
							e.stopPropagation();

							if ( $elementToExpand.is( ':visible' ) ) {
								$( menuItem ).removeClass( 'qodef-menu-item--open' );
								$elementToExpand.slideUp( slideUpSpeed );
							} else if ( $dropdownOpener.parent().parent().children().hasClass( 'qodef-menu-item--open' ) && $dropdownOpener.parent().parent().parent().hasClass( 'qodef-vertical-menu' ) ) {
								$( this ).parent().parent().children().removeClass( 'qodef-menu-item--open' );
								$( this ).parent().parent().children().find( ' > .qodef-drop-down-second' ).slideUp( slideUpSpeed );

								$( menuItem ).addClass( 'qodef-menu-item--open' );
								$elementToExpand.slideDown( slideDownSpeed );
							} else {

								if ( ! $( this ).parents( 'li' ).hasClass( 'qodef-menu-item--open' ) ) {
									$menuItems.removeClass( 'qodef-menu-item--open' );
									$menuItems.find( ' > .qodef-drop-down-second, > ul' ).slideUp( slideUpSpeed );
								}

								if ( $( this ).parent().parent().children().hasClass( 'qodef-menu-item--open' ) ) {
									$( this ).parent().parent().children().removeClass( 'qodef-menu-item--open' );
									$( this ).parent().parent().children().find( ' > .qodef-drop-down-second, > ul' ).slideUp( slideUpSpeed );
								}

								$( menuItem ).addClass( 'qodef-menu-item--open' );
								$elementToExpand.slideDown( slideDownSpeed );
							}
						}
					);
				}
			);
		},
		dropdownFloat: function ( $verticalSlidingNavObject ) {
			var $menuItems    = $verticalSlidingNavObject.find( 'ul li.menu-item-has-children' );
			var $allDropdowns = $menuItems.find( ' > .qodef-drop-down-second > .qodef-drop-down-second-inner > ul, > ul' );

			$menuItems.each(
				function () {
					var $elementToExpand = $( this ).find( ' > .qodef-drop-down-second > .qodef-drop-down-second-inner > ul, > ul' );
					var menuItem         = this;

					if ( Modernizr.touch ) {
						var $dropdownOpener = $( this ).find( '> a' );

						$dropdownOpener.on(
							'click tap',
							function ( e ) {
								e.preventDefault();
								e.stopPropagation();

								if ( $elementToExpand.hasClass( 'qodef-float--open' ) ) {
									$elementToExpand.removeClass( 'qodef-float--open' );
									$( menuItem ).removeClass( 'qodef-menu-item--open' );
								} else {
									if ( ! $( this ).parents( 'li' ).hasClass( 'qodef-menu-item--open' ) ) {
										$menuItems.removeClass( 'qodef-menu-item--open' );
										$allDropdowns.removeClass( 'qodef-float--open' );
									}

									$elementToExpand.addClass( 'qodef-float--open' );
									$( menuItem ).addClass( 'qodef-menu-item--open' );
								}
							}
						);
					} else {
						//must use hoverIntent because basic hover effect doesn't catch dropdown
						//it doesn't start from menu item's edge
						$( this ).hoverIntent(
							{
								over: function () {
									$elementToExpand.addClass( 'qodef-float--open' );
									$( menuItem ).addClass( 'qodef-menu-item--open' );
								},
								out: function () {
									$elementToExpand.removeClass( 'qodef-float--open' );
									$( menuItem ).removeClass( 'qodef-menu-item--open' );
								},
								timeout: 300
							}
						);
					}
				}
			);
		},
		verticalSlidingAreaScrollable: function ( $verticalSlidingMenuObject ) {
			return $verticalSlidingMenuObject.hasClass( 'qodef-with-scroll' );
		},
		initVerticalSlidingAreaScroll: function ( $verticalSlidingMenuObject ) {
			if ( qodefVerticalSlidingNavMenu.verticalSlidingAreaScrollable( $verticalSlidingMenuObject ) && typeof qodefCore.qodefPerfectScrollbar === 'object' ) {
				qodefCore.qodefPerfectScrollbar.init( $verticalSlidingMenuObject );
			}
		},
		verticalSlidingAreaShowHide: function ( $verticalSlidingMenuObject ) {
			var $verticalSlidingMenuOpener = $verticalSlidingMenuObject.find( '.qodef-vertical-sliding-menu-opener' );
			var $wrapper                   = $( '#qodef-page-wrapper' );


			$verticalSlidingMenuOpener.on(
				'click',
				function ( e ) {
					e.preventDefault();

					if ( ! $verticalSlidingMenuObject.hasClass( 'qodef-vertical-sliding-menu--opened' ) ) {
						$verticalSlidingMenuObject.addClass( 'qodef-vertical-sliding-menu--opened' );
						qodefVerticalSlidingNavMenu.openedScroll = qodef.window.scrollTop();
					} else {
						$verticalSlidingMenuObject.removeClass( 'qodef-vertical-sliding-menu--opened' );
					}
					if ( ! qodefCore.body.hasClass( 'qodef-vertical-sliding--opened' ) ) {
						qodefCore.body.addClass( 'qodef-vertical-sliding--opened' );
					} else {
						qodefCore.body.removeClass( 'qodef-vertical-sliding--opened' );
					}
				}
			);

			$( '.qodef-vertical-sliding-cover' ).remove();
			$wrapper.prepend( '<div class="qodef-vertical-sliding-cover"/>' );

		},
		verticalSlidingAreaCloseOnScroll: function ( $verticalSlidingMenuObject ) {
			qodef.window.on(
				'scroll',
				function () {
					if ( $verticalSlidingMenuObject.hasClass( 'qodef-vertical-sliding-menu--opened' ) && Math.abs( qodef.scroll - qodefVerticalSlidingNavMenu.openedScroll ) > 400 ) {
						$verticalSlidingMenuObject.removeClass( 'qodef-vertical-sliding-menu--opened' );
					}
				}
			);
		},
		init: function () {
			var $verticalSlidingMenuObject = $( '.qodef-header--vertical-sliding #qodef-page-header' );

			if ( $verticalSlidingMenuObject.length ) {
				qodefVerticalSlidingNavMenu.verticalSlidingAreaShowHide( $verticalSlidingMenuObject );
				qodefVerticalSlidingNavMenu.verticalSlidingAreaCloseOnScroll( $verticalSlidingMenuObject );
				qodefVerticalSlidingNavMenu.initNavigation( $verticalSlidingMenuObject );
				qodefVerticalSlidingNavMenu.initVerticalSlidingAreaScroll( $verticalSlidingMenuObject );
			}
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	var fixedHeaderAppearance = {
		showHideHeader: function ( $pageOuter, $header ) {
			if ( qodefCore.windowWidth > 1024 ) {
				if ( qodefCore.scroll <= 0 ) {
					qodefCore.body.removeClass( 'qodef-header--fixed-display' );
					$pageOuter.css( 'padding-top', '0' );
					$header.css( 'margin-top', '0' );
				} else {
					qodefCore.body.addClass( 'qodef-header--fixed-display' );
					if ( ! qodefCore.body.hasClass( 'qodef-header-fixed-from-start' ) ) {
						$pageOuter.css( 'padding-top', parseInt( qodefGlobal.vars.headerHeight + qodefGlobal.vars.topAreaHeight ) + 'px' );
						$header.css( 'margin-top', parseInt( qodefGlobal.vars.topAreaHeight ) + 'px' );
					}
				}
			}
		},
		init: function () {

			if ( ! qodefCore.body.hasClass( 'qodef-header--vertical' ) ) {
				var $pageOuter = $( '#qodef-page-outer' ),
					$header    = $( '#qodef-page-header' );

				fixedHeaderAppearance.showHideHeader( $pageOuter, $header );

				$( window ).scroll(
					function () {
						fixedHeaderAppearance.showHideHeader( $pageOuter, $header );
					}
				);

				$( window ).resize(
					function () {
						$pageOuter.css( 'padding-top', '0' );
						fixedHeaderAppearance.showHideHeader( $pageOuter, $header );
					}
				);
			}
		}
	};

	qodefCore.fixedHeaderAppearance = fixedHeaderAppearance.init;

})( jQuery );

(function ( $ ) {
	'use strict';

	var stickyHeaderAppearance = {
		header: '',
		docYScroll: 0,
		init: function () {
			var displayAmount = stickyHeaderAppearance.displayAmount();

			// Set variables
			stickyHeaderAppearance.header 	  = $( '.qodef-header-sticky' );
			stickyHeaderAppearance.docYScroll = $( document ).scrollTop();

			// Set sticky visibility
			stickyHeaderAppearance.setVisibility( displayAmount );

			$( window ).scroll(
				function () {
					stickyHeaderAppearance.setVisibility( displayAmount );
				}
			);
		},
		displayAmount: function () {
			if ( qodefGlobal.vars.qodefStickyHeaderScrollAmount !== 0 ) {
				return parseInt( qodefGlobal.vars.qodefStickyHeaderScrollAmount, 10 );
			} else {
				return parseInt( qodefGlobal.vars.headerHeight + qodefGlobal.vars.adminBarHeight, 10 );
			}
		},
		setVisibility: function ( displayAmount ) {
			var isStickyHidden = qodefCore.scroll < displayAmount;

			if ( stickyHeaderAppearance.header.hasClass( 'qodef-appearance--up' ) ) {
				var currentDocYScroll = $( document ).scrollTop();

				isStickyHidden = (currentDocYScroll > stickyHeaderAppearance.docYScroll && currentDocYScroll > displayAmount) || (currentDocYScroll < displayAmount);

				stickyHeaderAppearance.docYScroll = $( document ).scrollTop();
			}

			stickyHeaderAppearance.showHideHeader( isStickyHidden );
		},
		showHideHeader: function ( isStickyHidden ) {
			if ( isStickyHidden ) {
				qodefCore.body.removeClass( 'qodef-header--sticky-display' );
			} else {
				qodefCore.body.addClass( 'qodef-header--sticky-display' );
			}
		},
	};

	qodefCore.stickyHeaderAppearance = stickyHeaderAppearance.init;

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefSideAreaMobileHeader.init();
		}
	);

	var qodefSideAreaMobileHeader = {
		init: function () {
			var $holder = $( '#qodef-side-area-mobile-header' );

			if ( $holder.length && qodefCore.body.hasClass( 'qodef-mobile-header--side-area' ) ) {
				var $navigation = $holder.find( '.qodef-m-navigation' );

				qodefSideAreaMobileHeader.initOpenerTrigger( $holder, $navigation );
				qodefSideAreaMobileHeader.initNavigationClickToggle( $navigation );

				if ( typeof qodefCore.qodefPerfectScrollbar === 'object' ) {
					qodefCore.qodefPerfectScrollbar.init( $holder );
				}
			}
		},
		initOpenerTrigger: function ( $holder, $navigation ) {
			var $openerIcon = $( '.qodef-side-area-mobile-header-opener' ),
				$closeIcon  = $holder.children( '.qodef-m-close' );

			if ( $openerIcon.length && $navigation.length ) {
				$openerIcon.on(
					'tap click',
					function ( e ) {
						e.stopPropagation();
						e.preventDefault();

						if ( $holder.hasClass( 'qodef--opened' ) ) {
							$holder.removeClass( 'qodef--opened' );
						} else {
							$holder.addClass( 'qodef--opened' );
						}
					}
				);
			}

			$closeIcon.on(
				'tap click',
				function ( e ) {
					e.stopPropagation();
					e.preventDefault();

					if ( $holder.hasClass( 'qodef--opened' ) ) {
						$holder.removeClass( 'qodef--opened' );
					}
				}
			);
		},
		initNavigationClickToggle: function ( $navigation ) {
			var $menuItems = $navigation.find( 'ul li.menu-item-has-children' );

			$menuItems.each(
				function () {
					var $thisItem        = $( this ),
						$elementToExpand = $thisItem.find( ' > .qodef-drop-down-second, > ul' ),
						$dropdownOpener  = $thisItem.find( '> .qodef-menu-item-arrow' ),
						slideUpSpeed     = 'fast',
						slideDownSpeed   = 'slow';

					$dropdownOpener.on(
						'click tap',
						function ( e ) {
							e.preventDefault();
							e.stopPropagation();

							if ( $elementToExpand.is( ':visible' ) ) {
								$thisItem.removeClass( 'qodef-menu-item--open' );
								$elementToExpand.slideUp( slideUpSpeed );
							} else if ( $dropdownOpener.parent().parent().children().hasClass( 'qodef-menu-item--open' ) && $dropdownOpener.parent().parent().parent().hasClass( 'qodef-vertical-menu' ) ) {
								$thisItem.parent().parent().children().removeClass( 'qodef-menu-item--open' );
								$thisItem.parent().parent().children().find( ' > .qodef-drop-down-second' ).slideUp( slideUpSpeed );

								$thisItem.addClass( 'qodef-menu-item--open' );
								$elementToExpand.slideDown( slideDownSpeed );
							} else {

								if ( ! $thisItem.parents( 'li' ).hasClass( 'qodef-menu-item--open' ) ) {
									$menuItems.removeClass( 'qodef-menu-item--open' );
									$menuItems.find( ' > .qodef-drop-down-second, > ul' ).slideUp( slideUpSpeed );
								}

								if ( $thisItem.parent().parent().children().hasClass( 'qodef-menu-item--open' ) ) {
									$thisItem.parent().parent().children().removeClass( 'qodef-menu-item--open' );
									$thisItem.parent().parent().children().find( ' > .qodef-drop-down-second, > ul' ).slideUp( slideUpSpeed );
								}

								$thisItem.addClass( 'qodef-menu-item--open' );
								$elementToExpand.slideDown( slideDownSpeed );
							}
						}
					);
				}
			);
		},
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefSearchFullscreen.init();
		}
	);

	var qodefSearchFullscreen = {
		init: function () {
			var $searchOpener = $( 'a.qodef-search-opener' ),
				$searchHolder = $( '.qodef-fullscreen-search-holder' ),
				$searchClose  = $searchHolder.find( '.qodef-m-close' );

			if ( $searchOpener.length && $searchHolder.length ) {
				$searchOpener.on(
					'click',
					function ( e ) {
						console.log('kliknuo');
						e.preventDefault();
						if ( qodefCore.body.hasClass( 'qodef-fullscreen-search--opened' ) ) {
							qodefSearchFullscreen.closeFullscreen( $searchHolder );
						} else {
							qodefSearchFullscreen.openFullscreen( $searchHolder );
						}
					}
				);
				$searchClose.on(
					'click',
					function ( e ) {
						e.preventDefault();
						qodefSearchFullscreen.closeFullscreen( $searchHolder );
					}
				);

				//Close on escape
				$( document ).keyup(
					function ( e ) {
						if ( e.keyCode === 27 && qodefCore.body.hasClass( 'qodef-fullscreen-search--opened' ) ) { //KeyCode for ESC button is 27
							qodefSearchFullscreen.closeFullscreen( $searchHolder );
						}
					}
				);
			}
		},
		openFullscreen: function ( $searchHolder ) {
			qodefCore.body.removeClass( 'qodef-fullscreen-search--fadeout' );
			qodefCore.body.addClass( 'qodef-fullscreen-search--opened qodef-fullscreen-search--fadein' );

			setTimeout(
				function () {
					$searchHolder.find( '.qodef-m-form-field' ).focus();
				},
				900
			);

			qodefCore.qodefScroll.disable();
		},
		closeFullscreen: function ( $searchHolder ) {
			qodefCore.body.removeClass( 'qodef-fullscreen-search--opened qodef-fullscreen-search--fadein' );
			qodefCore.body.addClass( 'qodef-fullscreen-search--fadeout' );

			setTimeout(
				function () {
					$searchHolder.find( '.qodef-m-form-field' ).val( '' );
					$searchHolder.find( '.qodef-m-form-field' ).blur();
					qodefCore.body.removeClass( 'qodef-fullscreen-search--fadeout' );
				},
				300
			);

			qodefCore.qodefScroll.enable();
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefSearch.init();
		}
	);

	var qodefSearch = {
		init: function () {
			this.search = $( 'a.qodef-search-opener' );

			if ( this.search.length ) {
				this.search.each(
					function () {
						var $thisSearch = $( this );

						qodefSearch.searchHoverColor( $thisSearch );
					}
				);
			}
		},
		searchHoverColor: function ( $searchHolder ) {
			if ( typeof $searchHolder.data( 'hover-color' ) !== 'undefined' ) {
				var hoverColor    = $searchHolder.data( 'hover-color' ),
					originalColor = $searchHolder.css( 'color' );

				$searchHolder.on(
					'mouseenter',
					function () {
						$searchHolder.css( 'color', hoverColor );
					}
				).on(
					'mouseleave',
					function () {
						$searchHolder.css( 'color', originalColor );
					}
				);
			}
		}
	};

})( jQuery );

(function ($) {
    "use strict";

    $( document ).ready(
        () => {
            qodefLauritsSpinner.init();
        }
    );

    $( window ).on(
        'load',
        () => {
            qodefLauritsSpinner.windowLoaded = true;
        }
    );

    $( window ).on(
        'elementor/frontend/init',
        () => {
            const isEditMode = Boolean( elementorFrontend.isEditMode() );

            if ( isEditMode ) {
                qodefLauritsSpinner.init( isEditMode );
            }
        }
    );

    var qodefLauritsSpinner = {
        init ( isEditMode ) {
            const $holder = $('#qodef-page-spinner.qodef-layout--laurits');

            if ( $holder.length ) {
                if ( isEditMode ) {
                    qodefLauritsSpinner.fadeOutLoader( $holder );
                } else {
                    qodefLauritsSpinner.animateSpinner( $holder );
                    qodefCore.qodefScroll.disable();
                }
            }
        },
        animateSpinner ( $holder ) {
            const $shapes = $holder.find('.qodef-m-shapes');
            let   qodefLauritsSpinnerInterval,
                  animationInterval;

            if ( $shapes.length ) {
                $shapes.each(
                    ( index, element ) => {
                        const $thisSet = $( element );

                        $thisSet.find('.qodef-m-shape:first-child').addClass('qodef--active');

                        const initAnimation = () => {
                            animationInterval = setInterval(
                                () => {
                                    const $currentItem = $thisSet.find('.qodef--active').removeClass('qodef--active'),
                                          $nextItem    = $currentItem.next().length ? $currentItem.next() : $thisSet.children().eq(0);

                                    $nextItem.addClass('qodef--active');
                                }, 1600
                            );
                        }

                        initAnimation();

                        qodefLauritsSpinnerInterval = setInterval(
                            () => {
                                if ( qodefLauritsSpinner.windowLoaded ) {
                                    clearInterval(qodefLauritsSpinnerInterval);
                                    setTimeout(
                                        () => {
                                            qodefLauritsSpinner.fadeOutLoader( $holder, 800, 0 );
                                            setTimeout(
                                                () => {
                                                    clearInterval(animationInterval);
                                                    qodef.body.addClass( 'qodef-spinner--done' );
                                                    qodefCore.qodefScroll.enable();
                                                }, 300
                                            );
                                        }, 5800
                                    );
                                }
                            }, 100
                        );
                    }
                );
            }
        },
        fadeOutLoader ( $holder, speed, delay, easing ) {
            speed = speed ? speed : 500;
            delay = delay ? delay : 0;
            easing = easing ? easing : 'swing';

            if ( $holder.length ) {
                $holder.delay(delay).fadeOut(speed, easing);

                $(window).on(
                    'bind', 'pageshow',
                    ( event ) => {
                        if ( event.originalEvent.persisted ) {
                            $holder.fadeOut(speed, easing);
                        }
                    }
                );
            }
        }
    };

})(jQuery);
(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefProgressBarSpinner.init();
		}
	);

	$( window ).on(
		'load',
		function () {
			qodefProgressBarSpinner.windowLoaded = true;
			qodefProgressBarSpinner.completeAnimation();
		}
	);

	$( window ).on(
		'elementor/frontend/init',
		function () {
			var isEditMode = Boolean( elementorFrontend.isEditMode() );

			if ( isEditMode ) {
				qodefProgressBarSpinner.init( isEditMode );
			}
		}
	);

	var qodefProgressBarSpinner = {
		holder: '',
		windowLoaded: false,
		percentNumber: 0,
		init: function ( isEditMode ) {
			this.holder = $( '#qodef-page-spinner.qodef-layout--progress-bar' );

			if ( this.holder.length ) {
				qodefProgressBarSpinner.animateSpinner( this.holder, isEditMode );
			}
		},
		animateSpinner: function ( $holder, isEditMode ) {
			var $numberHolder = $holder.find( '.qodef-m-spinner-number-label' ),
				$spinnerLine  = $holder.find( '.qodef-m-spinner-line-front' );

			$spinnerLine.animate(
				{ 'width': '100%' },
				10000,
				'linear'
			);

			var numberInterval = setInterval(
				function () {
					qodefProgressBarSpinner.animatePercent( $numberHolder, qodefProgressBarSpinner.percentNumber );

					if ( qodefProgressBarSpinner.windowLoaded ) {
						clearInterval( numberInterval );
					}
				},
				100
			);

			if ( isEditMode ) {
				qodefProgressBarSpinner.fadeOutLoader( $holder );
			}
		},
		completeAnimation: function () {
			var $holder = qodefProgressBarSpinner.holder.length ? qodefProgressBarSpinner.holder : $( '#qodef-page-spinner.qodef-layout--progress-bar' );

			var numberIntervalFastest = setInterval(
				function () {

					if ( qodefProgressBarSpinner.percentNumber >= 100 ) {
						clearInterval( numberIntervalFastest );

						$holder.find( '.qodef-m-spinner-line-front' ).stop().animate(
							{ 'width': '100%' },
							500
						);

						$holder.addClass( 'qodef--finished' );

						setTimeout(
							function () {
								qodefProgressBarSpinner.fadeOutLoader( $holder );
							},
							600
						);
					} else {
						qodefProgressBarSpinner.animatePercent(
							$holder.find( '.qodef-m-spinner-number-label' ),
							qodefProgressBarSpinner.percentNumber
						);
					}
				},
				6
			);
		},
		animatePercent: function ( $numberHolder, percentNumber ) {
			if ( percentNumber < 100 ) {
				percentNumber += 5;
				$numberHolder.text( percentNumber );

				qodefProgressBarSpinner.percentNumber = percentNumber;
			}
		},
		fadeOutLoader: function ( $holder, speed, delay, easing ) {
			speed  = speed ? speed : 600;
			delay  = delay ? delay : 0;
			easing = easing ? easing : 'swing';

			$holder.delay( delay ).fadeOut( speed, easing );

			$( window ).on(
				'bind',
				'pageshow',
				function ( event ) {
					if ( event.originalEvent.persisted ) {
						$holder.fadeOut( speed, easing );
					}
				}
			);
		}
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_instagram_list = {};

	$( document ).ready(
		function () {
			qodefInstagram.init();
		}
	);

	var qodefInstagram = {
		init: function () {
			this.holder = $( '.sbi.qodef-instagram-swiper-container' );

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						qodefInstagram.initSlider( $( this ) );
					}
				);
			}
		},
		initSlider: function ( $currentItem, $initAllItems ) {
			var sliderOptions   = $currentItem.parent().attr( 'data-options' ),
				$instagramImage = $currentItem.find( '.sbi_item.sbi_type_image' ),
				$imageHolder    = $currentItem.find( '#sbi_images' );

			$currentItem.attr( 'data-options', sliderOptions );

			$imageHolder.addClass( 'swiper-wrapper' );

			if ( $instagramImage.length ) {
				$instagramImage.each(
					function () {
						$( this ).addClass( 'qodef-e qodef-image-wrapper swiper-slide' );
					}
				);
			}

			if ( typeof qodef.qodefSwiper === 'object' ) {

				if ( false === $initAllItems ) {
					qodef.qodefSwiper.initSlider( $currentItem );
				} else {
					qodef.qodefSwiper.init( $currentItem );
				}
			}
		},
	};

	qodefCore.shortcodes.laurits_core_instagram_list.qodefInstagram = qodefInstagram;
	qodefCore.shortcodes.laurits_core_instagram_list.qodefSwiper    = qodef.qodefSwiper;

})( jQuery );

(function ( $ ) {
	'use strict';

	var shortcode = 'laurits_core_product_list';

	$( document ).on(
		'laurits_trigger_get_new_posts',
		function ( e, $holder, response, nextPage ) {
			if ( $holder.hasClass( 'qodef-woo-product-list' ) ) {
				qodefSortBy.init( $holder, response, nextPage );
				qodef.qodefWooDefaultProductHeight.init();
			}
		}
	);

	var qodefSortBy = {
		init: function () {
			var $productList = $( '.qodef-woo-product-list' );

			if ( $productList.length ) {
				$productList.each(
					function () {
						var $thisProductList = $( this ),
							$fields 		 = [];

						$fields.$orderbyFields 		 = $productList.find( '.qodef-ordering-filter-link' );
						$fields.orderbyFieldsExists  = $fields.$orderbyFields.length;
						$fields.$categoryFields 	 = $productList.find( '.qodef-m-filter-item' );
						$fields.categoryFieldsExists = $fields.$categoryFields.length;

						qodefSortBy.initFilter( $thisProductList, $fields );
					}
				);
			}
		},
		initFilter: function( $list, $fields ) {
			var links = $list.find( '.qodef-m-filter-item, .qodef-ordering-filter-link' );

			links.on(
				'click',
				function(e) {
					e.preventDefault();
					e.stopPropagation();

					var clickedLink = $( this );
					if ( ! clickedLink.hasClass( 'qodef--active' ) ) {

						clickedLink.addClass( 'qodef--active' );
						clickedLink.parent().siblings().find( 'a' ).removeClass( 'qodef--active' );

						var options    = $list.data( 'options' ),
							newOptions = {};

						if ($fields.orderbyFieldsExists) {
							$fields.$orderbyFields.each(
								function () {
									if ( $( this ).hasClass( 'qodef--active' ) ) {
										var orderKey = 'order_by',
											value 	 = $( this ).data( 'ordering' );

										if (typeof value !== "undefined" && value !== "") {
											newOptions[orderKey] = value;
										} else {
											newOptions[orderKey] = '';
										}
									}
								}
							);
						}

						if ($fields.categoryFieldsExists) {
							$fields.$categoryFields.each(
								function () {
									if ( $( this ).hasClass( 'qodef--active' ) ) {
										var categoryKey = 'category',
											value 		= $( this ).data( 'filter' );

										if (typeof value !== "undefined" && value !== "" && value !== "*") {
											newOptions[categoryKey] = value;
										} else {
											newOptions[categoryKey] = '';
										}
									}
								}
							);
						}

						var additional = qodefSortBy.createAdditionalQuery( newOptions );

						$.each(
							additional,
							function ( key, value ) {
								options[key] = value;
							}
						);

						$list.data( 'options',options );

						qodef.body.trigger( 'laurits_trigger_load_more', [$list, 1] );

					}
				}
			);
		},
		createAdditionalQuery: function( newOptions ){
			var addQuery 		= {},
				taxQueryOptions = {},
				categories 		= $( '.qodef-m-filter-item' );

			addQuery.additional_query_args 			 = {};
			addQuery.additional_query_args.tax_query = [];

			if (typeof newOptions === 'object') {
				$.each(
					newOptions,
					function (key, value) {

						switch (key) {
							case 'order_by':
								addQuery.orderby = newOptions.order_by;
								break;
							case 'category':
								taxQueryOptions = {
									0: {
										taxonomy: 'product_cat',
										field: typeof value === 'number' ? 'term_id' : 'slug',
										terms: value,
									}
								};
						}
					}
				);

				if ( categories.length && taxQueryOptions[0].terms.length > 0 ) {
					addQuery.additional_query_args = {
						tax_query: taxQueryOptions,
					};
				}
			}

			return addQuery;
		},
	};

	qodefCore.shortcodes[shortcode] 					         = {};
	qodefCore.shortcodes[shortcode].qodefSortBy 		         = qodefSortBy;
	qodefCore.shortcodes[shortcode].qodefWooDefaultProductHeight = qodef.qodefWooDefaultProductHeight;

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}
	
})( jQuery );

(function ( $ ) {
	'use strict';

	/*
	 **	Re-init scripts on gallery loaded
	 */
	$( document ).on(
		'yith_wccl_product_gallery_loaded',
		function () {

			if ( typeof qodefCore.qodefWooMagnificPopup === 'function' ) {
				qodefCore.qodefWooMagnificPopup.init();
			}
		}
	);

})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefDropDownCart.init();
		}
	);

	var qodefDropDownCart = {
		init: function () {
			var $holder = $( '.qodef-woo-dropdown-cart' );

			if ( $holder.length ) {
				$holder.each(
					function () {
						var $thisHolder = $( this ),
							$items      = $thisHolder.find( '.qodef-woo-dropdown-items' );

						qodefDropDownCart.addItemsClass( $items );

						qodefCore.body.on(
							'added_to_cart',
							function () {
								qodefDropDownCart.addItemsClass( $thisHolder.find( '.qodef-woo-dropdown-items' ) );
							}
						);
					}
				);
			}
		},
		addItemsClass: function ( $items ) {
			if ( $items.length && $items.children().length > 4 ) {
				$items.addClass( 'qodef--scrollable' );
			} else if ( $items.hasClass( 'qodef--scrollable' ) ) {
				$items.removeClass( 'qodef--scrollable' );
			}
		},
	};

})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_clients_list             = {};
	qodefCore.shortcodes.laurits_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );

(function ( $ ) {
	'use strict';
	
	
	$( document ).ready(
		function () {
			qodefClientsShowcase.init();
		}
	);
	
	$( window ).resize(
		function () {
			qodefClientsShowcase.resize();
		}
	);
	
	var qodefClientsShowcase = {
		init: function () {
			var $holder = $('.qodef-clients-showcase');
			
			if ($holder.length) {
				$holder.each(function () {
					var thisHolder = $(this),
						articles = thisHolder.find('article'),
						articlesImages = thisHolder.find('.qodef-e-image-holder .qodef-e-image'),
						showcaseInfo = thisHolder.find('.qodef-e-top-info'),
						itemsList = thisHolder.find('.qodef-e-items-list'),
						imagesList = thisHolder.find('.qodef-e-image-holder');
					
					articles.eq(0).addClass('qodef--hover');
					articlesImages.eq(0).addClass('qodef--hover');
					
					if (showcaseInfo.length) {
						itemsList.css('margin-top', showcaseInfo.height());
					}
					
					if ( qodef.windowWidth <= 1024 && showcaseInfo.length ) {
						imagesList.css('margin-top', showcaseInfo.height());
					}
					
					articles.each(function(e){
						var thisArticle = $(this);
						
						thisArticle.on('mouseover', function () {
							var imageHolder = articlesImages.eq(e);
							
							if (!thisArticle.hasClass('qodef--hover')){
								thisArticle.siblings().removeClass('qodef--hover');
								imageHolder.siblings().removeClass('qodef--hover');
								
								thisArticle.addClass('qodef--hover');
								imageHolder.addClass('qodef--hover');
							}
						});
					});
					
				});
			}
		},
		resize: function () {
			var $holder = $('.qodef-clients-showcase');
			
			if ($holder.length) {
				$holder.each(function () {
					var thisHolder = $(this),
						showcaseInfo = thisHolder.find('.qodef-e-top-info'),
						itemsList = thisHolder.find('.qodef-e-items-list'),
						imagesList = thisHolder.find('.qodef-e-image-holder');
					
					if ( qodef.windowWidth <= 1024 && showcaseInfo.length ) {
						itemsList.css('margin-top', showcaseInfo.outerHeight());
					} else {
						imagesList.css('margincd-top', 0);
					}
					
					if ( qodef.windowWidth <= 768 && showcaseInfo.length ) {
						itemsList.css('margin-top', showcaseInfo.outerHeight());
						imagesList.css('margin-top', showcaseInfo.outerHeight());
					} else {
						imagesList.css('margin-top', 0);
					}
					
					
				});
			}
		},
	};
	
	qodefCore.shortcodes.laurits_core_clients_showcase = {};
	qodefCore.shortcodes.laurits_core_clients_showcase.qodefClientsShowcase = qodefClientsShowcase;
	
})( jQuery );

(function ( $ ) {
	'use strict';

	$(document).ready(function () {
		qodefSliderNav.init();
	});

	var qodefSliderNav = {
		init: function () {
			var $sliderWrapper = $('.qodef-slider-device-display-wrapper');

			if ($sliderWrapper.length) {
				$sliderWrapper.each(function () {
					var holder = $(this),
						slider = holder.find('.qodef-swiper-container'),
						infoLeft = holder.find('#qodef-info-left'),
						infoRight = holder.find('#qodef-info-right');

					if ( slider.hasClass('qodef-swiper--initialized') ) {
						var swiper = slider[0].swiper;
						swiper.autoplay.stop();

						qodefCore.qodefIsInViewport.check(
							slider,
							() => {
								slider.closest('.qodef-slider-device-display-wrapper').addClass('qodef--init');
								if (qodefCore.windowWidth > 1024) {
									qodefSliderNav.navMovement(slider, holder.find('.swiper-button-prev'), holder.find('.swiper-button-next'));
								}
								qodefSliderNav.setInfo(slider, infoLeft, infoRight);
								swiper.autoplay.start();
							}
						);

						swiper.on('slideChangeTransitionStart', function () {
							var sliderSpeed = swiper.params.speed;
							infoLeft.removeClass('qodef--active');
							setTimeout(function () {
							}, sliderSpeed / 10);
							setTimeout(function () {
								qodefSliderNav.setInfo(slider, infoLeft, infoRight);
							}, sliderSpeed / 2);
						});
					}
				});
			}
		},
		navMovement: function (holder, prev, next) {
			const headerHeight = $('#qodef-page-header').outerHeight();

			holder.on('mousemove', function (e) {
				var x = e.clientX,
					y = e.clientY,
					deltaY = prev.height() / 4,
					deltaX = prev.width() / 2;

				prev.add(next).css({
					'top': y - deltaY,
					'left': x - deltaX
				});

				if (x < qodefCore.windowWidth / 2) {
					prev.css('opacity', '1');
					prev.css('visibility', 'visible');
					next.css('opacity', '0');
					next.css('visibility', 'hidden');
				} else {
					next.css('opacity', '1');
					next.css('visibility', 'visible');
					prev.css('opacity', '0');
					prev.css('visibility', 'hidden');
				}

				if ( x <= prev.width() / 2 ) {
					prev.add(next).css({
						'top': y - deltaY,
						'left': 0
					});
				}

				if ( x >= qodef.windowWidth - next.width() / 2 ) {
					prev.add(next).css({
						'top': y - deltaY,
						'left': qodef.windowWidth - next.width()
					});
				}

				if ( y <= headerHeight + prev.add(next).height() ) {
					prev.add(next).css({
						'top': headerHeight + prev.add(next).height() - 10,
						'left': x - deltaX
					});
				}

				if ( y >= qodef.windowHeight - ( prev.add(next).height() / 2 - 10 ) ) {
					prev.add(next).css({
						'top': qodef.windowHeight - prev.add(next).height() / 2,
						'left': x - deltaX
					});
				}
			});
		},
		setInfo: function ( swiper, infoLeft, infoRight ) {
			var activeSlide = swiper.find('.swiper-slide-active'),
				activeInfoLeft = activeSlide.find('.qodef-e-left-holder').html(),
				activeInfoRight = activeSlide.find('.qodef-e-right-holder').html();

			infoLeft.html(activeInfoLeft);
			infoLeft.addClass('qodef--active');

			infoRight.html(activeInfoRight);
		},
	};

	qodefCore.shortcodes.laurits_core_fullscreen_portfolio_slider = {};
	qodefCore.shortcodes.laurits_core_fullscreen_portfolio_slider.qodefSwiper = qodef.qodefSwiper;
	qodefCore.shortcodes.laurits_core_fullscreen_portfolio_slider.qodefSliderNav = qodefSliderNav;

})( jQuery );

(function ( $ ) {
	'use strict';
	
	$(window).on('load', function () {
		qodefInteractivePortfolioShowcase.init();
	});
	
	var qodefInteractivePortfolioShowcase = {
		scrollAmount: '',
		init: function ( settings ) {
			var $holder = $('.qodef-interactive-portfolio-showcase');
			
			if ($holder.length) {
				$holder.each(function () {
					var thisSlider = $(this),
						articles = thisSlider.find('article'),
						articlesImages = thisSlider.find('.qodef-e-image-holder .qodef-e-media-image'),
						articleList = $holder.find('.qodef-e-info-list'),
						infoHolder = $holder.find('.qodef-info-holder'),
						headerHeight = $('#qodef-page-header').height(),
						mobileHeight = $('#qodef-page-mobile-header').height(),
						infoTop = thisSlider.find('.qodef-e-info--top'),
						infoTopHeight = infoTop.outerHeight(),
						infoTopPosition = infoTop.offset().top + infoTopHeight,
						currentMargin = infoTopHeight + qodef.window.height() / 5;
					qodefInteractivePortfolioShowcase.scrollAmount = articleList.offset().top;
					
					if ( qodef.windowWidth > 1024 ) {
						thisSlider.css('height','calc(100vh - ' + headerHeight + 'px)');
					} else {
						thisSlider.css('height','calc(100vh - ' + mobileHeight + 'px)');
					}
					
					if ( qodef.windowWidth <= 1366 ) {
						articleList.css('margin-top', currentMargin );
					} else {
						articleList.css('margin-top', '50%');
					}
					
					if ( infoHolder.length ) {
						infoHolder.on('scroll', function () {
							if ( articleList.offset().top < infoTopPosition ) {
								infoTop.css( 'top', -(infoTopPosition - articleList.offset().top)  + 'px' );
							} else {
								infoTop.css( 'top', '0' );
							}
						});
					}

					qodefCore.qodefIsInViewport.check(
						thisSlider,
						() => {
							$holder.addClass('qodef--init');
							articles.eq(0).addClass('qodef--hover');
							articlesImages.eq(0).addClass( 'qodef--hover qodef--prev' );
						}
					);

					articles.on('touchstart mouseenter',
						function () {
							var $thisArticle = $( this );

							if ( !$thisArticle.hasClass('qodef--hover') ) {
								articlesImages.removeClass('qodef--prev');
								articlesImages.filter('.qodef--hover').addClass('qodef--prev');
								console.log($thisArticle.index());
								setTimeout(
									function () {
										articlesImages.removeClass( 'qodef--hover' ).eq( $thisArticle.index() - 1 ).addClass( 'qodef--hover' );
										articles.removeClass( 'qodef--hover' ).eq( $thisArticle.index() - 1 ).addClass( 'qodef--hover' );
									}, 10
								);
							}
						}
					);
				});
			}
		},
		checkScrollDirection: function ( articleList ) {
			var scrollDirection = ( articleList.offset().top > qodefInteractivePortfolioShowcase.scrollAmount ) ? 'down' : 'up';
			
			qodefInteractivePortfolioShowcase.scrollAmount = articleList.offset().top;
			
			return scrollDirection;
		},
	};
	
	qodefCore.shortcodes.laurits_core_interactive_portfolio_showcase = {};
	qodefCore.shortcodes.laurits_core_interactive_portfolio_showcase.qodefInteractivePortfolioShowcase = qodefInteractivePortfolioShowcase;
	
})( jQuery );

(function ( $ ) {
	'use strict';
	
	$( document ).on(
		'laurits_trigger_get_new_posts',
		function () {
			qodefPortfolioEqualHeight.init();
		}
	);
	
	$( window ).on(
		'load',
		function () {
			qodefPortfolioEqualHeight.init();
			qodefPortfolioListRemoveSideBorders.init();
			qodefPortfolioAnimationEffects.init();
		}
	);
	
	var shortcode = 'laurits_core_portfolio_list';
	
	var qodefPortfolioEqualHeight = {
		init: function () {
			this.holder = $('.qodef-portfolio-list.qodef-layout--columns.qodef-item-equal-heigth');
			
			if ( this.holder.length && this.holder.hasClass('qodef-item-border--yes') ) {
				this.holder.each(
					function () {
						var $list = $( this ),
							items = $list.find('.qodef-e.qodef-grid-item'),
							maxHeight = 0;
						
						$list.waitForImages( function () {
							if ( items.length ) {
								items.each(
									function () {
										var item = $( this );
										
										if ( item.outerHeight() > maxHeight ) {
											maxHeight = item.outerHeight();
										}
									}
								);
								
								items.each(
									function () {
										var item = $( this );
										item.css('height', maxHeight);
									}
								);
							}
						});
					}
				);
			}
		}
	},
	qodefPortfolioListRemoveSideBorders = {
		init: function () {
			var page = $('#qodef-page-content');
			this.holder = page.find('.qodef-portfolio-list.qodef-item-border--yes.qodef-side-border--off');
			
			if ( this.holder.length ) {
				this.holder.each(
					function () {
						var $list = $( this ),
							body = $( 'body' ),
							editor = body.hasClass('elementor-page') ? 'elementor' : 'wp_bakery',
							grid = $list.find('.qodef-grid-inner'),
							backgroundVars = {},
							color = '#fff';
						
						if ('elementor' === editor) {
							backgroundVars.$widgetBackgroundColor = $list.closest('.elementor-widget-container').css('background-color');
							backgroundVars.$columnBackgroundColor = $list.closest('.elementor-column-wrap').css('background-color');
							backgroundVars.$sectionBackgroundColor = $list.closest('section.elementor-element').css('background-color');
							backgroundVars.$pageBackground = body.css('background-color');
						} else {
							backgroundVars.$widgetBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
							backgroundVars.$columnBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
							backgroundVars.$sectionBackgroundColor = $list.closest('.vc_row').css('background-color');
							backgroundVars.$pageBackground = body.css('background-color');
						}
						if ( 'undefined' !== typeof backgroundVars.$widgetBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$widgetBackgroundColor ) {
							color = backgroundVars.$widgetBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$columnBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$columnBackgroundColor ) {
							color = backgroundVars.$columnBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$sectionBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$sectionBackgroundColor ) {
							color = backgroundVars.$sectionBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$pageBackground && 'rgba(0, 0, 0, 0)' !== backgroundVars.$pageBackground ) {
							color = backgroundVars.$pageBackground;
						}
						
						grid.css('color', color);
					}
				);
			}
		}
	},
	qodefPortfolioAnimationEffects = {
		init () {
			const $holders = $('.qodef-portfolio-list.qodef-appear-animation--yes');

			if ( $holders.length ) {
				$holders.each(
					( index, element ) => {
						const $thisHolder = $( element );
						const delay       = $thisHolder.data('appearing-delay');
						$thisHolder.addClass('qodef--appeared');

						qodefCore.qodefIsInViewport.check(
							$thisHolder,
							() => {
								const $items = $thisHolder.find('.qodef-e');

								if ( $items.length ) {
									$items.each(
										( index, element ) => {
											const $thisItem = $( element );

											if ( $thisHolder.hasClass('qodef-borders-animation--yes') ) {
												setTimeout(
													() => {
														$thisItem.addClass('qodef--appeared');
													}, index * 160 + 400 + delay
												);
											} else {
												setTimeout(
													() => {
														$thisItem.addClass('qodef--appeared');
													}, index * 160 + delay
												);
											}

											if ( $thisItem.hasClass('qodef-parallax-effect--yes') ) {
												$thisItem.attr(
													'data-parallax',
													'{"y": -80, "smoothness": 100}'
												);

												qodefPortfolioAnimationEffects.initItems();
											}
										}
									)
								}
							}
						);
					}
				)
			}
		},
		initItems() {
			const parallaxInstances = $('[data-parallax]');

			if ( parallaxInstances.length && ! qodefCore.html.hasClass( 'touchevents' ) && typeof ParallaxScroll === 'object' ) {
				ParallaxScroll.init(); //initialization removed from plugin js file to have it run only on non-touch devices
			}
		}
	};
	
	qodefCore.shortcodes[shortcode] = {};
	qodefCore.shortcodes[shortcode].qodefPortfolioEqualHeight = qodefPortfolioEqualHeight;
	qodefCore.shortcodes[shortcode].qodefPortfolioListRemoveSideBorders = qodefPortfolioListRemoveSideBorders;

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}
	
})( jQuery );

(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_testimonials_list             = {};
	qodefCore.shortcodes.laurits_core_testimonials_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );

(function ( $ ) {
	'use strict';
	
	$( window ).on(
		'load',
		function () {
			qodefTeamListRemoveSideBorders.init();
		}
	);

	var shortcode = 'laurits_core_team_list';
	
	var qodefTeamListRemoveSideBorders = {
		init: function () {
			var page = $('#qodef-page-content');
			this.holder = page.find('.qodef-team-list.qodef-layout--columns.qodef-item-border--yes.qodef-side-border--off');
			
			if ( this.holder.length ) {
				this.holder.each(
					function () {
						var $list = $( this ),
							body = $( 'body' ),
							editor = body.hasClass('elementor-page') ? 'elementor' : 'wp_bakery',
							grid = $list.find('.qodef-grid-inner'),
							backgroundVars = {},
							color = '#fff';
						
						if ('elementor' === editor) {
							backgroundVars.$widgetBackgroundColor = $list.closest('.elementor-widget-container').css('background-color');
							backgroundVars.$columnBackgroundColor = $list.closest('.elementor-column-wrap').css('background-color');
							backgroundVars.$sectionBackgroundColor = $list.closest('section.elementor-element').css('background-color');
							backgroundVars.$pageBackground = body.css('background-color');
						} else {
							backgroundVars.$widgetBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
							backgroundVars.$columnBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
							backgroundVars.$sectionBackgroundColor = $list.closest('.vc_row').css('background-color');
							backgroundVars.$pageBackground = body.css('background-color');
						}
						if ( 'undefined' !== typeof backgroundVars.$widgetBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$widgetBackgroundColor ) {
							color = backgroundVars.$widgetBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$columnBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$columnBackgroundColor ) {
							color = backgroundVars.$columnBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$sectionBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$sectionBackgroundColor ) {
							color = backgroundVars.$sectionBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$pageBackground && 'rgba(0, 0, 0, 0)' !== backgroundVars.$pageBackground ) {
							color = backgroundVars.$pageBackground;
						}
						
						grid.css('color', color);
					}
				);
			}
		}
	};

	qodefCore.shortcodes[shortcode] = {};
	qodefCore.shortcodes[shortcode].qodefTeamListRemoveSideBorders = qodefTeamListRemoveSideBorders;

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}

})( jQuery );

(function ( $ ) {
	'use strict';
	
	$( document ).ready(
		function () {
			qodefImageSlider.init();
		}
	);
	
	$( window ).resize(
		function () {
			qodefImageSlider.init();
		}
	);
	
	$( document ).on(
		'laurits_trigger_get_new_posts',
		function () {
			qodefImageSlider.init();
		}
	);
	
	var qodefImageSlider = {
		init: function () {
			var $list = $( '.qodef-portfolio-list.qodef-item-layout--image-slider' );
			
			if ( $list.length ) {
				$list.each(
					function () {
						var $section = $list.closest('.elementor-section');
						
						if ( $section.is(':first-child') ) {
							$list.find( '.qodef-e' ).each(
								function () {
									var $thisItem = $( this ),
										$header = $('#qodef-page-header'),
										$stickyHeader = $('.qodef-header-sticky');
									
									if ($thisItem.is(':first-child')) {
										if ( qodef.windowWidth > 768 ) {
											$thisItem.find('.qodef-e-inner').css('height', 'calc(100vh - ' + $header.height() + 'px)');
										} else {
											$thisItem.find('.qodef-e-inner').css('height', 'auto');
										}
									} else {
										if ( $stickyHeader.length ) {
											if ( qodef.windowWidth > 768 ) {
												$thisItem.find('.qodef-e-inner').css('height', 'calc(100vh - ' + $stickyHeader.height() + 'px)');
											} else {
												$thisItem.find('.qodef-e-inner').css('height', 'auto');
											}
										} else {
											if ( qodef.windowWidth > 768 ) {
												$thisItem.find('.qodef-e-inner').css('height', '100vh');
											} else {
												$thisItem.find('.qodef-e-inner').css('height', 'auto');
											}
										}
									}
								}
							);
						} else {
							$list.find( '.qodef-e' ).each(
								function () {
									var $thisItem = $( this ),
										$stickyHeader = $('.qodef-header-sticky');
									
									if ( $stickyHeader.length ) {
										if ( qodef.windowWidth > 768 ) {
											$thisItem.find('.qodef-e-inner').css('height', 'calc(100vh - ' + $stickyHeader.height() + 'px)');
										} else {
											$thisItem.find('.qodef-e-inner').css('height', 'auto');
										}
									} else {
										if ( qodef.windowWidth > 768 ) {
											$thisItem.find('.qodef-e-inner').css('height', '100vh');
										} else {
											$thisItem.find('.qodef-e-inner').css('height', 'auto');
										}
									}
								}
							);
						}
					}
				);

				qodefImageSlider.delaySliders( $list );
			}
		},
		delaySliders ( $list ) {
			if ( $list.length ) {
				$list.each(
					( index, element ) => {
						const $thisList = $( element );

						qodefCore.qodefIsInViewport.check(
							$thisList,
							() => {
								$thisList.addClass('qodef--init');
								const $sliders = $thisList.find('.qodef-swiper-container');

								if ( $sliders.length ) {
									$sliders.each(
										( index, element ) => {
											const $thisSlider = $( element ),
												  thisSwiper = $thisSlider[0].swiper;

											thisSwiper.autoplay.stop();

											setTimeout(
												() => {
													thisSwiper.autoplay.start();
												}, index * 200
											);
										}
									)
								}
							}
						);
					}
				)
			}
		}
	};
	
	qodefCore.shortcodes.laurits_core_portfolio_list.qodefImageSlider = qodefImageSlider;
	
})( jQuery );

(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefInfoFollow.init();
		}
	);

	$( document ).on(
		'laurits_trigger_get_new_posts',
		function () {
			qodefInfoFollow.init();
		}
	);

	var qodefInfoFollow = {
		init: function () {
			var $gallery = $( '.qodef-hover-animation--follow' );

			if ( $gallery.length ) {
				qodefCore.body.append( '<div class="qodef-e-content-follow"><div class="qodef-e-top-holder"></div><div class="qodef-e-text"></div></div>' );

				var $contentFollow = $( '.qodef-e-content-follow' ),
					$topHolder     = $contentFollow.find( '.qodef-e-top-holder' ),
					$textHolder    = $contentFollow.find( '.qodef-e-text' );

				$gallery.each(
					function () {
						$gallery.find( '.qodef-e-inner' ).each(
							function () {
								var $thisItem = $( this );

								//info element position
								$thisItem.on(
									'mousemove',
									function ( e ) {
										if ( e.clientX + 20 + $contentFollow.width() > qodefCore.windowWidth ) {
											$contentFollow.addClass( 'qodef-right' );
										} else {
											$contentFollow.removeClass( 'qodef-right' );
										}

										$contentFollow.css(
											{
												top: e.clientY + 20,
												left: e.clientX + 20,
											}
										);
									}
								);

								//show/hide info element
								$thisItem.on(
									'mouseenter',
									function () {
										var $thisItemTopHolder  = $( this ).find( '.qodef-e-top-holder' ),
											$thisItemTextHolder = $( this ).find( '.qodef-e-text' );

										if ( $thisItemTopHolder.length ) {
											$topHolder.html( $thisItemTopHolder.html() );
										}

										if ( $thisItemTextHolder.length ) {
											$textHolder.html( $thisItemTextHolder.html() );
										}

										if ( ! $contentFollow.hasClass( 'qodef-is-active' ) ) {
											$contentFollow.addClass( 'qodef-is-active' );
										}
									}
								).on(
									'mouseleave',
									function () {
										if ( $contentFollow.hasClass( 'qodef-is-active' ) ) {
											$contentFollow.removeClass( 'qodef-is-active' );
										}
									}
								);
							}
						);
					}
				);
			}
		},
	};

	qodefCore.shortcodes.laurits_core_portfolio_list.qodefInfoFollow = qodefInfoFollow;

})( jQuery );
