<?php
if ( ! empty( $info_text ) ) { ?>
	<h2 class="qodef-e-info-text"><?php echo esc_html( $info_text ); ?> </h2>
<?php } ?>
