<?php
if ( ! empty( $tagline ) ) { ?>
	<span class="qodef-e-tag-line"><?php echo esc_html( $tagline ); ?> </span>
<?php } ?>
