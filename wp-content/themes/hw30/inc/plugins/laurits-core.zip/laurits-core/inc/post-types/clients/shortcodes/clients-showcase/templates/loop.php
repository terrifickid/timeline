<div class="qodef-e-info-list">
	<div class="qodef-e-top-info">
		<?php
		// Include shortcode tagline
		laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/parts/tagline', '', $params );

		// Include shortcode title
		laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/parts/info-text', '', $params );
		?>
	</div>
	<div class="qodef-e-items-list" <?php echo qode_framework_inline_style( $items_styles ); ?>>
		<?php
		if ( $query_result->have_posts() ) {
			while ( $query_result->have_posts() ) :
				$query_result->the_post();

				$params['item_classes'] = $this_shortcode->get_item_classes( $params );

				laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/item', '', $params );

			endwhile; // End of the loop.
		} else {
			// Include global posts not found
			laurits_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
		}

		wp_reset_postdata();
		?>
	</div>
</div>
