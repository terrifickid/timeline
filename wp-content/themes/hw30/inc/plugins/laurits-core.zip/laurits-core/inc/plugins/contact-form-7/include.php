<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/contact-form-7/class-lauritscore-contact-form-7.php';
