<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-content">
			<?php
			// Include post title
			laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/parts/title', '', $params );
			?>
		</div>
	</div>
</article>
