<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-lauritscore-woocommerce-dropdown-cart-widget.php';
