<?php if ( 'yes' === $show_ordering_filter ) { ?>
	<div class="qodef-ordering-filter">
		<h5 class="qodef-ordering-title"><?php esc_html_e( 'Sort by +', 'laurits-core' ); ?>
		</h5>
		<div class="qodef-ordering-items">
			<ul>
				<?php echo laurits_core_get_blog_list_sorting_filter( $params ); ?>
			</ul>
		</div>
	</div>
<?php } ?>
