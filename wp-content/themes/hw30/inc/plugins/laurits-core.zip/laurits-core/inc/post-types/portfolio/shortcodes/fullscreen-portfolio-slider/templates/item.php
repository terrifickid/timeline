<?php
$wrapper_styles = array();
$info_styles    = array();
if ( ! empty( $background_color ) ) {
	$wrapper_styles[] = 'background-color: ' . $background_color;
	$info_styles[]    = 'background-color: ' . $background_color;
}

$portfolio_device = get_post_meta( get_the_ID(), 'qodef_portfolio_device_display_image_device', true );

$holder_class = 'qodef-e-mobile-wrapper';
if ( ! empty( $portfolio_device ) ) {
	$holder_class = 'qodef-e-' . $portfolio_device . '-wrapper';
}
?>
<article class="qodef-e qodef-grid-item swiper-slide">
	<div class="qodef-e-inner">
		<div class="<?php echo esc_html( $holder_class ); ?>" <?php qode_framework_inline_style( $wrapper_styles ); ?>>
			<div class="qodef-e-image-wrapper">
				<?php laurits_core_template_part( 'post-types/portfolio/shortcodes/fullscreen-portfolio-slider', 'templates/post-info/image', $portfolio_device, $params ); ?>
			</div>
			<div class="qodef-e-content">
				<div class="qodef-e-left-holder">
					<?php
					// Include post title
					laurits_core_template_part( 'post-types/portfolio/shortcodes/fullscreen-portfolio-slider', 'templates/post-info/title', '', $params );
					?>
					<div class="qodef-e-info">
						<div class="qodef-e-info-category">
							<?php
							// Include post category info
							laurits_core_template_part( 'post-types/portfolio/shortcodes/fullscreen-portfolio-slider', 'templates/post-info/categories', '', $params );
							?>
						</div>
						<?php
						// Include post client info
						laurits_core_template_part( 'post-types/portfolio/shortcodes/fullscreen-portfolio-slider', 'templates/post-info/client', '', $params );
						?>
					</div>
				</div>
				<div class="qodef-e-right-holder">
					<?php
					// Include post client info
					laurits_core_template_part( 'post-types/portfolio/shortcodes/fullscreen-portfolio-slider', 'templates/post-info/share', '', $params );
					?>
				</div>
			</div>
		</div>
	</div>
</article>
