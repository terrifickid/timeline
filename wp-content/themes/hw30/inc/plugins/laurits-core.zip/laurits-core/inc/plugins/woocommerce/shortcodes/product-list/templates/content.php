<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_attr( $data_attr, 'data-options' ); ?>>
	<?php
	if ( 'yes' === $enable_filter || 'yes' === $show_ordering_filter ) {
		?>
	<div class="qodef-filter-wrapper">
		<?php
		// Include global filter from theme
		laurits_core_theme_template_part( 'filter', 'templates/filter', '', $params );
	}

	if ( 'yes' === $show_ordering_filter ) {
		// filtering template must be here because of ajax loading
		laurits_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/ordering-filter', '', $params );
	}
	if ( 'yes' === $enable_filter || 'yes' === $show_ordering_filter ) {
		?>
	</div>
	<?php } ?>
	<div class="qodef-grid-inner clear">
		<?php
		// Include global masonry template from theme
		laurits_core_theme_template_part( 'masonry', 'templates/sizer-gutter', '', $params['behavior'] );

		// Include items
		laurits_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/loop', '', $params );
		?>
	</div>
	<?php
	// Include global pagination from theme
	laurits_core_theme_template_part( 'pagination', 'templates/pagination', $params['pagination_type'], $params );
	?>
</div>
