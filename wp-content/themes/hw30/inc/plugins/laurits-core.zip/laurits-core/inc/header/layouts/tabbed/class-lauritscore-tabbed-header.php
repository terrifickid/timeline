<?php

class LauritsCore_Tabbed_Header extends LauritsCore_Header {
	private static $instance;

	public function __construct() {
		$this->set_layout( 'tabbed' );
		$this->set_search_layout( 'fullscreen' );
		$this->default_header_height = 130;

		parent::__construct();
	}

	/**
	 * @return LauritsCore_Tabbed_Header
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}
