<div class="qodef-tabbed-header-wrapper">
		<?php
		// Include logo
		laurits_core_get_header_logo_image();

		// Include main navigation
		laurits_core_template_part( 'header', 'templates/parts/navigation' );

		// Include widget area one
		laurits_core_get_header_widget_area();
		?>
</div>
