<?php

include_once LAURITS_CORE_CPT_PATH . '/clients/helper.php';

foreach ( glob( LAURITS_CORE_CPT_PATH . '/clients/dashboard/meta-box/*.php' ) as $module ) {
	include_once $module;
}
