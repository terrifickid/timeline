<?php

if ( ! function_exists( 'laurits_core_add_minimal_header_meta' ) ) {
	/**
	 * Function that add additional header layout meta box options
	 *
	 * @param object $page
	 */
	function laurits_core_add_minimal_header_meta( $page ) {

		$section = $page->add_section_element(
			array(
				'name'       => 'qodef_minimal_header_section',
				'title'      => esc_html__( 'Minimal Header', 'laurits-core' ),
				'dependency' => array(
					'show' => array(
						'qodef_header_layout' => array(
							'values'        => 'minimal',
							'default_value' => '',
						),
					),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'    => 'select',
				'name'          => 'qodef_minimal_header_in_grid',
				'title'         => esc_html__( 'Content in Grid', 'laurits-core' ),
				'description'   => esc_html__( 'Set content to be in grid', 'laurits-core' ),
				'default_value' => '',
				'options'       => laurits_core_get_select_type_options_pool( 'no_yes' ),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_header_height',
				'title'       => esc_html__( 'Header Height', 'laurits-core' ),
				'description' => esc_html__( 'Enter header height', 'laurits-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'laurits-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_header_side_padding',
				'title'       => esc_html__( 'Header Side Padding', 'laurits-core' ),
				'description' => esc_html__( 'Enter side padding for header area', 'laurits-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px or %', 'laurits-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_minimal_header_background_color',
				'title'       => esc_html__( 'Header Background Color', 'laurits-core' ),
				'description' => esc_html__( 'Enter header background color', 'laurits-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'laurits-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_minimal_header_border_color',
				'title'       => esc_html__( 'Header Border Color', 'laurits-core' ),
				'description' => esc_html__( 'Enter header border color', 'laurits-core' ),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_header_border_width',
				'title'       => esc_html__( 'Header Border Width', 'laurits-core' ),
				'description' => esc_html__( 'Enter header border width size', 'laurits-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'laurits-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'select',
				'name'        => 'qodef_minimal_header_border_style',
				'title'       => esc_html__( 'Header Border Style', 'laurits-core' ),
				'description' => esc_html__( 'Choose header border style', 'laurits-core' ),
				'options'     => laurits_core_get_select_type_options_pool( 'border_style' ),
			)
		);
	}

	add_action( 'laurits_core_action_after_page_header_meta_map', 'laurits_core_add_minimal_header_meta' );
}
