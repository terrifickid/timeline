<?php
$portfolio_service = get_post_meta( get_the_ID(), 'qodef_portfolio_item_service', true );

if ( ! empty( $portfolio_service ) ) { ?>
	<span class="qodef-e-service"><?php echo esc_html( $portfolio_service ); ?> </span>
<?php } ?>
