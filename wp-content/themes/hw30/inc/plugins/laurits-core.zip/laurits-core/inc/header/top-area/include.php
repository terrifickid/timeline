<?php

include_once LAURITS_CORE_INC_PATH . '/header/top-area/class-lauritscore-top-area.php';
include_once LAURITS_CORE_INC_PATH . '/header/top-area/helper.php';

foreach ( glob( LAURITS_CORE_INC_PATH . '/header/top-area/dashboard/*/*.php' ) as $dashboard ) {
	include_once $dashboard;
}
