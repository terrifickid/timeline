(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.laurits_core_clients_list             = {};
	qodefCore.shortcodes.laurits_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
