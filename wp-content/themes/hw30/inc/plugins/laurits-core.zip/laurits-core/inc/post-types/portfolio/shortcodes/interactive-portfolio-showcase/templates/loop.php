<div class="qodef-e-info-list">
	<div class="qodef-e-info-slider">
		<div class="qodef-e-info-heading-row">
			<span class="qodef-e-item qodef-e-item-title">
				<?php echo esc_html( 'Project', 'laurits-core' ); ?>
			</span>
			<span class="qodef-e-item qodef-e-item-service">
				<?php echo esc_html( 'Service', 'laurits-core' ); ?>
			</span>
			<span class="qodef-e-item qodef-e-item-location">
				<?php echo esc_html( 'Location', 'laurits-core' ); ?>
			</span>
			<span class="qodef-e-item qodef-e-item-year">
				<?php echo esc_html( 'Year', 'laurits-core' ); ?>
			</span>
		</div>
		<?php
		if ( $query_result->have_posts() ) {
			while ( $query_result->have_posts() ) :
				$query_result->the_post();

				$params['image_dimension'] = $this_shortcode->get_list_item_image_dimension( $params );
				$params['item_classes']    = $this_shortcode->get_item_classes( $params );

				laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/item', '', $params );

			endwhile; // End of the loop.
		} else {
			// Include global posts not found
			laurits_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
		}

		wp_reset_postdata();
		?>
	</div>
</div>
