<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/class-lauritscore-product-list-shortcode.php';
include_once LAURITS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/helper.php';

foreach ( glob( LAURITS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
