<?php
if ( ! empty( $info_text ) ) { ?>
	<h2 class="qodef-e-info-text"><?php echo qode_framework_wp_kses_html( 'content', $info_text ); ?> </h2>
<?php } ?>
