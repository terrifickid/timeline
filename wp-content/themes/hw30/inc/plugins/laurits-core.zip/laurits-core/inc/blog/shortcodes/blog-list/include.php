<?php

include_once LAURITS_CORE_INC_PATH . '/blog/shortcodes/blog-list/helper.php';
include_once LAURITS_CORE_INC_PATH . '/blog/shortcodes/blog-list/class-lauritscore-blog-list-shortcode.php';

foreach ( glob( LAURITS_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
