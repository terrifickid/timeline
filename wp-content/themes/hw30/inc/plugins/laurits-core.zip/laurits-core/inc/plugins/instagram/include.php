<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/instagram/helper.php';
