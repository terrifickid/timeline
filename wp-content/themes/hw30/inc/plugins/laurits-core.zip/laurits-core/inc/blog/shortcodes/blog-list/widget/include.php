<?php

include_once LAURITS_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-lauritscore-blog-list-widget.php';
