<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-on-image/info-on-image.php';
