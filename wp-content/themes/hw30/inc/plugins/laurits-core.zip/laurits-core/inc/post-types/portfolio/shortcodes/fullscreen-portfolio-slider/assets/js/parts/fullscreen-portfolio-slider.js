(function ( $ ) {
	'use strict';

	$(document).ready(function () {
		qodefSliderNav.init();
	});

	var qodefSliderNav = {
		init: function () {
			var $sliderWrapper = $('.qodef-slider-device-display-wrapper');

			if ($sliderWrapper.length) {
				$sliderWrapper.each(function () {
					var holder = $(this),
						slider = holder.find('.qodef-swiper-container'),
						infoLeft = holder.find('#qodef-info-left'),
						infoRight = holder.find('#qodef-info-right');

					if ( slider.hasClass('qodef-swiper--initialized') ) {
						var swiper = slider[0].swiper;
						swiper.autoplay.stop();

						qodefCore.qodefIsInViewport.check(
							slider,
							() => {
								slider.closest('.qodef-slider-device-display-wrapper').addClass('qodef--init');
								if (qodefCore.windowWidth > 1024) {
									qodefSliderNav.navMovement(slider, holder.find('.swiper-button-prev'), holder.find('.swiper-button-next'));
								}
								qodefSliderNav.setInfo(slider, infoLeft, infoRight);
								swiper.autoplay.start();
							}
						);

						swiper.on('slideChangeTransitionStart', function () {
							var sliderSpeed = swiper.params.speed;
							infoLeft.removeClass('qodef--active');
							setTimeout(function () {
							}, sliderSpeed / 10);
							setTimeout(function () {
								qodefSliderNav.setInfo(slider, infoLeft, infoRight);
							}, sliderSpeed / 2);
						});
					}
				});
			}
		},
		navMovement: function (holder, prev, next) {
			const headerHeight = $('#qodef-page-header').outerHeight();

			holder.on('mousemove', function (e) {
				var x = e.clientX,
					y = e.clientY,
					deltaY = prev.height() / 4,
					deltaX = prev.width() / 2;

				prev.add(next).css({
					'top': y - deltaY,
					'left': x - deltaX
				});

				if (x < qodefCore.windowWidth / 2) {
					prev.css('opacity', '1');
					prev.css('visibility', 'visible');
					next.css('opacity', '0');
					next.css('visibility', 'hidden');
				} else {
					next.css('opacity', '1');
					next.css('visibility', 'visible');
					prev.css('opacity', '0');
					prev.css('visibility', 'hidden');
				}

				if ( x <= prev.width() / 2 ) {
					prev.add(next).css({
						'top': y - deltaY,
						'left': 0
					});
				}

				if ( x >= qodef.windowWidth - next.width() / 2 ) {
					prev.add(next).css({
						'top': y - deltaY,
						'left': qodef.windowWidth - next.width()
					});
				}

				if ( y <= headerHeight + prev.add(next).height() ) {
					prev.add(next).css({
						'top': headerHeight + prev.add(next).height() - 10,
						'left': x - deltaX
					});
				}

				if ( y >= qodef.windowHeight - ( prev.add(next).height() / 2 - 10 ) ) {
					prev.add(next).css({
						'top': qodef.windowHeight - prev.add(next).height() / 2,
						'left': x - deltaX
					});
				}
			});
		},
		setInfo: function ( swiper, infoLeft, infoRight ) {
			var activeSlide = swiper.find('.swiper-slide-active'),
				activeInfoLeft = activeSlide.find('.qodef-e-left-holder').html(),
				activeInfoRight = activeSlide.find('.qodef-e-right-holder').html();

			infoLeft.html(activeInfoLeft);
			infoLeft.addClass('qodef--active');

			infoRight.html(activeInfoRight);
		},
	};

	qodefCore.shortcodes.laurits_core_fullscreen_portfolio_slider = {};
	qodefCore.shortcodes.laurits_core_fullscreen_portfolio_slider.qodefSwiper = qodef.qodefSwiper;
	qodefCore.shortcodes.laurits_core_fullscreen_portfolio_slider.qodefSliderNav = qodefSliderNav;

})( jQuery );
