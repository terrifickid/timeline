<?php

if ( ! function_exists( 'laurits_core_add_minimal_header_global_option' ) ) {
	/**
	 * This function set header type value for global header option map
	 */
	function laurits_core_add_minimal_header_global_option( $header_layout_options ) {
		$header_layout_options['minimal'] = array(
			'image' => LAURITS_CORE_HEADER_LAYOUTS_URL_PATH . '/minimal/assets/img/minimal-header.png',
			'label' => esc_html__( 'Minimal', 'laurits-core' ),
		);

		return $header_layout_options;
	}

	add_filter( 'laurits_core_filter_header_layout_option', 'laurits_core_add_minimal_header_global_option' );
}

if ( ! function_exists( 'laurits_core_register_minimal_header_layout' ) ) {
	/**
	 * Function which add header layout into global list
	 *
	 * @param array $header_layouts
	 *
	 * @return array
	 */
	function laurits_core_register_minimal_header_layout( $header_layouts ) {
		$header_layouts['minimal'] = 'LauritsCore_Minimal_Header';

		return $header_layouts;
	}

	add_filter( 'laurits_core_filter_register_header_layouts', 'laurits_core_register_minimal_header_layout' );
}
