(function ( $ ) {
	'use strict';
	
	$(window).on('load', function () {
		qodefInteractivePortfolioShowcase.init();
	});
	
	var qodefInteractivePortfolioShowcase = {
		scrollAmount: '',
		init: function ( settings ) {
			var $holder = $('.qodef-interactive-portfolio-showcase');
			
			if ($holder.length) {
				$holder.each(function () {
					var thisSlider = $(this),
						articles = thisSlider.find('article'),
						articlesImages = thisSlider.find('.qodef-e-image-holder .qodef-e-media-image'),
						articleList = $holder.find('.qodef-e-info-list'),
						infoHolder = $holder.find('.qodef-info-holder'),
						headerHeight = $('#qodef-page-header').height(),
						mobileHeight = $('#qodef-page-mobile-header').height(),
						infoTop = thisSlider.find('.qodef-e-info--top'),
						infoTopHeight = infoTop.outerHeight(),
						infoTopPosition = infoTop.offset().top + infoTopHeight,
						currentMargin = infoTopHeight + qodef.window.height() / 5;
					qodefInteractivePortfolioShowcase.scrollAmount = articleList.offset().top;
					
					if ( qodef.windowWidth > 1024 ) {
						thisSlider.css('height','calc(100vh - ' + headerHeight + 'px)');
					} else {
						thisSlider.css('height','calc(100vh - ' + mobileHeight + 'px)');
					}
					
					if ( qodef.windowWidth <= 1366 ) {
						articleList.css('margin-top', currentMargin );
					} else {
						articleList.css('margin-top', '50%');
					}
					
					if ( infoHolder.length ) {
						infoHolder.on('scroll', function () {
							if ( articleList.offset().top < infoTopPosition ) {
								infoTop.css( 'top', -(infoTopPosition - articleList.offset().top)  + 'px' );
							} else {
								infoTop.css( 'top', '0' );
							}
						});
					}

					qodefCore.qodefIsInViewport.check(
						thisSlider,
						() => {
							$holder.addClass('qodef--init');
							articles.eq(0).addClass('qodef--hover');
							articlesImages.eq(0).addClass( 'qodef--hover qodef--prev' );
						}
					);

					articles.on('touchstart mouseenter',
						function () {
							var $thisArticle = $( this );

							if ( !$thisArticle.hasClass('qodef--hover') ) {
								articlesImages.removeClass('qodef--prev');
								articlesImages.filter('.qodef--hover').addClass('qodef--prev');
								console.log($thisArticle.index());
								setTimeout(
									function () {
										articlesImages.removeClass( 'qodef--hover' ).eq( $thisArticle.index() - 1 ).addClass( 'qodef--hover' );
										articles.removeClass( 'qodef--hover' ).eq( $thisArticle.index() - 1 ).addClass( 'qodef--hover' );
									}, 10
								);
							}
						}
					);
				});
			}
		},
		checkScrollDirection: function ( articleList ) {
			var scrollDirection = ( articleList.offset().top > qodefInteractivePortfolioShowcase.scrollAmount ) ? 'down' : 'up';
			
			qodefInteractivePortfolioShowcase.scrollAmount = articleList.offset().top;
			
			return scrollDirection;
		},
	};
	
	qodefCore.shortcodes.laurits_core_interactive_portfolio_showcase = {};
	qodefCore.shortcodes.laurits_core_interactive_portfolio_showcase.qodefInteractivePortfolioShowcase = qodefInteractivePortfolioShowcase;
	
})( jQuery );
