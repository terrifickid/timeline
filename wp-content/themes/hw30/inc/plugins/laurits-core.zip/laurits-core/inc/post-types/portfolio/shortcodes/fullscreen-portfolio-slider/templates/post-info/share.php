<?php if ( class_exists( 'LauritsCore_Social_Share_Shortcode' ) ) { ?>
	<div class="qodef-e qodef-inof--social-share">
		<?php
		$params = array(
			'layout' => 'text',
		);

		echo LauritsCore_Social_Share_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php } ?>
