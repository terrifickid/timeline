<?php

class LauritsCore_Interactive_Portfolio_Showcase_Shortcode_Elementor extends LauritsCore_Elementor_Widget_Base {

	function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'laurits_core_interactive_portfolio_showcase' );

		parent::__construct( $data, $args );
	}
}

laurits_core_get_elementor_widgets_manager()->register_widget_type( new LauritsCore_Interactive_Portfolio_Showcase_Shortcode_Elementor() );
