<div class="qodef-e-media qodef-swiper-container qodef--slider">
	<div class="swiper-wrapper">
		<?php
		$portfolio_media = get_post_meta( get_the_ID(), 'qodef_portfolio_media', true );

		if ( ! empty( $portfolio_media ) ) {
			$slider_params = array();

			foreach ( $portfolio_media as $media ) {
				$slider_params['media'] = $media['qodef_portfolio_gallery'];
			}

			if ( isset( $media ) && ! empty( $media ) ) {
				$images = explode( ',', $slider_params['media'] );

				foreach ( $images as $image ) {
					if ( isset( $image ) && ! empty( $image ) ) {

						$image_title = get_the_title( $image );
						$image_src   = wp_get_attachment_image_src( $image, 'full' );
						?>
						<div class="swiper-slide" itemprop="image" data-type="image" title="<?php echo esc_attr( $image_title ); ?>">
							<?php echo wp_get_attachment_image( $image, 'full' ); ?>
						</div>
						<?php
					}
				}
			}
		}
		?>
	</div>
	<?php laurits_core_template_part( 'content', 'templates/swiper-pag', '', array( 'slider_pagination' => 'yes' ) ); ?>
</div>
