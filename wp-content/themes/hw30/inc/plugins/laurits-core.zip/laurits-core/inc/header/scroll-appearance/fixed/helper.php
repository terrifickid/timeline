<?php

if ( ! function_exists( 'laurits_core_add_fixed_header_option' ) ) {
	/**
	 * This function set header scrolling appearance value for global header option map
	 */
	function laurits_core_add_fixed_header_option( $options ) {
		$options['fixed'] = esc_html__( 'Fixed', 'laurits-core' );

		return $options;
	}

	add_filter( 'laurits_core_filter_header_scroll_appearance_option', 'laurits_core_add_fixed_header_option' );
}

if ( ! function_exists( 'laurits_core_add_fixed_header_classes' ) ) {
	/**
	 * This function set header scrolling appearance value for global header option map
	 */
	function laurits_core_add_fixed_header_classes( $classes ) {
		$header_scroll_appearance = laurits_core_get_post_value_through_levels( 'qodef_header_scroll_appearance' );

		if ( 'fixed' === $header_scroll_appearance ) {
			$fixed_before_scroll = laurits_core_get_post_value_through_levels( 'qodef_fixed_header_before_scroll' );

			if ( 'yes' === $fixed_before_scroll ) {
				$classes[] = 'qodef-header-fixed-from-start';
			}
		}

		return $classes;
	}

	add_filter( 'body_class', 'laurits_core_add_fixed_header_classes' );
}
