<?php

include_once LAURITS_CORE_CPT_PATH . '/clients/shortcodes/clients-list/class-lauritscore-clients-list-shortcode.php';

foreach ( glob( LAURITS_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
