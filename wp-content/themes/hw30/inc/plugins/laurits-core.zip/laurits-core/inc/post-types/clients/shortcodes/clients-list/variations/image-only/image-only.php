<?php

if ( ! function_exists( 'laurits_core_add_clients_list_variation_image_only' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function laurits_core_add_clients_list_variation_image_only( $variations ) {
		$variations['image-only'] = esc_html__( 'Image Only', 'laurits-core' );

		return $variations;
	}

	add_filter( 'laurits_core_filter_clients_list_layouts', 'laurits_core_add_clients_list_variation_image_only' );
}
