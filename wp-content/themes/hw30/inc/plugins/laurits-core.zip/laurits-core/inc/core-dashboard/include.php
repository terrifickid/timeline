<?php

include_once LAURITS_CORE_INC_PATH . '/core-dashboard/class-lauritscore-dashboard.php';
