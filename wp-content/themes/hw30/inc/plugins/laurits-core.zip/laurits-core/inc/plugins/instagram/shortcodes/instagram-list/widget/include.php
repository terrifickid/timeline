<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-lauritscore-instagram-list-widget.php';
