<?php
if ( ! empty( $footnote ) ) { ?>
	<span class="qodef-e-footnote"><?php echo wp_kses_post( $footnote ); ?> </span>
<?php } ?>
