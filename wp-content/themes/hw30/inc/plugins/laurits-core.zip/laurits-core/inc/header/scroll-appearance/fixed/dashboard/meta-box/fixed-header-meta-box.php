<?php

if ( ! function_exists( 'laurits_core_add_fixed_header_options' ) ) {
	/**
	 * Function that add additional header layout global options
	 *
	 * @param object $section
	 * @param object $custom_sidebars
	 */
	function laurits_core_add_fixed_header_options( $section, $custom_sidebars ) {

		if ( $section ) {

			$fixed_section = $section->add_section_element(
				array(
					'name'       => 'qodef_fixed_header_section',
					'dependency' => array(
						'show' => array(
							'qodef_header_scroll_appearance' => array(
								'values'        => 'fixed',
								'default_value' => '',
							),
						),
					),
				)
			);

			$fixed_section->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_fixed_header_before_scroll',
					'title'         => esc_html__( 'Fixed Header Before Scroll', 'laurits-core' ),
					'description'   => esc_html__( 'Choose if the header is fixed before scroll', 'laurits-core' ),
					'default_value' => 'no',
				)
			);
		}
	}

	add_action( 'laurits_core_action_after_header_scroll_appearance_meta_options_map', 'laurits_core_add_fixed_header_options', 11, 2 );
}
