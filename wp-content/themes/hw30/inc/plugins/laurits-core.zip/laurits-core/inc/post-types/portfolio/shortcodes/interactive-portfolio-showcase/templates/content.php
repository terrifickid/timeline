<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-info-holder">
		<div class="qodef-e-info--top" <?php echo qode_framework_get_inline_style( $info_text_styles ); ?>>
			<?php
			// Include tagline template
			laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/parts/tag-line', '', $params );

			// Include info text template
			laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/parts/info-text', '', $params );
			?>
		</div>
		<?php
		// Include portfolio loop
		laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/loop', '', $params );
		?>
	</div>
	<div class="qodef-e-image-holder">
	<?php
	// Include portfolio loop
	laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/loop', 'images', $params );

	// Include footnote
	laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/parts/footnote', '', $params );
	?>
	</div>
</div>
