<?php

include_once LAURITS_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/helper.php';
include_once LAURITS_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/class-lauritscore-portfolio-list-shortcode.php';

foreach ( glob( LAURITS_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
