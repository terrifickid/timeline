<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php
	if ( 'left' === $image_position ) {
		// Include portfolio loop
		laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/loop', 'images', $params );

		// Include portfolio loop
		laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/loop', '', $params );
	} elseif ( 'right' === $image_position ) {
		// Include portfolio loop
		laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/loop', '', $params );

		// Include portfolio loop
		laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/loop', 'images', $params );
	}
	?>
</div>
