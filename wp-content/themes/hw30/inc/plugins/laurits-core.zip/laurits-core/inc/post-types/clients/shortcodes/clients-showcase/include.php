<?php

include_once LAURITS_CORE_CPT_PATH . '/clients/shortcodes/clients-showcase/class-lauritscore-clients-showcase-shortcode.php';
