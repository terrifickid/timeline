<?php

include_once LAURITS_CORE_CPT_PATH . '/portfolio/shortcodes/interactive-portfolio-showcase/class-lauritscore-interactive-portfolio-showcase-shortcode.php';
