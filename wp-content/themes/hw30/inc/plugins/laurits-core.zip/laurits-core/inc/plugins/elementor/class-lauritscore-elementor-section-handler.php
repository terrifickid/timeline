<?php

class LauritsCore_Elementor_Section_Handler {
	private static $instance;
	public $sections = array();
	public $background_text_sections = array();

	public function __construct() {
		add_action( 'elementor/element/section/_section_responsive/after_section_end', array( $this, 'render_parallax_options' ), 10, 2 );
		add_action( 'elementor/element/section/_section_responsive/after_section_end', array( $this, 'render_letter_options' ), 10, 2 );
		add_action( 'elementor/element/section/_section_responsive/after_section_end', array( $this, 'render_offset_options' ), 10, 2 );
		add_action( 'elementor/element/section/_section_responsive/after_section_end', array( $this, 'render_grid_options' ), 10, 2 );
		add_action( 'elementor/element/column/_section_responsive/after_section_end', array( $this, 'render_sticky_options' ), 10, 2 );
		add_action( 'elementor/frontend/section/before_render', array( $this, 'section_before_render' ) );
		add_action( 'elementor/frontend/element/before_render', array( $this, 'section_before_render' ) );
		add_action( 'elementor/frontend/before_enqueue_styles', array( $this, 'enqueue_styles' ), 9 );
		add_action( 'elementor/frontend/before_enqueue_scripts', array( $this, 'enqueue_scripts' ), 9 );
	}

	/**
	 * @return LauritsCore_Elementor_Section_Handler
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function render_letter_options( $section, $args ) {
		$section->start_controls_section(
			'qodef_letter',
			[
				'label' => esc_html__( 'Laurits Background Text', 'laurits-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
			]
		);

		$section->add_control(
			'qodef_enable_background_text',
			[
				'label'        => esc_html__( 'Enable Background Text', 'laurits-core'),
				'type'         => Elementor\Controls_Manager::SELECT,
				'default'      => 'no',
				'options' => [
					'no' => esc_html__('No', 'laurits-core')  ,
					'yes' => esc_html__('Yes', 'laurits-core')  ,
				],
				'render_type'  => 'template',
				'prefix_class' => 'qodef-backgound-letter-holder-'
			]
		);

		$section->add_control(
			'qodef_background_text',
			[
				'label'       => esc_html__( 'Letter', 'laurits-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'render_type' => 'template',
				'condition' => [
					'qodef_enable_background_text' => 'yes'
				],
				'description' => esc_html__( 'Type one character', 'laurits-core' )
			]
		);

		$section->add_control(
			'qodef_background_text_top',
			[
				'label'     => esc_html__( 'Top position (default value is 142px)', 'laurits-core' ),
				'type'      => Elementor\Controls_Manager::TEXT,
				'condition' => [
					'qodef_enable_background_text' => 'yes'
				],
				'render_type'  => 'template'
			]
		);

        $section->add_control(
            'qodef_background_text_appear_animation',
            [
                'label'       => esc_html__( 'Enable Background Text Appear Animation', 'laurits-core' ),
                'type'         => Elementor\Controls_Manager::SELECT,
                'default'      => 'no',
                'options' => [
                    'no' => esc_html__('No', 'laurits-core')  ,
                    'yes' => esc_html__('Yes', 'laurits-core')  ,
                ],
                'render_type' => 'template',
                'condition' => [
                    'qodef_enable_background_text' => 'yes'
                ]
            ]
        );

		$section->end_controls_section();
	}

	public function render_parallax_options( $section, $args ) {
		$section->start_controls_section(
			'qodef_parallax',
			[
				'label' => esc_html__( 'Laurits Parallax', 'laurits-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
			]
		);

		$section->add_control(
			'qodef_parallax_type',
			[
				'label'       => esc_html__( 'Enable Parallax', 'laurits-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'no',
				'options'     => [
					'no'       => esc_html__( 'No', 'laurits-core' ),
					'parallax' => esc_html__( 'Yes', 'laurits-core' ),
				],
				'render_type' => 'template',
			]
		);

		$section->add_control(
			'qodef_parallax_image',
			[
				'label'       => esc_html__( 'Parallax Background Image', 'laurits-core' ),
				'type'        => \Elementor\Controls_Manager::MEDIA,
				'condition'   => [
					'qodef_parallax_type' => 'parallax',
				],
				'render_type' => 'template',
			]
		);

		$section->end_controls_section();
	}

	public function render_offset_options( $section, $args ) {
		$section->start_controls_section(
			'qodef_offset',
			[
				'label' => esc_html__( 'Laurits Offset Image', 'laurits-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
			]
		);

		$section->add_control(
			'qodef_offset_type',
			[
				'label'       => esc_html__( 'Enable Offset Image', 'laurits-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'no',
				'options'     => [
					'no'     => esc_html__( 'No', 'laurits-core' ),
					'offset' => esc_html__( 'Yes', 'laurits-core' ),
				],
				'render_type' => 'template',
			]
		);

		$section->add_control(
			'qodef_offset_image',
			[
				'label'       => esc_html__( 'Offset Image', 'laurits-core' ),
				'type'        => \Elementor\Controls_Manager::MEDIA,
				'condition'   => [
					'qodef_offset_type' => 'offset',
				],
				'render_type' => 'template',
			]
		);

		$section->add_control(
			'qodef_offset_top',
			[
				'label'       => esc_html__( 'Offset Image Top Position', 'laurits-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '50%',
				'condition'   => [
					'qodef_offset_type' => 'offset',
				],
				'render_type' => 'template',
			]
		);

		$section->add_control(
			'qodef_offset_left',
			[
				'label'       => esc_html__( 'Offset Image Left Position', 'laurits-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '50%',
				'condition'   => [
					'qodef_offset_type' => 'offset',
				],
				'render_type' => 'template',
			]
		);

		$section->end_controls_section();
	}

	public function render_grid_options( $section, $args ) {
		$section->start_controls_section(
			'qodef_grid_row',
			[
				'label' => esc_html__( 'Laurits Grid', 'laurits-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
			]
		);

		$section->add_control(
			'qodef_enable_grid_row',
			[
				'label'        => esc_html__( 'Make this row "In Grid"', 'laurits-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => 'no',
				'options'      => [
					'no'   => esc_html__( 'No', 'laurits-core' ),
					'grid' => esc_html__( 'Yes', 'laurits-core' ),
				],
				'prefix_class' => 'qodef-elementor-content-',
			]
		);

		$section->add_control(
			'qodef_grid_row_behavior',
			[
				'label'        => esc_html__( 'Grid Row Behavior', 'laurits-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => '',
				'options'      => [
					''      => esc_html__( 'Default', 'laurits-core' ),
					'right' => esc_html__( 'Extend Grid Right', 'laurits-core' ),
					'left'  => esc_html__( 'Extend Grid Left', 'laurits-core' ),
				],
				'condition'    => [
					'qodef_enable_grid_row' => 'grid',
				],
				'prefix_class' => 'qodef-extended-grid qodef-extended-grid--',
			]
		);

		$section->end_controls_section();
	}

	public function section_before_render( $widget ) {
		$data     = $widget->get_data();
		$type     = isset( $data['elType'] ) ? $data['elType'] : 'section';
		$settings = $data['settings'];

		if ( 'section' === $type ) {
			if ( isset( $settings['qodef_parallax_type'] ) && 'parallax' === $settings['qodef_parallax_type'] ) {
				$parallax_type  = $widget->get_settings_for_display( 'qodef_parallax_type' );
				$parallax_image = $widget->get_settings_for_display( 'qodef_parallax_image' );

				if ( ! in_array( $data['id'], $this->sections, true ) ) {
					$this->sections[ $data['id'] ][] = array(
						'parallax_type'  => $parallax_type,
						'parallax_image' => $parallax_image,
					);
				}
			}

			if ( isset( $settings['qodef_offset_type'] ) && 'offset' === $settings['qodef_offset_type'] ) {
				$offset_type  = $widget->get_settings_for_display( 'qodef_offset_type' );
				$offset_image = $widget->get_settings_for_display( 'qodef_offset_image' );
				$offset_top   = $widget->get_settings_for_display( 'qodef_offset_top' );
				$offset_left  = $widget->get_settings_for_display( 'qodef_offset_left' );

				if ( ! in_array( $data['id'], $this->sections, true ) ) {
					$this->sections[ $data['id'] ][] = array(
						'offset_type'  => $offset_type,
						'offset_image' => $offset_image,
						'offset_top'   => $offset_top,
						'offset_left'  => $offset_left,
					);
				}
			}

			if ( isset( $settings['qodef_background_text'] ) && $settings['qodef_background_text'] !== '' && isset( $settings['qodef_enable_background_text'] ) && $settings['qodef_enable_background_text'] == 'yes' ) {
				$background_text                  = $widget->get_settings_for_display( 'qodef_background_text' );
				$background_text_top              = $widget->get_settings_for_display( 'qodef_background_text_top' );
				$background_text_appear_animation = $widget->get_settings_for_display( 'qodef_background_text_appear_animation' );

				if ( ! in_array( $data['id'], $this->background_text_sections ) ) {
					$this->background_text_sections[ $data['id'] ] = [ $background_text, $background_text_top, $background_text_appear_animation ];
				}
			}
		}
	}

	public function render_sticky_options( $section, $args ) {
		$section -> start_controls_section(
			'qodef_sticky_holder',
			[
				'label' => esc_html__( 'Laurits Core Sticky', 'laurits-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
			]
		);

		$section -> add_control(
			'qodef_sticky_enable',
			[
				'label'        => esc_html__( 'Make this column "Sticky"', 'laurits-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => '',
				'options'      => [
					''       => esc_html__( 'No', 'laurits-core' ),
					'column' => esc_html__( 'Yes', 'laurits-core' ),
				],
				'prefix_class' => 'qodef-sticky-',
			]
		);

		$section->add_control(
			'qodef_sticky_fixed',
			[
				'label'        => esc_html__( 'Make this column "Fixed"', 'laurits-core' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => '',
				'options'      => [
					''      => esc_html__( 'No', 'laurits-core' ),
					'fixed'      => esc_html__( 'Yes', 'laurits-core' ),
				],
				'condition'    => [
					'qodef_sticky_enable' => 'column',
				],
				'prefix_class' => 'qodef-sticky-',
			]
		);

		$section -> end_controls_section();
	}

	public function enqueue_styles() {
		wp_enqueue_style( 'laurits-core-elementor', LAURITS_CORE_PLUGINS_URL_PATH . '/elementor/assets/css/elementor.min.css' );
	}

	public function enqueue_scripts() {
		wp_enqueue_script( 'laurits-core-elementor', LAURITS_CORE_PLUGINS_URL_PATH . '/elementor/assets/js/elementor.min.js', array( 'jquery', 'elementor-frontend' ) );

		$elementor_global_vars = array(
			'elementorSectionHandler'        => $this->sections,
			'elementorBackgroundTextSection' => $this->background_text_sections
		);

		wp_localize_script(
			'laurits-core-elementor',
			'qodefElementorGlobal',
			array(
				'vars' => $elementor_global_vars,
			)
		);
	}
}

if ( ! function_exists( 'laurits_core_init_elementor_section_handler' ) ) {
	/**
	 * Function that initialize main page builder handler
	 */
	function laurits_core_init_elementor_section_handler() {
		LauritsCore_Elementor_Section_Handler::get_instance();
	}

	add_action( 'init', 'laurits_core_init_elementor_section_handler', 1 );
}
