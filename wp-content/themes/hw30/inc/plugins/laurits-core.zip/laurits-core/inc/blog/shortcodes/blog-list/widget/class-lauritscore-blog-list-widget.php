<?php

if ( ! function_exists( 'laurits_core_add_blog_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function laurits_core_add_blog_list_widget( $widgets ) {
		$widgets[] = 'LauritsCore_Blog_List_Widget';

		return $widgets;
	}

	add_filter( 'laurits_core_filter_register_widgets', 'laurits_core_add_blog_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class LauritsCore_Blog_List_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'laurits-core' ),
				)
			);
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'laurits_core_blog_list',
				)
			);

			if ( $widget_mapped ) {
				$this->set_base( 'laurits_core_blog_list' );
				$this->set_name( esc_html__( 'Laurits Blog List', 'laurits-core' ) );
				$this->set_description( esc_html__( 'Display a list of blog posts', 'laurits-core' ) );
			}
		}

		public function render( $atts ) {
			echo LauritsCore_Blog_List_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
