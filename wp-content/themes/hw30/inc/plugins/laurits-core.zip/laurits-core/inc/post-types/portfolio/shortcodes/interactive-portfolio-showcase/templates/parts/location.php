<?php
$portfolio_city    = get_post_meta( get_the_ID(), 'qodef_portfolio_item_city', true );
$portfolio_country = get_post_meta( get_the_ID(), 'qodef_portfolio_item_country', true );

if ( ! empty( $portfolio_city ) || ! empty( $portfolio_country ) ) { ?>
	<div class="qodef-e-location">
		<?php if ( ! empty( $portfolio_city ) ) { ?>
		<span class="qodef-e-city"><?php echo esc_html( $portfolio_city ); ?> </span>
		<?php } ?>
		<?php if ( ! empty( $portfolio_country ) ) { ?>
			<span class="qodef-e-country"><?php echo esc_html( $portfolio_country ); ?> </span>
		<?php } ?>
	</div>
<?php } ?>
