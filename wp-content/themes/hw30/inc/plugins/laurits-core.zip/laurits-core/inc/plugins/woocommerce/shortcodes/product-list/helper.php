<?php

if ( ! function_exists( 'laurits_core_product_list_filter_query' ) ) {
	/**
	 * Function to adjust query for listing list parameters
	 */
	function laurits_core_product_list_filter_query( $args, $params ) {

		switch ( $params['orderby'] ) {

			case 'price-range-high':
				$args['meta_query'] = array(
					array(
						'key' => '_price',
					),
				);

				$args['order']   = 'DESC';
				$args['orderby'] = 'meta_value_num';
				break;

			case 'price-range-low':
				$args['meta_query'] = array(
					array(
						'key' => '_price',
					),
				);

				$args['order']   = 'ASC';
				$args['orderby'] = 'meta_value_num';
				break;
		}

		return $args;
	}

	add_filter( 'laurits_filter_query_params', 'laurits_core_product_list_filter_query', 10, 2 );
}

if ( ! function_exists( 'laurits_core_get_product_list_query_order_by_array' ) ) {
	function laurits_core_get_product_list_query_order_by_array() {
		$include_order_by = array(
			'date'             => esc_html__( 'Latest Added', 'laurits-core' ),
			'price-range-high' => esc_html__( 'High to Low', 'laurits-core' ),
			'price-range-low'  => esc_html__( 'Low To High', 'laurits-core' ),
		);

		return laurits_core_get_select_type_options_pool( 'order_by', false, array( 'ID', 'menu_order', 'title', 'rand', 'name', 'date' ), $include_order_by );
	}
}


if ( ! function_exists( 'laurits_core_get_product_list_sorting_filter' ) ) {
	function laurits_core_get_product_list_sorting_filter() {
		$sorting_list_html = '';

		$include_order_by = laurits_core_get_product_list_query_order_by_array();

		foreach ( $include_order_by as $key => $value ) {
			$sorting_list_html .= '<li><a class="qodef-ordering-filter-link" data-ordering="' . $key . '" href="#">' . $value . '</a></li>';
		}

		return $sorting_list_html;
	}
}
