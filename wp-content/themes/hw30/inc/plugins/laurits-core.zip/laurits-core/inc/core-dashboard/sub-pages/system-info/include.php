<?php

include_once LAURITS_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-lauritscore-dashboard-system-info-page.php';
