<?php

if ( ! function_exists( 'laurits_core_add_portfolio_item_list_meta_boxes' ) ) {
	/**
	 * Function that add general meta box options for this module
	 *
	 * @param object $page
	 */
	function laurits_core_add_portfolio_item_list_meta_boxes( $page ) {

		if ( $page ) {

			$list_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-list',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'List Settings', 'laurits-core' ),
					'description' => esc_html__( 'Portfolio list settings', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_portfolio_list_image',
					'title'       => esc_html__( 'Portfolio List Image', 'laurits-core' ),
					'description' => esc_html__( 'Upload image to be displayed on portfolio list instead of featured image', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_portfolio_device_display_image_device',
					'title'         => esc_html__( 'Choose device to display in Device Display list type ', 'laurits-core' ),
					'description'   => esc_html__( 'Choose the device to be displayed in Device Display list type', 'laurits-core' ),
					'options'       => array(
						'mobile' => esc_html__( 'Mobile', 'laurits-core' ),
						'laptop' => esc_html__( 'Laptop', 'laurits-core' ),
					),
					'default-value' => 'mobile',
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_portfolio_device_display_first_image',
					'title'       => esc_html__( 'Portfolio Device Display List Image', 'laurits-core' ),
					'description' => esc_html__( 'Upload image to be displayed on portfolio list device display type instead of featured image', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_portfolio_device_display_second_image',
					'title'       => esc_html__( 'Portfolio Device Display List Second Image', 'laurits-core' ),
					'description' => esc_html__( 'Upload image to be displayed on portfolio list device display type instead of featured image', 'laurits-core' ),
					'dependency'  => array(
						'show' => array(
							'qodef_portfolio_device_display_image_device' => array(
								'values'        => array(
									'mobile',
								),
								'default_value' => 'mobile',
							),
						),
					),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_masonry_image_dimension_portfolio_item',
					'title'       => esc_html__( 'Image Dimension', 'laurits-core' ),
					'description' => esc_html__( 'Choose an image layout for "masonry behavior" portfolio list. If you are using fixed image proportions on the list, choose an option other than default', 'laurits-core' ),
					'options'     => laurits_core_get_select_type_options_pool( 'masonry_image_dimension' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_portfolio_item_letter',
					'title'       => esc_html__( 'Portfolio Item Letter', 'laurits-core' ),
					'description' => esc_html__( 'Input a letter that will be displayed in portfolio lists', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_portfolio_item_tag_line',
					'title'       => esc_html__( 'Portfolio Item Tag Line', 'laurits-core' ),
					'description' => esc_html__( 'Input a tag line that will be displayed in portfolio lists', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_portfolio_item_service',
					'title'       => esc_html__( 'Portfolio Item Service', 'laurits-core' ),
					'description' => esc_html__( 'Input service that will be displayed in interactive portfolio showcase', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_portfolio_item_city',
					'title'       => esc_html__( 'Portfolio Item City', 'laurits-core' ),
					'description' => esc_html__( 'Input city that will be displayed in interactive portfolio showcase', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_portfolio_item_country',
					'title'       => esc_html__( 'Portfolio Item Country', 'laurits-core' ),
					'description' => esc_html__( 'Input country that will be displayed in interactive portfolio showcase', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_portfolio_item_year',
					'title'       => esc_html__( 'Portfolio Item Year', 'laurits-core' ),
					'description' => esc_html__( 'Input year that will be displayed in interactive portfolio showcase', 'laurits-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_portfolio_item_padding',
					'title'       => esc_html__( 'Portfolio Item Custom Padding', 'laurits-core' ),
					'description' => esc_html__( 'Choose item padding when it appears in portfolio list (ex. 5% 5% 5% 5%)', 'laurits-core' ),
				)
			);

            $list_tab->add_field_element(
                array(
                    'field_type'    => 'yesno',
                    'name'          => 'qodef_portfolio_item_parallax_effect',
                    'title'         => esc_html__( 'Portfolio Item Parallax Effect', 'laurits-core' ),
                    'description'   => esc_html__( 'Enabling this option will add parallax effect to the item when it appears in portfolio list', 'laurits-core' ),
                    'default_value' => 'no',
                )
            );

			// Hook to include additional options after module options
			do_action( 'laurits_core_action_after_portfolio_list_meta_box_map', $list_tab );
		}
	}

	add_action( 'laurits_core_action_after_portfolio_meta_box_map', 'laurits_core_add_portfolio_item_list_meta_boxes' );
}
