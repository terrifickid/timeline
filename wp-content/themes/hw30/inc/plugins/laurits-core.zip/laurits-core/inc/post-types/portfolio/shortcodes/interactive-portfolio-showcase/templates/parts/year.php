<?php
$portfolio_year = get_post_meta( get_the_ID(), 'qodef_portfolio_item_year', true );

if ( ! empty( $portfolio_year ) ) { ?>
	<span class="qodef-e-year"><?php echo esc_html( $portfolio_year ); ?> </span>
<?php } ?>
