(function ($) {
	"use strict";
	
	$(window).on('load', function () {
		qodefPortfolioSticky.init('init');
	});
	
	$(window).resize(function () {
		qodefPortfolioSticky.init('resize');
	});
	
	var qodefPortfolioSticky = {
		pageOffset: '',
		scrollAmount: '',
		
		init: function (state) {
			var $holder = $('.qodef-portfolio-info-holder');
			
			if ($holder.length) {
				$holder.each(function () {
					qodefPortfolioSticky.calculateVars($(this), state);
				});
			}
		},
		calculateVars: function ($info, state) {
			var infoVars = {};
			
			infoVars.$infoInner = $info;
			
			infoVars.columnTopEdgePosition = $info.offset().top;
			infoVars.columnLeftEdgePosition = $info.offset().left;
			infoVars.columnWidth = $info.innerWidth();
			infoVars.columnHeight = $info.outerHeight();
			
			
			infoVars.$outerItem = $info.closest('.qodef-e-content-inner');
			
			
			infoVars.outerItemTopEdgePosition = infoVars.$outerItem.offset().top;
			infoVars.outerItemHeight = infoVars.$outerItem.height();
			infoVars.outerItemBottomEdgePosition = infoVars.outerItemTopEdgePosition + infoVars.outerItemHeight;
			qodefPortfolioSticky.scrollAmount = qodef.scroll;
			
			qodefPortfolioSticky.checkPosition(infoVars);
			
			$(window).scroll(function () {
				if ('init' === state) {
					var scrollDirection = qodefPortfolioSticky.checkScrollDirection();
				}
				
				qodefPortfolioSticky.checkPosition(infoVars, scrollDirection);
			});
		},
		checkPosition: function (infoVars, direction) {
			
			if (qodef.windowWidth > 1024) {
				qodefPortfolioSticky.calculateOffset();
				if ((qodef.scroll + qodefPortfolioSticky.pageOffset) <= infoVars.columnTopEdgePosition) {
					qodefPortfolioSticky.setPosition(infoVars, 'relative');
				}
				if (((qodef.scroll + qodefPortfolioSticky.pageOffset) >= infoVars.columnTopEdgePosition) && ((qodef.scroll + qodefPortfolioSticky.pageOffset + infoVars.columnHeight) < infoVars.outerItemBottomEdgePosition)) {
					qodefPortfolioSticky.setPosition(infoVars, 'fixed', direction);
				} else if ((qodef.scroll + qodefPortfolioSticky.pageOffset + infoVars.columnHeight) >= infoVars.outerItemBottomEdgePosition) {
					qodefPortfolioSticky.setPosition(infoVars, 'absolute');
				}
			} else {
				qodefPortfolioSticky.setPosition(infoVars, 'relative');
			}
		},
		calculateOffset: function () {
			qodefPortfolioSticky.pageOffset = 0;
			
			if ($('body').hasClass('admin-bar')) {
				qodefPortfolioSticky.pageOffset += 32;
			}
			
			if ($('body').hasClass('qodef-header--sticky-display') && $('.qodef-header-sticky').length) {
				qodefPortfolioSticky.pageOffset += parseInt($('.qodef-header-sticky').outerHeight(true));
			}
			
			if ($('body').hasClass('qodef-header--fixed-display')) {
				qodefPortfolioSticky.pageOffset += parseInt($('#qodef-page-header').outerHeight(true));
				qodefPortfolioSticky.pageOffset += parseInt($('#qodef-page-header').css('margin-top'));
			}
		},
		checkScrollDirection: function () {
			var scrollDirection = (qodef.scroll > qodefPortfolioSticky.scrollAmount) ? 'down' : 'up';
			
			qodefPortfolioSticky.scrollAmount = qodef.scroll;
			
			return scrollDirection;
		},
		setPosition: function (columnVars, position, direction) {
			if ('relative' === position) {
				columnVars.$infoInner.css({
					'bottom': 'auto',
					'left': 'auto',
					'position': 'relative',
					'top': 'auto',
					'width': columnVars.columnWidth,
					'transform': 'translateY(0)',
					'transition': 'none, padding .2s ease-out'
				});
				
				if ( columnVars.$infoInner.hasClass('qodef-scroll') ) {
					columnVars.$infoInner.removeClass('qodef-scroll');
				}
				
			}
			if ('fixed' === position) {
				if ($('body').hasClass('qodef-header--sticky-display')) {
					var transitionValue = ('up' === direction) ? 'none' : 'transform .5s ease';
				}
				
				columnVars.$infoInner.css({
					'bottom': 'auto',
					'left': columnVars.columnLeftEdgePosition,
					'position': 'fixed',
					'top': 0,
					'width': columnVars.columnWidth,
					'transform': 'translateY(' + qodefPortfolioSticky.pageOffset + 'px)',
					'transition': transitionValue + ', padding .2s ease-out'
				});
				
				if ( ! columnVars.$infoInner.hasClass('qodef-scroll') ) {
					columnVars.$infoInner.addClass('qodef-scroll');
				}
				
				columnVars.columnHeight = columnVars.$infoInner.outerHeight();
			}
			if ('absolute' === position) {
				columnVars.$infoInner.css({
					'bottom': '0',
					'left': '0',
					'position': 'absolute',
					'top': 'auto',
					'width': columnVars.columnWidth,
					'transform': 'translateY(0)',
					'transition': 'none, padding .2s ease-out'
				});
			}
		}
	};
	
	window.qodefPortfolioSticky = qodefPortfolioSticky;
})(jQuery);
