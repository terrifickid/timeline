<?php

class LauritsCore_Fullscreen_Portfolio_Slider_Shortcode_Elementor extends LauritsCore_Elementor_Widget_Base {

	function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'laurits_core_fullscreen_portfolio_slider' );

		parent::__construct( $data, $args );
	}
}

laurits_core_get_elementor_widgets_manager()->register_widget_type( new LauritsCore_Fullscreen_Portfolio_Slider_Shortcode_Elementor() );
