(function ($) {
	'use strict';
	
	var shortcode = 'laurits_core_blog_list';
	
	$(document).on(
		'laurits_trigger_get_new_posts',
		function (e, $holder, response, nextPage) {
			if ($holder.hasClass('qodef-blog')) {
				qodefBlogSortBy.init($holder, response, nextPage);
			}
			qodefBlogListDynamicImage.init();
		}
	);
	
	$(window).on(
		'load',
		function () {
			qodefBlogListDynamicImage.init();
			qodefBlogSortBy.init();
			qodefBlogListRemoveSideBorders.init();
			qodefBlogListAnimation.init();
		}
	);
	
	$(window).on(
		'resize',
		function () {
			qodefBlogListDynamicImage.init();
		}
	);
	
	var qodefBlogListDynamicImage = {
			init: function () {
				this.holder = $('.qodef-blog.qodef-dynaimc-image-height');
				
				if (this.holder.length) {
					this.holder.each(
						function () {
							var $list = $(this),
								items = $list.find('.qodef-blog-item');
							$list.waitForImages(
								function () {
									if (items.length) {
										items.each(
											function () {
												var item = $(this),
													innerHeight = item.find('.qodef-e-content-holder').outerHeight(),
													contentHeight = item.find('.qodef-e-content').outerHeight(),
													image = item.find('.qodef-e-media-image');
												
												if (image.length) {
													image.css('height', innerHeight - contentHeight);
												}
											}
										);
									}
								}
							);
						}
					);
				}
			}
		},
		qodefBlogSortBy = {
			init: function () {
				var $blogList = $('.qodef-blog.qodef-shortcode');
				
				if ($blogList.length) {
					$blogList.each(
						function () {
							var $thisBlogList = $(this),
								$fields = [];
							
							$fields.$orderbyFields = $blogList.find('.qodef-ordering-filter-link');
							$fields.orderbyFieldsExists = $fields.$orderbyFields.length;
							$fields.$categoryFields = $blogList.find('.qodef-m-filter-item');
							$fields.categoryFieldsExists = $fields.$categoryFields.length;
							
							qodefBlogSortBy.initFilter($thisBlogList, $fields);
							
						}
					);
				}
			},
			initFilter: function ($list, $fields) {
				var links = $list.find('.qodef-m-filter-item, .qodef-ordering-filter-link');
				
				links.on(
					'click',
					function (e) {
						e.preventDefault();
						e.stopPropagation();
						
						var clickedLink = $(this);
						if (!clickedLink.hasClass('qodef--active')) {
							
							clickedLink.addClass('qodef--active');
							clickedLink.parent().siblings().find('a').removeClass('qodef--active');
							
							var options = $list.data('options'),
								newOptions = {};
							
							if ($fields.orderbyFieldsExists) {
								$fields.$orderbyFields.each(
									function () {
										if ($(this).hasClass('qodef--active')) {
											var orderKey = 'order_by',
												value = $(this).data('ordering');
											
											if (typeof value !== "undefined" && value !== "") {
												newOptions[orderKey] = value;
											} else {
												newOptions[orderKey] = '';
											}
										}
									}
								);
							}
							
							if ($fields.categoryFieldsExists) {
								$fields.$categoryFields.each(
									function () {
										if ($(this).hasClass('qodef--active')) {
											var categoryKey = $(this).data('taxonomy'),
												value = $(this).data('filter');
											
											if (typeof value !== "undefined" && value !== "" && value !== "*") {
												newOptions[categoryKey] = value;
											} else {
												newOptions[categoryKey] = '';
											}
										}
									}
								);
							}
							
							var additional = qodefBlogSortBy.createAdditionalQuery(newOptions);
							
							$.each(
								additional,
								function (key, value) {
									options[key] = value;
								}
							);
							
							$list.data('options', options);
							
							qodef.body.trigger('laurits_trigger_load_more', [$list, 1]);
							
							qodefBlogListDynamicImage.init();
							
						}
					}
				);
			},
			createAdditionalQuery: function (newOptions) {
				var addQuery = {},
					taxQueryOptions = {},
					categories = $('.qodef-m-filter-item');
				
				addQuery.additional_query_args = {};
				addQuery.additional_query_args.tax_query = [];
				
				if (typeof newOptions === 'object') {
					$.each(
						newOptions,
						function (key, value) {
							
							switch (key) {
								case 'order_by':
									addQuery.orderby = newOptions.order_by;
									break;
								case 'category':
									taxQueryOptions = {
										0: {
											taxonomy: 'category',
											field: typeof value === 'number' ? 'term_id' : 'slug',
											terms: value,
										}
									};
									break;
								case 'post_tag':
									taxQueryOptions = {
										0: {
											taxonomy: 'post_tag',
											field: typeof value === 'number' ? 'term_id' : 'slug',
											terms: value,
										}
									};
							}
						}
					);
					
					if (categories.length && taxQueryOptions[0].terms.length > 0) {
						addQuery.additional_query_args = {
							tax_query: taxQueryOptions,
						};
					}
				}
				
				return addQuery;
			},
		},
		qodefBlogListRemoveSideBorders = {
			init: function () {
				var page = $('#qodef-page-content');
				this.holder = page.find('.qodef-blog.qodef-item-border--yes.qodef-side-border--off');
				
				if (this.holder.length) {
					this.holder.each(
						function () {
							var $list = $(this),
								body = $('body'),
								editor = body.hasClass('elementor-page') ? 'elementor' : 'wp_bakery',
								grid = $list.find('.qodef-grid-inner'),
								backgroundVars = {},
								color = '#fff';
							
							if ('elementor' === editor) {
								backgroundVars.$widgetBackgroundColor = $list.closest('.elementor-widget-container').css('background-color');
								backgroundVars.$columnBackgroundColor = $list.closest('.elementor-column-wrap').css('background-color');
								backgroundVars.$sectionBackgroundColor = $list.closest('section.elementor-element').css('background-color');
								backgroundVars.$pageBackground = body.css('background-color');
							} else {
								backgroundVars.$widgetBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
								backgroundVars.$columnBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
								backgroundVars.$sectionBackgroundColor = $list.closest('.vc_row').css('background-color');
								backgroundVars.$pageBackground = body.css('background-color');
							}
							if ('undefined' !== typeof backgroundVars.$widgetBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$widgetBackgroundColor) {
								color = backgroundVars.$widgetBackgroundColor;
							} else if ('undefined' !== typeof backgroundVars.$columnBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$columnBackgroundColor) {
								color = backgroundVars.$columnBackgroundColor;
							} else if ('undefined' !== typeof backgroundVars.$sectionBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$sectionBackgroundColor) {
								color = backgroundVars.$sectionBackgroundColor;
							} else if ('undefined' !== typeof backgroundVars.$pageBackground && 'rgba(0, 0, 0, 0)' !== backgroundVars.$pageBackground) {
								color = backgroundVars.$pageBackground;
							}
							
							grid.css('color', color);
						}
					);
				}
			}
		},
		qodefBlogListAnimation = {
			init () {
				this.blog = $('.qodef-blog');

				if ( this.blog.length ) {
					this.blog.each(
						( index, element ) => {
							const $thisBlogList = $( element );

							if ( $thisBlogList.hasClass('qodef-hover-animation--yes') ) {
								qodefBlogListAnimation.linkHover( $thisBlogList );
							}

							if ( $thisBlogList.hasClass('qodef-appear-animation--yes') ) {
								qodefBlogListAnimation.appearAnimation( $thisBlogList );
							}
						}
					);
				}
			},
			linkHover ( $holder ) {
				const $items = $holder.find('.qodef-blog-item');

				$items.each(
					( index, element ) => {
						const $thisItem = $( element ),
							$itemMedia = $thisItem.find('.qodef-e-media-image'),
							$titleLink = $thisItem.find('.qodef-e-title-link');

						if ( $itemMedia.length ) {
							$itemMedia.on(
								'mouseenter',
								() => {
									$thisItem.addClass('qodef--active');
								}
							);

							$itemMedia.on(
								'mouseleave',
								() => {
									$thisItem.removeClass('qodef--active');
								}
							);
						}

						if ( $titleLink.length ) {
							$titleLink.on(
								'mouseenter',
								() => {
									$thisItem.addClass('qodef--active');
								}
							);

							$titleLink.on(
								'mouseleave',
								() => {
									$thisItem.removeClass('qodef--active');
								}
							);
						}
					}
				);
			},
			appearAnimation ( $holder ) {
				const delay = $holder.data('appearing-delay');
				qodefCore.qodefIsInViewport.check(
					$holder,
					() => {
						const $items = $holder.find('.qodef-e');
						$holder.addClass('qodef--appeared');

						if ( $items.length ) {
							$items.each(
								( index, element ) => {
									const $thisItem = $( element );

									if ( $holder.hasClass('qodef-filter--on') ) {
										setTimeout(
											() => {
												$thisItem.addClass('qodef--appeared');
											}, index * 160 + 180 + delay
										);
									} else {
										setTimeout(
											() => {
												$thisItem.addClass('qodef--appeared');
											}, index * 160 + delay
										);
									}

									if ( $thisItem.hasClass('qodef-parallax-effect--yes') ) {
										$thisItem.attr(
											'data-parallax',
											'{"y": -80, "smoothness": 100}'
										);

										qodefPortfolioAnimationEffects.initItems();
									}
								}
							)
						}
					}
				);
			}
		};
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(
			qodefCore.listShortcodesScripts,
			function (key, value) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}
	
	qodefCore.shortcodes[shortcode].qodefResizeIframes = qodef.qodefResizeIframes;
	qodefCore.shortcodes[shortcode].qodefBlogListDynamicImage = qodefBlogListDynamicImage;
	qodefCore.shortcodes[shortcode].qodefBlogSortBy = qodefBlogSortBy;
	qodefCore.shortcodes[shortcode].qodefBlogListRemoveSideBorders = qodefBlogListRemoveSideBorders;
	
})(jQuery);
