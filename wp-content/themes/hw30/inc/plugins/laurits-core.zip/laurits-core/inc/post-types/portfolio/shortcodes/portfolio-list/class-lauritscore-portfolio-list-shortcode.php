<?php

if ( ! function_exists( 'laurits_core_add_portfolio_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function laurits_core_add_portfolio_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'LauritsCore_Portfolio_List_Shortcode';

		return $shortcodes;
	}

	add_filter( 'laurits_core_filter_register_shortcodes', 'laurits_core_add_portfolio_list_shortcode' );
}

if ( class_exists( 'LauritsCore_List_Shortcode' ) ) {
	class LauritsCore_Portfolio_List_Shortcode extends LauritsCore_List_Shortcode {

		public function __construct() {
			$this->set_post_type( 'portfolio-item' );
			$this->set_post_type_taxonomy( 'portfolio-category' );
			$this->set_post_type_additional_taxonomies( array( 'portfolio-tag' ) );
			$this->set_layouts( apply_filters( 'laurits_core_filter_portfolio_list_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'laurits_core_filter_portfolio_list_extra_options', array() ) );
			$this->set_hover_animation_options( apply_filters( 'laurits_core_filter_portfolio_list_hover_animation_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( LAURITS_CORE_CPT_URL_PATH . '/portfolio/shortcodes/portfolio-list' );
			$this->set_base( 'laurits_core_portfolio_list' );
			$this->set_name( esc_html__( 'Portfolio List', 'laurits-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of portfolios', 'laurits-core' ) );
			$this->set_category( esc_html__( 'Laurits Core', 'laurits-core' ) );
			$this->set_scripts( apply_filters( 'laurits_core_filter_portfolio_list_register_assets', array() ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'laurits-core' ),
				)
			);
			$this->map_list_options(
				array(
					'exclude_behavior' => array( 'justified-gallery' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'display_tag_line',
					'title'         => esc_html__( 'Display Item Tag Line', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'display_letter',
					'title'         => esc_html__( 'Display Item Letter', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'display_item_border',
					'title'         => esc_html__( 'Display Item Border', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'remove_side_borders',
					'title'         => esc_html__( 'Remove Side Borders', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'equal_height',
					'title'         => esc_html__( 'Equal Item Height', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
					'dependency'    => array(
						'show' => array(
							'behavior' => array(
								'values'        => array( 'columns' ),
								'default_value' => 'columns',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'display_show_more',
					'title'         => esc_html__( 'Enable Show More', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'show_more_link',
					'title'      => esc_html__( 'Show More Link', 'laurits-core' ),
					'dependency' => array(
						'show' => array(
							'display_show_more' => array(
								'values'        => 'yes',
								'default_value' => 'no',
							),
						),
					),
				)
			);
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->map_layout_options(
				array(
					'layouts'          => $this->get_layouts(),
					'hover_animations' => $this->get_hover_animation_options(),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'custom_padding',
					'title'         => esc_html__( 'Use Item Custom Padding', 'laurits-core' ),
					'description'   => esc_html__( 'If you set this option to “Yes”, the padding values defined in the Portfolio Item Custom Padding field will be applied', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
					'dependency'    => array(
						'show' => array(
							'behavior' => array(
								'values'        => array( 'columns', 'masonry' ),
								'default_value' => 'columns',
							),
						),
					),
					'group'         => esc_html__( 'Layout', 'laurits-core' ),
				)
			);
            $this->set_option(
                array(
                    'field_type'    => 'select',
                    'name'          => 'items_appear_animation',
                    'title'         => esc_html__( 'Enable Items Appear Animation', 'laurits-core' ),
                    'options'       => laurits_core_get_select_type_options_pool( 'yes_no', false ),
                    'default_value' => 'no',
                    'group'         => esc_html__( 'Animation Options', 'laurits-core' )
                )
            );
            $this->set_option(
                array(
                    'field_type' => 'text',
                    'name'       => 'appear_animation_delay',
                    'title'      => esc_html__( 'Appear Animation Delay (ms)', 'laurits-core' ),
                    'group'      => esc_html__( 'Animation Options', 'laurits-core' ),
                    'dependency' => array(
                        'show' => array(
                            'items_appear_animation' => array(
                                'values'        => 'yes',
                                'default_value' => 'no',
                            ),
                        ),
                    ),
                )
            );
            $this->set_option(
                array(
                    'field_type'    => 'select',
                    'name'          => 'borders_appear_animation',
                    'title'         => esc_html__( 'Enable Borders Appear Animation', 'laurits-core' ),
                    'options'       => laurits_core_get_select_type_options_pool( 'yes_no', false ),
                    'default_value' => 'no',
                    'group'         => esc_html__( 'Animation Options', 'laurits-core' ),
                    'dependency'    => array(
                        'show' => array(
                            'display_item_border' => array(
                                'values'        => 'yes',
                                'default_value' => 'no'
                            )
                        )
                    )
                )
            );
            $this->set_option(
                array(
                    'field_type'    => 'select',
                    'name'          => 'hr_borders_appear_animation',
                    'title'         => esc_html__( 'Enable Horizontal Borders Appear Animation', 'laurits-core' ),
                    'options'       => laurits_core_get_select_type_options_pool( 'yes_no', false ),
                    'default_value' => 'no',
                    'group'         => esc_html__( 'Animation Options', 'laurits-core' ),
                    'dependency'    => array(
                        'show' => array(
                            'layout' => array(
                                'values'        => 'image-on-hover',
                                'default_value' => ''
                            )
                        )
                    )
                )
            );
			$this->map_additional_options();
			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'laurits_core_portfolio_list', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function load_assets() {
			parent::load_assets();

			do_action( 'laurits_core_action_portfolio_list_load_assets', $this->get_atts() );
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_filter_taxonomy( $atts );

			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );

			$atts['query_result']   = new \WP_Query( laurits_core_get_query_params( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
            $atts['holder_data']    = $this->get_holder_data( $atts );
			$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['data_attr']      = laurits_core_get_pagination_data( LAURITS_CORE_REL_PATH, 'post-types/portfolio/shortcodes', 'portfolio-list', 'portfolio', $atts );

			$atts['this_shortcode'] = $this;

			return laurits_core_get_template_part( 'post-types/portfolio/shortcodes/portfolio-list', 'templates/content', $atts['behavior'], $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-portfolio-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['display_item_border'] ) ? 'qodef-item-border--' . $atts['display_item_border'] : '';
			$holder_classes[] = ! empty( $atts['equal_height'] ) && 'yes' === $atts['equal_height'] ? 'qodef-item-equal-heigth' : '';
			$holder_classes[] = 'yes' === $atts['remove_side_borders'] ? 'qodef-side-border--off' : 'qodef-side-border--on';
			$holder_classes[] = 'yes' === $atts['custom_padding'] ? 'qodef--custom-padding' : '';
            $holder_classes[] = ! empty( $atts['items_appear_animation'] ) ? 'qodef-appear-animation--' . $atts['items_appear_animation'] : '';
            $holder_classes[] = ! empty( $atts['borders_appear_animation'] ) ? 'qodef-borders-animation--' . $atts['borders_appear_animation'] : '';
            $holder_classes[] = ! empty( $atts['hr_borders_appear_animation'] ) ? 'qodef-hr-borders-animation--' . $atts['hr_borders_appear_animation'] : '';

            $list_classes            = $this->get_list_classes( $atts );
			$hover_animation_classes = $this->get_hover_animation_classes( $atts );
			$holder_classes          = array_merge( $holder_classes, $list_classes, $hover_animation_classes );

			return implode( ' ', $holder_classes );
		}

        private function get_holder_data( $atts ) {
            $data = array();

            $data['data-appearing-delay'] = ! empty( $atts['appear_animation_delay'] ) ? intval( $atts['appear_animation_delay'] ) : 0;

            return $data;
        }

		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();

			$list_item_classes = $this->get_list_item_classes( $atts );

			$item_classes = array_merge( $item_classes, $list_item_classes );

			return implode( ' ', $item_classes );
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}

			return $styles;
		}

		public function get_list_item_style( $atts ) {
			$styles = array();

			if ( isset( $atts['custom_padding'] ) && 'yes' === $atts['custom_padding'] ) {
				$styles[] = 'padding: ' . get_post_meta( get_the_ID(), 'qodef_portfolio_item_padding', true );
			}

			return $styles;
		}
	}
}
