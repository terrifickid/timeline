(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefTabbedNavMenu.init();
		}
	);

	var qodefTabbedNavMenu = {

		init: function () {
				var $holder = $( '.qodef-header--tabbed #qodef-page-header' );

			if ( $holder.length ) {
				$holder.each(
					function () {
						qodefTabbedNavMenu.initItem( $( this ) );
					}
				);
			}
		},

		initItem: function ( $currentHeader ) {
			var $logo 	  = $currentHeader.find( '#qodef-page-header-inner .qodef-header-logo-link' );
			var $menuItem = $currentHeader.find( '#qodef-page-header-inner .qodef-header-navigation > ul > li' );
			var $widget   = $currentHeader.find( '#qodef-page-header-inner .qodef-widget-holder .widget' );
			var $width 	  = $( window ).width();

			var $headerItems = $logo.add( $menuItem ).add( $widget );

			$headerItems.css( 'width', 'calc( ' + $width / ( $logo.length + $menuItem.length + $widget.length ) + 'px )' );
		},

	};

})( jQuery );
