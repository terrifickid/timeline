(function ( $ ) {
	'use strict';
	
	$( document ).on(
		'laurits_trigger_get_new_posts',
		function () {
			qodefPortfolioEqualHeight.init();
		}
	);
	
	$( window ).on(
		'load',
		function () {
			qodefPortfolioEqualHeight.init();
			qodefPortfolioListRemoveSideBorders.init();
			qodefPortfolioAnimationEffects.init();
		}
	);
	
	var shortcode = 'laurits_core_portfolio_list';
	
	var qodefPortfolioEqualHeight = {
		init: function () {
			this.holder = $('.qodef-portfolio-list.qodef-layout--columns.qodef-item-equal-heigth');
			
			if ( this.holder.length && this.holder.hasClass('qodef-item-border--yes') ) {
				this.holder.each(
					function () {
						var $list = $( this ),
							items = $list.find('.qodef-e.qodef-grid-item'),
							maxHeight = 0;
						
						$list.waitForImages( function () {
							if ( items.length ) {
								items.each(
									function () {
										var item = $( this );
										
										if ( item.outerHeight() > maxHeight ) {
											maxHeight = item.outerHeight();
										}
									}
								);
								
								items.each(
									function () {
										var item = $( this );
										item.css('height', maxHeight);
									}
								);
							}
						});
					}
				);
			}
		}
	},
	qodefPortfolioListRemoveSideBorders = {
		init: function () {
			var page = $('#qodef-page-content');
			this.holder = page.find('.qodef-portfolio-list.qodef-item-border--yes.qodef-side-border--off');
			
			if ( this.holder.length ) {
				this.holder.each(
					function () {
						var $list = $( this ),
							body = $( 'body' ),
							editor = body.hasClass('elementor-page') ? 'elementor' : 'wp_bakery',
							grid = $list.find('.qodef-grid-inner'),
							backgroundVars = {},
							color = '#fff';
						
						if ('elementor' === editor) {
							backgroundVars.$widgetBackgroundColor = $list.closest('.elementor-widget-container').css('background-color');
							backgroundVars.$columnBackgroundColor = $list.closest('.elementor-column-wrap').css('background-color');
							backgroundVars.$sectionBackgroundColor = $list.closest('section.elementor-element').css('background-color');
							backgroundVars.$pageBackground = body.css('background-color');
						} else {
							backgroundVars.$widgetBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
							backgroundVars.$columnBackgroundColor = $list.closest('.vc_column-inner').css('background-color');
							backgroundVars.$sectionBackgroundColor = $list.closest('.vc_row').css('background-color');
							backgroundVars.$pageBackground = body.css('background-color');
						}
						if ( 'undefined' !== typeof backgroundVars.$widgetBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$widgetBackgroundColor ) {
							color = backgroundVars.$widgetBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$columnBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$columnBackgroundColor ) {
							color = backgroundVars.$columnBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$sectionBackgroundColor && 'rgba(0, 0, 0, 0)' !== backgroundVars.$sectionBackgroundColor ) {
							color = backgroundVars.$sectionBackgroundColor;
						} else if ( 'undefined' !== typeof backgroundVars.$pageBackground && 'rgba(0, 0, 0, 0)' !== backgroundVars.$pageBackground ) {
							color = backgroundVars.$pageBackground;
						}
						
						grid.css('color', color);
					}
				);
			}
		}
	},
	qodefPortfolioAnimationEffects = {
		init () {
			const $holders = $('.qodef-portfolio-list.qodef-appear-animation--yes');

			if ( $holders.length ) {
				$holders.each(
					( index, element ) => {
						const $thisHolder = $( element );
						const delay       = $thisHolder.data('appearing-delay');
						$thisHolder.addClass('qodef--appeared');

						qodefCore.qodefIsInViewport.check(
							$thisHolder,
							() => {
								const $items = $thisHolder.find('.qodef-e');

								if ( $items.length ) {
									$items.each(
										( index, element ) => {
											const $thisItem = $( element );

											if ( $thisHolder.hasClass('qodef-borders-animation--yes') ) {
												setTimeout(
													() => {
														$thisItem.addClass('qodef--appeared');
													}, index * 160 + 400 + delay
												);
											} else {
												setTimeout(
													() => {
														$thisItem.addClass('qodef--appeared');
													}, index * 160 + delay
												);
											}

											if ( $thisItem.hasClass('qodef-parallax-effect--yes') ) {
												$thisItem.attr(
													'data-parallax',
													'{"y": -80, "smoothness": 100}'
												);

												qodefPortfolioAnimationEffects.initItems();
											}
										}
									)
								}
							}
						);
					}
				)
			}
		},
		initItems() {
			const parallaxInstances = $('[data-parallax]');

			if ( parallaxInstances.length && ! qodefCore.html.hasClass( 'touchevents' ) && typeof ParallaxScroll === 'object' ) {
				ParallaxScroll.init(); //initialization removed from plugin js file to have it run only on non-touch devices
			}
		}
	};
	
	qodefCore.shortcodes[shortcode] = {};
	qodefCore.shortcodes[shortcode].qodefPortfolioEqualHeight = qodefPortfolioEqualHeight;
	qodefCore.shortcodes[shortcode].qodefPortfolioListRemoveSideBorders = qodefPortfolioListRemoveSideBorders;

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}
	
})( jQuery );
