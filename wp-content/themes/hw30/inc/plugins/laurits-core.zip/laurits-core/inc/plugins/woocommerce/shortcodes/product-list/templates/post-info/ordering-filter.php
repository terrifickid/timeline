<?php if ( 'yes' === $show_ordering_filter ) { ?>
	<div class="qodef-woo-ordering-outer">
		<h5 class="qodef-woo-ordering-label"><?php esc_html_e( 'Sort by +', 'laurits-core' ); ?>
		</h5>
		<div class="qodef-woo-ordering">
			<div>
				<ul>
					<?php echo laurits_core_get_product_list_sorting_filter( $params ); ?>
				</ul>
			</div>
		</div>
	</div>
<?php } ?>
