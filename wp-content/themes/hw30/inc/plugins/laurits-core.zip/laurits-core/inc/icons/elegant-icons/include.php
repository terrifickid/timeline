<?php

include_once LAURITS_CORE_INC_PATH . '/icons/elegant-icons/class-lauritscore-elegant-icons-pack.php';
