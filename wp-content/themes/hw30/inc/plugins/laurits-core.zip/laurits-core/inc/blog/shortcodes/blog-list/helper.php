<?php

if ( ! function_exists( 'laurits_core_blog_list_filter_query' ) ) {
	/**
	 * Function to adjust query for listing list parameters
	 */
	function laurits_core_blog_list_filter_query( $args, $params ) {

		switch ( $params['orderby'] ) {

			case 'popularity':
				$args['meta_query'] = array(
					array(
						'key' => 'qode_count_post_views_meta',
					),
				);
				$args['order']      = 'DESC';
				$args['orderby']    = 'meta_value_num';
				break;
			case 'most-comments':
				$args['order']   = 'DESC';
				$args['orderby'] = 'comment_count';
				break;
		}

		return $args;
	}

	add_filter( 'laurits_filter_query_params', 'laurits_core_blog_list_filter_query', 10, 2 );
}

if ( ! function_exists( 'laurits_core_get_blog_list_query_order_by_array' ) ) {
	function laurits_core_get_blog_list_query_order_by_array() {
		$include_order_by = array(
			'date'          => esc_html__( 'Latest Added', 'laurits-core' ),
			'popularity'    => esc_html__( 'Popularity', 'laurits-core' ),
			'most-comments' => esc_html__( 'Most Comments', 'laurits-core' ),
		);

		return laurits_core_get_select_type_options_pool( 'order_by', false, array( 'ID', 'menu_order', 'title', 'rand', 'name', 'date' ), $include_order_by );
	}
}


if ( ! function_exists( 'laurits_core_get_blog_list_sorting_filter' ) ) {
	function laurits_core_get_blog_list_sorting_filter() {
		$sorting_list_html = '';

		$include_order_by = laurits_core_get_blog_list_query_order_by_array();

		foreach ( $include_order_by as $key => $value ) {
			$sorting_list_html .= '<li><a class="qodef-ordering-filter-link" data-ordering="' . $key . '" href="#">' . $value . '</a></li>';
		}

		return $sorting_list_html;
	}
}

if ( ! function_exists( 'qode_blog_update_post_count_views' ) ) {
	function qode_blog_update_post_count_views() {
		$post_ID = get_the_ID();

		if ( is_singular( 'post' ) ) {
			if ( isset( $_COOKIE[ 'qode-post-views_' . $post_ID ] ) ) {
				return;
			} else {
				$count = get_post_meta( $post_ID, 'qode_count_post_views_meta', true );
				if ( '' === $count ) {
					update_post_meta( $post_ID, 'qode_count_post_views_meta', 1 );
					setcookie( 'qode-post-views_' . $post_ID, $post_ID, intval( time() * 20 ), '/' );
				} else {
					$count ++;
					update_post_meta( $post_ID, 'qode_count_post_views_meta', $count );
					setcookie( 'qode-post-views_' . $post_ID, $post_ID, intval( time() * 20 ), '/' );
				}
			}
		}
	}

	add_action( 'wp', 'qode_blog_update_post_count_views' );
}
