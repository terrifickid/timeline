<?php
$item_id     = get_the_ID();
$title_tag   = 'h4';
$link        = get_post_meta( $item_id, 'qodef_client_link', true );
$link_target = get_post_meta( $item_id, 'qodef_client_link_target', true );
$link_target = ! empty( $link_target ) ? $link_target : '_blank';
?>
<<?php echo esc_attr( $title_tag ); ?> itemprop="name" class="qodef-e-title entry-title" <?php qode_framework_inline_style( $this_shortcode->get_title_styles( $params ) ); ?>>
	<a itemprop="url" class="qodef-e-title-link" href="<?php echo esc_url( $link ); ?>" target="<?php echo esc_attr( $link_target ); ?>">
		<?php the_title(); ?>
	</a>
</<?php echo esc_attr( $title_tag ); ?>>
