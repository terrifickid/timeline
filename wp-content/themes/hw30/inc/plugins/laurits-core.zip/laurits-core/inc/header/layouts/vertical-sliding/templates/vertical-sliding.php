<?php
do_action( 'laurits_action_before_page_header' );
$style = array();

$background_color_vertical_sliding = laurits_core_get_post_value_through_levels( 'qodef_vertical_sliding_header_background_color' );

if ( ! empty( $background_color_vertical_sliding ) ) {
	$style[] = 'background-color: ' . $background_color_vertical_sliding;
}

?>

<header id="qodef-page-header" role="banner">
	<div id="qodef-page-header-inner" class="<?php echo implode( ' ', apply_filters( 'laurits_filter_header_inner_class', array(), 'default' ) ); ?>">
		<div class="qodef-vertical-sliding-area qodef--static" <?php qode_framework_inline_style( $style ); ?>>
			<?php
			// include logo
			laurits_core_get_header_logo_image();

			// include opener
			laurits_core_get_opener_icon_html(
				array(
					'option_name'  => 'vertical_sliding_menu',
					'custom_class' => 'qodef-vertical-sliding-menu-opener',
				),
				true
			);

			// include widget area one
			laurits_core_get_header_widget_area();
			?>
		</div>
		<div class="qodef-vertical-sliding-area qodef--dynamic" <?php qode_framework_inline_style( $style ); ?>>
			<?php
			// include vertical sliding navigation
			laurits_core_template_part( 'header', 'layouts/vertical-sliding/templates/navigation' );
			?>
		</div>
	</div>
</header>
