<?php
$portfolio_tag_line = get_post_meta( get_the_ID(), 'qodef_portfolio_item_tag_line', true );

if ( ! empty( $portfolio_tag_line ) && 'yes' === $display_tag_line ) { ?>
	<span class="qodef-e-tag-line"><?php echo esc_html( $portfolio_tag_line ); ?> </span>
<?php } ?>
