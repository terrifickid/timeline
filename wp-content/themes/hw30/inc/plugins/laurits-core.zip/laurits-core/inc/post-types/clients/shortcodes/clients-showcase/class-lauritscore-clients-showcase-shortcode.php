<?php

if ( ! function_exists( 'laurits_core_add_clients_showcase_shortcode' ) ) {
	/**
	 * Function that is adding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function laurits_core_add_clients_showcase_shortcode( $shortcodes ) {
		$shortcodes[] = 'LauritsCore_Clients_Showcase_Shortcode';

		return $shortcodes;
	}

	add_filter( 'laurits_core_filter_register_shortcodes', 'laurits_core_add_clients_showcase_shortcode' );
}

if ( class_exists( 'LauritsCore_List_Shortcode' ) ) {
	class LauritsCore_Clients_Showcase_Shortcode extends LauritsCore_List_Shortcode {

		public function __construct() {
			$this->set_post_type( 'clients' );
			$this->set_post_type_taxonomy( 'clients-category' );
			$this->set_layouts( apply_filters( 'laurits_core_filter_clients_showcase_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'laurits_core_filter_clients_showcase_extra_options', array() ) );
			$this->set_hover_animation_options( apply_filters( 'laurits_core_filter_clients_showcase_hover_animation_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( LAURITS_CORE_CPT_URL_PATH . '/clients/shortcodes/clients-showcase' );
			$this->set_base( 'laurits_core_clients_showcase' );
			$this->set_name( esc_html__( 'Clients Showcase', 'laurits-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays clients in a showcase layout', 'laurits-core' ) );
			$this->set_category( esc_html__( 'Laurits Core', 'laurits-core' ) );
			$this->set_scripts();
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'laurits-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'behavior',
					'title'         => esc_html__( 'List Appearance', 'laurits-core' ),
					'options'       => array(
						'clients-showcase' => esc_html__( 'Clients Showcase', 'laurits-core' ),
					),
					'default_value' => 'clients-showcase',
					'visibility'    => array( 'map_for_page_builder' => false ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Item Layout', 'laurits-core' ),
					'options'       => array(
						'image-on-hover' => esc_html__( 'Image On Hover', 'laurits-core' ),
					),
					'default_value' => 'image-on-hover',
					'group'         => esc_html__( 'Layout', 'laurits-core' ),
					'visibility'    => array( 'map_for_page_builder' => false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'tagline',
					'title'      => esc_html__( 'Tagline', 'laurits-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'textarea',
					'name'       => 'info_text',
					'title'      => esc_html__( 'Info Text', 'laurits-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'line_break_positions',
					'title'       => esc_html__( 'Positions of Line Break', 'laurits-core' ),
					'description' => esc_html__( 'Enter the positions of the words after which you would like to create a line break. Separate the positions with commas (e.g. if you would like the first, third, and fourth word to have a line break, you would enter "1,3,4")', 'laurits-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'disable_info_text_break_words',
					'title'         => esc_html__( 'Disable Info Text Line Break', 'laurits-core' ),
					'description'   => esc_html__( 'Enabling this option will disable info text line breaks for screen size 1440 and lower', 'laurits-core' ),
					'options'       => laurits_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'items_padding',
					'title'      => esc_html__( 'Items Padding', 'laurits-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'image_position',
					'title'      => esc_html__( 'Image Position', 'laurits-core' ),
					'options'    => array(
						'left'  => esc_html__( 'Left', 'laurits-core' ),
						'right' => esc_html__( 'Right', 'laurits-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'enable_border',
					'title'      => esc_html__( 'Enable Border', 'laurits-core' ),
					'options'    => laurits_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'items_direction',
					'title'      => esc_html__( 'Items Direction', 'laurits-core' ),
					'options'    => array(
						'vertical'   => esc_html__( 'Vertical', 'laurits-core' ),
						'horizontal' => esc_html__( 'Horizontal', 'laurits-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'section_layout',
					'title'      => esc_html__( 'Section Layout', 'laurits-core' ),
					'options'    => array(
						'equal'       => esc_html__( 'Equal', 'laurits-core' ),
						'wide-images' => esc_html__( 'Wide Images', 'laurits-core' ),
						'wide-items'  => esc_html__( 'Wide Items', 'laurits-core' ),
					),
				)
			);
			$this->map_query_options(
				array(
					'post_type' => $this->get_post_type(),
				)
			);
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'laurits_core_clients_showcase', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function load_assets() {
			parent::load_assets();

			do_action( 'laurits_core_action_clients_showcase_load_assets', $this->get_atts() );
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_filter_taxonomy( $atts );

			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );

			$atts['query_result']   = new \WP_Query( laurits_core_get_query_params( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['info_text']      = $this->get_modified_info_text( $atts );
			$atts['items_styles']   = $this->get_items_styles( $atts );
			$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['data_attr']      = laurits_core_get_pagination_data( LAURITS_CORE_REL_PATH, 'post-types/clients/shortcodes', 'clients-showcase', 'clients', $atts );

			$atts['this_shortcode'] = $this;

			return laurits_core_get_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/content', $atts['behavior'], $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-clients-showcase';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['image_position'] ) ? 'qodef-image-position--' . $atts['image_position'] : '';
			$holder_classes[] = ! empty( $atts['enable_border'] ) && 'yes' === $atts['enable_border'] ? 'qodef-border-enabled' : '';
			$holder_classes[] = ! empty( $atts['items_direction'] ) ? 'qodef-items-direction--' . $atts['items_direction'] : '';
			$holder_classes[] = ! empty( $atts['section_layout'] ) ? 'qodef-section-layout--' . $atts['section_layout'] : '';
			$holder_classes[] = 'yes' === $atts['disable_info_text_break_words'] ? 'qodef-info-text-break--disabled' : '';

			$list_classes            = $this->get_list_classes( $atts );
			$hover_animation_classes = $this->get_hover_animation_classes( $atts );
			$holder_classes          = array_merge( $holder_classes, $list_classes, $hover_animation_classes );

			return implode( ' ', $holder_classes );
		}

		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();

			return implode( ' ', $item_classes );
		}

		public function get_items_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['items_padding'] ) ) {
				$styles[] = 'padding-top: ' . $atts['items_padding'];
			}

			return $styles;
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}

			return $styles;
		}

		private function get_modified_info_text( $atts ) {
			$title = $atts['info_text'];

			if ( ! empty( $title ) && ! empty( $atts['line_break_positions'] ) ) {
				$split_title          = explode( ' ', $title );
				$line_break_positions = explode( ',', str_replace( ' ', '', $atts['line_break_positions'] ) );

				foreach ( $line_break_positions as $position ) {
					$position = intval( $position );
					if ( isset( $split_title[ $position - 1 ] ) && ! empty( $split_title[ $position - 1 ] ) ) {
						$split_title[ $position - 1 ] = $split_title[ $position - 1 ] . '<br />';
					}
				}

				$title = implode( ' ', $split_title );
			}

			return $title;
		}
	}
}
