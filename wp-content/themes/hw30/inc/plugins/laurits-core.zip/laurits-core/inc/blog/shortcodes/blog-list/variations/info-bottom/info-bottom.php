<?php

if ( ! function_exists( 'laurits_core_add_blog_list_variation_info_bottom' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function laurits_core_add_blog_list_variation_info_bottom( $variations ) {
		$variations['info-bottom'] = esc_html__( 'Info Bottom', 'laurits-core' );

		return $variations;
	}

	add_filter( 'laurits_core_filter_blog_list_layouts', 'laurits_core_add_blog_list_variation_info_bottom' );
}

if ( ! function_exists( 'laurits_core_add_blog_list_options_info_bottom' ) ) {
	/**
	 * Function that add additional options for variation layout
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	function laurits_core_add_blog_list_options_info_bottom( $options ) {
		$info_below_options   = array();
		$display_excerpt      = array(
			'field_type'    => 'select',
			'name'          => 'info_bottom_display_excerpt',
			'title'         => esc_html__( 'Display Blog Excerpt', 'laurits-core' ),
			'options'       => laurits_core_get_select_type_options_pool( 'yes_no', false ),
			'default_value' => 'yes',
			'dependency'    => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-bottom',
						'default_value' => '',
					),
				),
			),
			'group'         => esc_html__( 'Layout', 'laurits-core' ),
		);
		$info_below_options[] = $display_excerpt;

		return array_merge( $options, $info_below_options );
	}

	add_filter( 'laurits_core_filter_blog_list_extra_options', 'laurits_core_add_blog_list_options_info_bottom' );
}
