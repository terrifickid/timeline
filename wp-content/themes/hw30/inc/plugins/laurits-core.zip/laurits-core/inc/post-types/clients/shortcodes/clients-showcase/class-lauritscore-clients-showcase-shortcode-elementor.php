<?php

class LauritsCore_Clients_Showcase_Shortcode_Elementor extends LauritsCore_Elementor_Widget_Base {

	function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'laurits_core_clients_showcase' );

		parent::__construct( $data, $args );
	}
}

laurits_core_get_elementor_widgets_manager()->register_widget_type( new LauritsCore_Clients_Showcase_Shortcode_Elementor() );
