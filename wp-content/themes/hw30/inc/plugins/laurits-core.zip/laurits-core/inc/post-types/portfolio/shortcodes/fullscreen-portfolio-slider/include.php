<?php

include_once LAURITS_CORE_CPT_PATH . '/portfolio/shortcodes/fullscreen-portfolio-slider/class-lauritscore-fullscreen-portfolio-slider-shortcode.php';
