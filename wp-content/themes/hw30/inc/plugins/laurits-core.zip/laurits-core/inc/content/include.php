<?php

include_once LAURITS_CORE_INC_PATH . '/content/helper.php';
