<?php

include_once LAURITS_CORE_INC_PATH . '/icons/simple-line-icons/class-lauritscore-simple-line-icons-pack.php';
