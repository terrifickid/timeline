<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-lauritscore-twitter-list-widget.php';
