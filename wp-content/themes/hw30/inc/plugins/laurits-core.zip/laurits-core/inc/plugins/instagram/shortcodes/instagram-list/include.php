<?php

include_once LAURITS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-lauritscore-instagram-list-shortcode.php';
