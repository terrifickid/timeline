<?php

if ( ! function_exists( 'laurits_core_dependency_for_top_area_options' ) ) {
	/**
	 * Function which return dependency values for global module options
	 *
	 * @return array
	 */
	function laurits_core_dependency_for_top_area_options() {
		return apply_filters( 'laurits_core_filter_top_area_hide_option', $hide_dep_options = array() );
	}
}

if ( ! function_exists( 'laurits_core_register_top_area_header_areas' ) ) {
	/**
	 * Function which register widget areas for current module
	 */
	function laurits_core_register_top_area_header_areas() {
		register_sidebar(
			array(
				'id'            => 'qodef-top-area-left',
				'name'          => esc_html__( 'Header Top Area - Left', 'laurits-core' ),
				'description'   => esc_html__( 'Widgets added here will appear on the left side in top header area', 'laurits-core' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s qodef-top-bar-widget">',
				'after_widget'  => '</div>',
			)
		);

		register_sidebar(
			array(
				'id'            => 'qodef-top-area-right',
				'name'          => esc_html__( 'Header Top Area - Right', 'laurits-core' ),
				'description'   => esc_html__( 'Widgets added here will appear on the right side in top header area', 'laurits-core' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s qodef-top-bar-widget">',
				'after_widget'  => '</div>',
			)
		);
	}

	add_action( 'laurits_core_action_additional_header_widgets_area', 'laurits_core_register_top_area_header_areas' );
}
