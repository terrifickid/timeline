<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-content">
			<?php
			// Include post title
			laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/parts/title', '', $params );

			// Include post service
			laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/parts/service', '', $params );

			// Include post location
			laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/parts/location', '', $params );

			// Include post year
			laurits_core_template_part( 'post-types/portfolio/shortcodes/interactive-portfolio-showcase', 'templates/parts/year', '', $params );
			?>
		</div>
	</div>
</article>
