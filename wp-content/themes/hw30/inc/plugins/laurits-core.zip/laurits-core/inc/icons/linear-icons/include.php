<?php

include_once LAURITS_CORE_INC_PATH . '/icons/linear-icons/class-lauritscore-linear-icons-pack.php';
