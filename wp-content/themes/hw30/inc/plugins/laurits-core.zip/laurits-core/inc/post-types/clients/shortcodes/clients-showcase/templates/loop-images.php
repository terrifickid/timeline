<div class="qodef-e-image-holder">
	<?php
	if ( $query_result->have_posts() ) {
		while ( $query_result->have_posts() ) :
			$query_result->the_post();

			$params['item_classes'] = $this_shortcode->get_item_classes( $params );

			laurits_core_template_part( 'post-types/clients/shortcodes/clients-showcase', 'templates/parts/image', '', $params );

		endwhile; // End of the loop.
	} else {
		// Include global posts not found
		laurits_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
	}

	wp_reset_postdata();
	?>
</div>
