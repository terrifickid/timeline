<?php

include_once LAURITS_CORE_INC_PATH . '/header/layouts/tabbed/helper.php';
include_once LAURITS_CORE_INC_PATH . '/header/layouts/tabbed/class-lauritscore-tabbed-header.php';
include_once LAURITS_CORE_INC_PATH . '/header/layouts/tabbed/dashboard/admin/tabbed-header-options.php';
include_once LAURITS_CORE_INC_PATH . '/header/layouts/tabbed/dashboard/meta-box/tabbed-header-meta-box.php';
