<?php
$portfolio_info_client        = get_post_meta( get_the_ID(), 'qodef_portfolio_single_client', true );
$portfolio_info_client_link   = get_post_meta( get_the_ID(), 'qodef_portfolio_single_client_link', true );
$portfolio_info_client_target = get_post_meta( get_the_ID(), 'qodef_portfolio_single_client_link_target', true );

if ( ! empty( $portfolio_info_client ) ) { ?>
	<div class="qodef-e qodef-info--client">
		<span class="qodef-e-title"><?php esc_html_e( 'Client:', 'laurits-core' ); ?> </span>
		<?php if ( ! empty( $portfolio_info_client_link ) ) { ?>
		<a class="qodef--link" href="<?php echo esc_url( $portfolio_info_client_link ); ?>" target="<?php echo esc_attr( $portfolio_info_client_target ); ?>">
			<?php } else { ?>
			<span class="qodef-e-client">
			<?php } ?>
			<?php echo qode_framework_wp_kses_html( 'content', $portfolio_info_client ); ?>
			<?php if ( empty( $portfolio_info_client_link ) ) { ?>
				</span>
			<?php } else { ?>
		</a>
	<?php } ?>
	</div>
<?php } ?>
