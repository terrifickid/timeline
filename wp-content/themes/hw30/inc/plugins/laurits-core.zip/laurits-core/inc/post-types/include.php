<?php

include_once LAURITS_CORE_CPT_PATH . '/class-lauritscore-custom-post-types.php';
