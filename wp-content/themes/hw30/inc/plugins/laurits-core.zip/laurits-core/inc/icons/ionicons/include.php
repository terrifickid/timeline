<?php

include_once LAURITS_CORE_INC_PATH . '/icons/ionicons/class-lauritscore-ionicons-pack.php';
