(function ( $ ) {
	'use strict';
	
	
	$( document ).ready(
		function () {
			qodefClientsShowcase.init();
		}
	);
	
	$( window ).resize(
		function () {
			qodefClientsShowcase.resize();
		}
	);
	
	var qodefClientsShowcase = {
		init: function () {
			var $holder = $('.qodef-clients-showcase');
			
			if ($holder.length) {
				$holder.each(function () {
					var thisHolder = $(this),
						articles = thisHolder.find('article'),
						articlesImages = thisHolder.find('.qodef-e-image-holder .qodef-e-image'),
						showcaseInfo = thisHolder.find('.qodef-e-top-info'),
						itemsList = thisHolder.find('.qodef-e-items-list'),
						imagesList = thisHolder.find('.qodef-e-image-holder');
					
					articles.eq(0).addClass('qodef--hover');
					articlesImages.eq(0).addClass('qodef--hover');
					
					if (showcaseInfo.length) {
						itemsList.css('margin-top', showcaseInfo.height());
					}
					
					if ( qodef.windowWidth <= 1024 && showcaseInfo.length ) {
						imagesList.css('margin-top', showcaseInfo.height());
					}
					
					articles.each(function(e){
						var thisArticle = $(this);
						
						thisArticle.on('mouseover', function () {
							var imageHolder = articlesImages.eq(e);
							
							if (!thisArticle.hasClass('qodef--hover')){
								thisArticle.siblings().removeClass('qodef--hover');
								imageHolder.siblings().removeClass('qodef--hover');
								
								thisArticle.addClass('qodef--hover');
								imageHolder.addClass('qodef--hover');
							}
						});
					});
					
				});
			}
		},
		resize: function () {
			var $holder = $('.qodef-clients-showcase');
			
			if ($holder.length) {
				$holder.each(function () {
					var thisHolder = $(this),
						showcaseInfo = thisHolder.find('.qodef-e-top-info'),
						itemsList = thisHolder.find('.qodef-e-items-list'),
						imagesList = thisHolder.find('.qodef-e-image-holder');
					
					if ( qodef.windowWidth <= 1024 && showcaseInfo.length ) {
						itemsList.css('margin-top', showcaseInfo.outerHeight());
					} else {
						imagesList.css('margincd-top', 0);
					}
					
					if ( qodef.windowWidth <= 768 && showcaseInfo.length ) {
						itemsList.css('margin-top', showcaseInfo.outerHeight());
						imagesList.css('margin-top', showcaseInfo.outerHeight());
					} else {
						imagesList.css('margin-top', 0);
					}
					
					
				});
			}
		},
	};
	
	qodefCore.shortcodes.laurits_core_clients_showcase = {};
	qodefCore.shortcodes.laurits_core_clients_showcase.qodefClientsShowcase = qodefClientsShowcase;
	
})( jQuery );
